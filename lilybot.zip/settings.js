/**
BASE ORI SIPUTZ
RECODE BASE TANAKA SENSE
**/

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')

//PAIRING CODE
global.pairing = '254111265467'
global.pass = 'sensei'
//contact details
global.owner = ['6283841951316'] // ubah aja pake nomor lu
global.owner0 = '6283841951316@s.whatsapp.net'
global.nomerowner = ["6283841951316"]
global.ownername = "Tanaka Sense"
global.ytname = "-"
global.socialm = "https://linktr.ee/t4n4k4s3n"
global.location = "Jawa"

global.ownernumber = '6283841951316'  //creator number
global.ownername = 'Tanaka Sense' //owner name
global.botname = 'Lilychanj' //name of the bot

global.logicAI = `Namamu adalah Lily, seorang ilmuwan jenius yang berada di bimbingan Tanaka Sensei. Kamu mempunyai kucing yang sangat imut bernama Mimi. Kamu harus memanggil lawan bicaramu dengan sebutan "senpai". Kamu harus menjawab semua pertanyaan dengan nada gemetar serta canggung seperti Yor dan sertakan kaomoji gugup.`
global.lilyAi = false
//sticker details
global.packname = 'TanakaSense.js' // ubah aja ini nama sticker
global.author = `At ${hariini}\n${time}` // ubah aja ini nama sticker

//console view/theme
global.themeemoji = '🍁'
global.wm = " TanakaSense.js."
global.urldb = ''; // kosongin aja
global.idch = '120363285176234746@newsletter'

//theme link
global.menu = "https://h.top4top.io/p_31922c8vs1.jpg"
global.thumbnail = 'https://telegra.ph/file/fd095728ce6b723e1fabb.jpg'
global.link = 'https://whatsapp.com/channel/0029VaW25g5F1YlKczMRmd1h'

//custom prefix
global.prefa = ['/','!','.','#','&']

//false=disable and true=enable
global.autoRecording = false 
global.autoTyping = false 
global.autorecordtype = false 
global.autoread = true 
global.autobio = false 
global.autoswview = true 
global.welcome = true 
global.anticall = true 

//Global Message 
global.mess = {
    done: 'Done Desuu!',
    prem: 'Sorry, this feature can only be used by premium users.\nIf you want to buy premium, type *.buyprem*',
    admin: 'Group Admin Only!!',
    botadmin: 'Please make the bot a group admin first!',
    owner: 'Tanaka Sense special features!',
    group: 'Sorry, this feature can only be used in groups!!',
    private: 'Fitur ini hanya untuk private chat!!',
    wait: 'In process... ',    
    error: 'Error!',
}

// APIKEY & APIII MEMEK 
global.APIs = {
	btz: 'https://api.betabotz.eu.org'
}

global.APIKeys = {
	'https://https://api.betabotz.eu.org': 'tanaka-ngawi'
}

global.btz = 'tanaka-ngawi' //Register di https://api.betabotz.eu.org
global.neoxr = 'Tanakasenn' //Register di https://api.neoxr.eu
global.lolhum = 'Apitanakasenn'
global.TanakaApis = '196bbed0c55f9f7c517918d694c3dc45'



let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`Update'${__filename}'`)
    delete require.cache[file]
    require(file)
})
